<html>
<head>
    <title><?=$mailData['subject']?></title>
</head>
<body>

	<div>
		<?=$mailData['subject']?>: <br /><br />
			<table width='500' border='1' cellpadding='10' cellspacing='10' style='border:1px #ccc solid; border-collapse:collapse; color:#000'>
				<?php foreach($mailData['body'] as $key => $value) { ?>
				<tr>
					<td width='250'><?=ucwords($key)?></td>
					<td  width='250'><?=ucwords($value)?></td>
				</tr>    
				<?php } ?>
			</table>
	</div>
  
</body>
</html>