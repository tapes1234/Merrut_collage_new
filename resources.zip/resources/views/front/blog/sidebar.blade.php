<div id="sticky-sidebar" class="blog-sidebar">
	<div class="sidebar-search sidebar-grid shadow mb-50">
		<form class="search-bar">
			<input type="text" placeholder="Search...">
			<span>
				<button type="submit"><i class="flaticon-search"></i></button> 
			</span>
		</form>
	</div>
	<?php if($getBlogCategory) { ?>
	<div class="sidebar-categories sidebar-grid shadow">
		<div class="sidebar-title">
			<h3 class="title mb-20">Categories</h3>
		</div>
		<ul>
			<?php foreach($getBlogCategory as $blog_category) { ?>
				<li><a href="<?=createBlogCategoryUrl($blog_category->slug)?>"><?=$blog_category->title?></a></li>
			<?php } ?>
			
		</ul>
	</div>
	<?php } ?>
	<?php  if($recentPost  = recentPost(4)) { ?>
	<div class="sidebar-popular-post sidebar-grid shadow mb-50">
		<div class="sidebar-title">
			<h3 class="title mb-20">Recent Post</h3>
		</div>
		<?php foreach($recentPost aS $r_post) { ?>
		<div class="single-post mb-20">
			<div class="post-image">
				<a href="<?=createBlogUrl($r_post->blog_category_slug,$r_post->slug)?>"><img src="<?=resizeimg($r_post->icon,80,68,false)?>" alt="<?=$r_post->title?>"  title="<?=$r_post->title?>" ></a>
			</div>
			<div class="post-desc">
				<div class="post-title">
					<h5 class="margin-0"><a href="<?=createBlogUrl($r_post->blog_category_slug,$r_post->slug)?>"><?=$r_post->title?> </a></h5>
				</div>
				<ul>
					<li><i class="fa fa-calendar"></i> <?=date('d F, Y',strtotime($r_post->publish_date))?></li>
				</ul>
			</div>
		</div>
		<?php } ?>
	</div>
	<?php } ?>
	
</div>