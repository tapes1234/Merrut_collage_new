@extends('front.layout.layout')
@section('content')
<?=$breadcrumb?>

<div class="rs-blog inner single pt-50 pb-50 md-pt-80 md-pb-80">
	<div class="container">
		<div class="row">
			<div class="col-lg-8">
				<div class="blog-part">
					<div class="blog-img">
						<img src="<?=$thumb?>" title="<?=$title?>" alt="<?=$title?>">
						<p class="text-center"><i><?=$thumb_caption?></i></p>
					</div>
					<div class="article-content shadow mb-60">
						<h2><?=$heading?></h2>
						<ul class="blog-meta mb-22">
							<li><i class="fa fa-calendar-check-o"></i> <?=date('d F, Y',strtotime($publish_date))?></li>
                  </ul>
					<?=$description?>
               </div>
            </div>
         </div>
         <div class="col-lg-4 md-mb-50 pl-35 lg-pl-15 md-order-first">
            @include('front.blog.sidebar')
         </div>
      </div>
      <div id="sticky-end"></div>
   </div>
</div>
@endsection