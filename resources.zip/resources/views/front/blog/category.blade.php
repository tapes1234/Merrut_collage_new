@extends('front.layout.layout')
@section('content')
<?=$breadcrumb?>
<style>
.page-item.active .page-link {
	z-index: 3;
	color: #fff;
	background-color: #ed3410;
	border-color: #ed3410;
}

.page-link{
	color:#000;
}
</style>





<div id="rs-blog" class="rs-blog style1 modify bg6 pt-93 pb-92 md-pt-73 md-pb-50">
	<div class="container">
		<div class="row">
			<div class="col-md-8">
				<div class="row">
					<?php if($getResults) { ?>
					<?php foreach($getResults as $result) { ?>
					<div class="blog-wrap col-md-6 mb-4">
						<div class="img-part">
							<img src="<?=resizeimg($result->icon,556,483,false)?>" alt="<?=$result->title?>" title="<?=$result->title?>">
							<div class="fly-btn">
								<a href="<?=createBlogUrl($result->blog_category_slug,$result->slug)?>"><i class="flaticon-right-arrow"></i></a>
							</div>
						</div>
						<div class="content-part">
							<a class="categories" href="<?=createBlogUrl($result->blog_category_slug,$result->slug)?>"><?=$result->badge?></a>
							<h3 class="title"><a href="<?=createBlogUrl($result->blog_category_slug,$result->slug)?>"><?=$result->title?></a></h3>
							<p class="desc"><?=$result->short_description?></p>
							<div class="blog-meta">
								
								<div class="date">
									<i class="fa fa-clock-o"></i><?=date('d F, Y',strtotime($result->publish_date))?>
								</div>
							</div>
						</div>
					</div>
					<?php } ?>
					<div class="col-lg-12">
						<div class="mt-2">
							<?=$getResults->withQueryString()->links('pagination::bootstrap-5')?>
						</div>
					</div>
					<?php   } else { ?>
						<div class="blog-wrap col-md-12 mb-4">
							<h3 class="text-center">Data Not Found</h3>
						</div>
					<?php } ?>
				</div>
			</div>
			
			<div class="col-lg-4 md-mb-50 pl-35 lg-pl-15 md-order-first">
				@include('front.blog.sidebar')
			</div>	
		</div>
	</div>
</div>
@endsection