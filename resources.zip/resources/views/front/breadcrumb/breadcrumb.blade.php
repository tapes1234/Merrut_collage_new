





<section class="dropex-section r-breadcurmbs-1 njjjdur-mkksu">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="wrap_breadcrumbs_1">
					<h1 class="breadcurmbs-head"><?=$heading?></h1>
					<ul class="breadcrumbs_content_1 ">
						<li class=""><a href="<?=url('/')?>">Home</a></li>
						<?php $breadc = 1;foreach($breadcrumb as $bread) { ?>
							<?php if($breadc == count($breadcrumb)) { ?>
								<li class=""><a href="<?=url()->current()?>"><?=$bread['text']?></a></li>
							<?php } else { ?>
								<li class=""><a href="<?=$bread['href']?>"><?=$bread['text']?></a></li>
							<?php } ?>
						<?php $breadc++;} ?>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>



