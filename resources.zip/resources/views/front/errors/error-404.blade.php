@extends('front.layout.layout')
@section('content')

<?=$breadcrumb?>

<section class="tc-popular-posts-blog">
	<div class="container">
		<div class="content-widgets pt-50 pb-50">
			<div class="row">
				<div class="col-sm-12 text-center">
					<h2 class="text-center">404 Page Not Found</h2>
					<br>
					<a class="btn btn-secondary text-center" href="<?=url('/')?>">Back To Home</a>
				</div>
			</div>
		</div>
	</div>
</section>


@endsection