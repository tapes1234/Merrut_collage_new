@extends('front.layout.layout')
@section('content')
<?=$breadcrumb?>


<section class="new-posrt-folio">
    <div class="container">
        <div class="row">
			<div class="col-md-12">
				<div class="abnnnsdfhejrfe">
					<ul class="main-colle">
						<?php foreach($getResults as $result) { ?>
						<li><a class="z-mines" data-fancybox="gallery" href="<?=resizeimg($result->image,1920,800,true)?>"><img src="<?=resizeimg($result->image,1920,800,true)?>" class="img-fluid"></a></li>
						<?php } ?>
					</ul>
				</div>
			</div>
        </div>
    </div>
</section>


<section class="ft-contehy">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="nmnsduwjeruj">
					<?=$description?>
				</div>
			</div>
		</div>
	</div>
</section>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
<script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script> 
@endsection