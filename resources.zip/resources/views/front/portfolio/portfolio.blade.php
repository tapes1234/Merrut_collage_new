@extends('front.layout.layout')
@section('content')
<?=$breadcrumb?>

<section class="top-destinations">
	<div class="container">
		<div class="row justify-content-center">
			<?php foreach($getResults as $results) { ?>
				<div class="col-lg-4 col-md-4 p-2">
					<div class="top-destination-item">
						<img class="img-responsive" src="<?=resizeimg($results['image'],500,333,false)?>" alt="<?=$results['title']?>" title="<?=$results['title']?>">
						<div class="overlay">
							<h2><a href="<?=createPortFolioUrl($results['slug'])?>"><?=$results['title']?></a></h2>
							<?=$results['short_description']?>
						</div>
					</div>
				</div>
			<?php } ?>
		</div>
	</div>
</section>
@endsection