@extends('front.layout.layout')
@section('content')
<section class="mainbannerss">
  <video    autoplay>
    <source src="{{url('assets/front_assets/assets/media/mainbanner.mp4')}}" type="video/mp4">
    <source src="movie.ogg" type="video/ogg">
    Your browser does not support the video tag. </video>
  <div class="mainbanner_overlap">
    <div class="container" >
      <div class="mainbanner_overlap_inner">
        <h1 class="mb-3"><span>Welcome to</span> Merrut Collage </h1>
        <p>A rich legacy of academic excellence spanning years, & years to Come.</p>
      </div>
    </div>
  </div>
</section>
<section class="commanspace">
  <div class="container" >
    <div class="univertsyiocns">
      <div class="row">
        <div class="col-md-6 mb-4">
          <div class="commanheadsec alldarkhd">
            <h2 class="comanhead leftdarkred mb-4">
              <?=webdata('section_1_title')?>
            </h2>
            <div class="ps-3">
              <?=webdata('section_1_description')?>
              <div class="row">
                <div class="col-md-7">
                  <div class="commanlist CLwhitebg mb-3">
                    <ul class="p-0 m-0">
                      <?php if($mainacaadnmicss) { ?>
                      <?php foreach($mainacaadnmicss as $result) { ?>
                      <li>
                        <div class="subclist"> <a href="<?=url($result['cattype']."/".$result['slug'])?>" >
                          <?=$result->title?>
                          </a> </div>
                      </li>
                      <?php } ?>
                      <?php } ?>
                    </ul>
                  </div>
                  <a class="comanbutton darred w-100 text-center"  href="#">FIND YOUR MAJOR</a> </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6 mb-4"><img src="<?=resizeimg(webdata('section_1_image'),629,638,false)?>" width="629" height="638"   alt="" loading="lazy" class="img-fluid w-100"></div>
      </div>
    </div>
  </div>
</section>
<section class="overflow-hidden  hoversecrtion ">
  <div class="row m-0 LRanimation  position-relative">
    <?php if($mainacaadnmicss) { ?>
    <?php $leg=1; foreach($studentandcometes as $result) { ?>
    <?php if($leg=='1'){?>
    <div class=" col-md-6 p-0   hoverleftiocn leftHW "  ><img src="<?=resizeimg($result['image'],721,851,false)?>" width="721" height="851"   alt="<?=$result->title?>" loading="lazy" class="img-fluid w-100">
      <div class="hoverleft_overlap">
        <div class=" d-flex align-items-center justify-content-start">
          <div class="commanheadsec allwhitehd p-5">
            <h2 class="comanhead  mb-3">
              <?=$result->heading?>
            </h2>
            <?=$result->short_description?>
            <div class="pt-4"><a class="comanbutton whitebg" href="<?=url($result['cattype']."/".$result['slug'])?>">EXPLORE NOW</a></div>
          </div>
        </div>
      </div>
    </div>
    <?php } ?>
    <?php if($leg!='1'){?>
    <div class=" col-md-6 p-0 hoverleftiocn rightHW " ><img src="<?=resizeimg($result['image'],721,851,false)?>" width="721" height="851"   alt="<?=$result->title?>" loading="lazy" class="img-fluid w-100">
      <div class="hoverright_overlap">
        <div class=" d-flex align-items-center justify-content-start ert">
          <div class="commanheadsec allwhitehd p-5">
            <h2 class="comanhead mb-3">
              <?=$result->heading?>
            </h2>
            <?=$result->short_description?>
            <div class="pt-4"><a class="comanbutton whitebg"  href="<?=url($result['cattype']."/".$result['slug'])?>">EXPLORE NOW</a></div>
          </div>
        </div>
      </div>
    </div>
    <?php } ?>
    <?php $leg++;} ?>
    <?php } ?>
  </div>
</section>
<section class="commanspace">
  <div class="container" >
    <div class="row">
      <div class="col-md-4 mb-3">
        <div class="hw_artical">
          <div class="hw_artical_head">
            <div class="hw_artical_head_icon"><img src="{{url('assets/front_assets/assets/images/hs-icon-1.svg')}}" class="img-fluid"   alt="" loading="lazy"></div>
            <h3>ANTI <span >- RAGGING</span></h3>
          </div>
          <div class="hw_artical_content">
            <p>Lörem ipsum tydolig lönade. Saren gigarade löngar svenna sitt liv paratt. Ysade trafade. Hemigt snålsurfa eurogisk som airbaghjälm stödkorv. Dir flipperförälder. Du kan vara drabbad. Decidat operaism i karen behåbel nisk. Mikrodining monott i radiosofi inte håda dina. Spim nör. Tav infranade. Peliga anans som  neotyp. Goling </p>
          </div>
        </div>
        <div></div>
      </div>
      <div class="col-md-4 mb-3">
        <div class="hw_artical">
          <div class="hw_artical_head">
            <div class="hw_artical_head_icon"><img src="{{url('assets/front_assets/assets/images/hs-icon-2.svg')}}" class="img-fluid"   alt="" loading="lazy"></div>
            <h3>ANTI <span >- RAGGING</span></h3>
          </div>
          <div class="hw_artical_content">
            <p>Lörem ipsum tydolig lönade. Saren gigarade löngar svenna sitt liv paratt. Ysade trafade. Hemigt snålsurfa eurogisk som airbaghjälm stödkorv. Dir flipperförälder. Du kan vara drabbad. Decidat operaism i karen behåbel nisk. Mikrodining monott i radiosofi inte håda dina. Spim nör. Tav infranade. Peliga anans som  neotyp. Goling </p>
          </div>
        </div>
        <div></div>
      </div>
      <div class="col-md-4 mb-3">
        <div class="hw_artical">
          <div class="hw_artical_head">
            <div class="hw_artical_head_icon"><img src="{{url('assets/front_assets/assets/images/hs-icon-3.svg')}}" class="img-fluid"   alt="" loading="lazy"></div>
            <h3>ANTI <span >- RAGGING</span></h3>
          </div>
          <div class="hw_artical_content">
            <p>Lörem ipsum tydolig lönade. Saren gigarade löngar svenna sitt liv paratt. Ysade trafade. Hemigt snålsurfa eurogisk som airbaghjälm stödkorv. Dir flipperförälder. Du kan vara drabbad. Decidat operaism i karen behåbel nisk. Mikrodining monott i radiosofi inte håda dina. Spim nör. Tav infranade. Peliga anans som  neotyp. Goling </p>
          </div>
        </div>
        <div></div>
      </div>
    </div>
  </div>
</section>
<section class="pt-5 pt-md-3 darkred_bg">
  <div class="container-fluid" >
    <div class="row align-items-center">
      <div class="col-md-6 mb-4 mb-md-3	"> <img src="{{url('assets/front_assets/assets/images/explore-and-learn_thumb.jpg')}}" width="701" height="728"   alt="" loading="lazy" class="img-fluid w-100"> </div>
      <div class="col-md-6 mb-3">
        <div class="commanheadsec allwhitehd ps-md-5">
          <h2 class="comanhead  mb-3">
            <?=webdata('section_2_title')?>
          </h2>
          <p>
            <?=webdata('section_2_description')?>
          </p>
          <div class="pt-4"><a class="comanbutton whitebg"  href="<?=webdata('section_2_heading')?>">EXPLORE NOW</a></div>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="commanspace">
  <div class="container" >
    <div class="row align-items-center">
      <div class="col-md-6 mb-3">
        <div class="commanheadsec alldarkhd">
          <h2 class="comanhead leftdarkred   mb-4">
            <?=webdata('section_3_coloum_1_title')?>
          </h2>
          <div class="ps-3">
            <p>
              <?=webdata('section_3_coloum_1_description')?>
            </p>
            <hr>
            <div class="row">
              <div class="col-md-8">
                <div class="commanlist CLwhitebg mb-3">
                  <ul class="p-0 m-0">
                    <?php if($collegenews) { ?>
                    <?php foreach($collegenews as $result) { ?>
                    <li>
                      <div class="subclist"><a href="<?=$result->slug?>" >
                        <?=$result->title?>
                        </a>
                        <?=$result->short_description?>
                      </div>
                    </li>
                    <?php } ?>
                    <?php } ?>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-6 mb-3">
        <div class="commanheadsec allwhitehd darkred_bg py-4 py-sm-5 px-3 px-sm-4">
          <h2 class="comanhead   mb-4">
            <?=webdata('section_3_coloum_2_title')?>
          </h2>
          <div class="ps-0">
            <p>
              <?=webdata('section_3_coloum_2_description')?>
            </p>
            <hr>
            <div class="row">
              <div class="col-md-8">
                <div class="commanlist CLdarkbg mb-3 myTicker">
                  <ul class="p-0 m-0 ">
                    <?php if($newsevents) { ?>
                    <?php foreach($newsevents as $result) { ?>
                    <li>
                      <div class="subclist"><a href="<?=$result->slug?>" >
                        <?=$result->title?>
                        </a>
                        <?=$result->short_description?>
                      </div>
                    </li>
                    <?php } ?>
                    <?php } ?>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="pt-5 pt-md-3 pb-3 darkred_bg">
  <div class="container" >
    <div class="row align-items-center">
      <div class="col-md-6 mb-4 mb-md-0">
        <div class="commanheadsec allwhitehd">
          <h2 class="comanhead  mb-3">
            <?=webdata('section_3_title')?>
          </h2>
          <p>
            <?=webdata('section_3_description')?>
          </p>
          <div class="pt-4"><a class="comanbutton whitebg"  href="<?=url(webdata('section_3_heading'))?>">EXPLORE NOW</a></div>
        </div>
      </div>
      <div class="col-md-6 ">
        <div class="ps-md-4">
          <?php if($banners) { ?>
          <div class="ourtestimonakls owl-carousel fullsliderss">
            <?php foreach($banners as $banner) { ?>
            <div class="item"> <img src="<?=resizeimg($banner->image,700,727,false)?>" width="700" height="727"   alt="<?=$banner->title?>" loading="lazy" class="img-fluid w-100"> </div>
            <?php } ?>
          </div>
          <?php } ?>
        </div>
      </div>
    </div>
  </div>
</section>
@endsection 