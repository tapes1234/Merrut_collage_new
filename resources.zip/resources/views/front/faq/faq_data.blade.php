<?php if($allfaqs) { ?>
<div class="rs-faq inner pt-92 md-pt-72 pb-100 md-pb-80 gray-bg">
   <div class="container">
      <div class="row">
         <div class="col-lg-12 pr-55 md-pr-15 md-mb-30">
            <div class="sec-title mb-43">
               <div class="sub-title primary">Feel free to contact us</div>
               <h2 class="title mb-16">Do You Have Any Questions?</h2>
               <div class="desc">Creation timelines for the standard lorem ipsum passage vary, with some citing the 15th century and others the business data.</div>
            </div>
            <div id="accordion" class="accordion">
				<?php foreach($allfaqs as $faqs) { ?>
				<div class="card">
					<div class="card-header">
						<a class="card-link collapsed" data-toggle="collapse" href="#collapseOne_<?=$faqs['id']?>" aria-expanded="false"><?=$faqs['question']?></a>
					</div>
					<div id="collapseOne_<?=$faqs['id']?>" class="collapse" data-parent="#accordion">
						<div class="card-body"><?=$faqs['answer']?></div>
					</div>
				</div>
				<?php } ?>
			   
            
            </div>
         </div>
      </div>
   </div>
</div>
<?php } ?>