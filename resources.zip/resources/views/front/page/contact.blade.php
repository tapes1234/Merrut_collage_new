@extends('front.layout.layout')
@section('content')
<?=$breadcrumb?>
<section class="upper-contavt">
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<div class="main-left">
					<div class="acdfr-mkkdi-up-heading">
						<h4>For Sales & Marketing queries  </h4>
					</div>
					<?php if(isset($allwebdata['sales_address']) && $allwebdata['sales_address']) { ?>
					<div class="position-an-njjs">
						<i class="fa fa-map-marker"></i>
						<?=$allwebdata['sales_address']?>
					</div>
					<?php } ?>
					<?php if(isset($allwebdata['sales_phone']) && $allwebdata['sales_phone']) { ?>
					<div class="position-an-njjs">
						<i class="fa fa-phone"></i>
						<?=$allwebdata['sales_phone']?>
					</div>
					<?php } ?>
					<?php if(isset($allwebdata['sales_email']) && $allwebdata['sales_email']) { ?>
					<div class="position-an-njjs">
						<i class="fa fa-envelope"></i>
						<?=$allwebdata['sales_email']?>
					</div>
					<?php } ?>
				</div>
			</div>
			<div class="col-md-4">
				<div class="main-left">
					<div class="acdfr-mkkdi-up-heading">
						<h4>Corporate Office   </h4>
					</div>
					<?php if(isset($allwebdata['corporate_address']) && $allwebdata['corporate_address']) { ?>
					<div class="position-an-njjs">
						<i class="fa fa-map-marker"></i>
						<?=$allwebdata['corporate_address']?>
					</div>
					<?php } ?>
					<?php if(isset($allwebdata['corporate_phone']) && $allwebdata['corporate_phone']) { ?>
					<div class="position-an-njjs">
						<i class="fa fa-phone"></i>
						<?=$allwebdata['corporate_phone']?>
					</div>
					<?php } ?>
					<?php if(isset($allwebdata['corporate_email']) && $allwebdata['corporate_email']) { ?>
					<div class="position-an-njjs">
						<i class="fa fa-envelope"></i>
						<?=$allwebdata['corporate_email']?>
					</div>
					<?php } ?>
				</div>
			</div>	
			<div class="col-md-4">
				<div class="main-left">
					<div class="acdfr-mkkdi-up-heading">
						<h4>spiring candidates may contact at: </h4>
					</div>
					<?php if(isset($allwebdata['spiring_address']) && $allwebdata['spiring_address']) { ?>
					<div class="position-an-njjs">
						<i class="fa fa-map-marker"></i>
						<?=$allwebdata['spiring_address']?>
					</div>
					<?php } ?>
					<?php if(isset($allwebdata['spiring_phone']) && $allwebdata['spiring_phone']) { ?>
					<div class="position-an-njjs">
						<i class="fa fa-phone"></i>
						<?=$allwebdata['spiring_phone']?>
					</div>
					<?php } ?>
					<?php if(isset($allwebdata['spiring_email']) && $allwebdata['spiring_email']) { ?>
					<div class="position-an-njjs">
						<i class="fa fa-envelope"></i>
						<?=$allwebdata['spiring_email']?>
					</div>
					<?php } ?>
				</div>
			</div>
		</div>
	</div>
</section>

<?php if($clients) { ?>
<section class="njjdur-mllsdur">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="section-head less-padding-bt b-align-center">
					<h2 class="head-title" style="color: #fff;">Our Plants</h2>
				</div>
			</div>
			<?php foreach($clients as $client) { ?>
			<div class="col-md-6">
				<div class="frm-cards">
					<div class="anjkd-hed">
						<h5><?=$client['name']?></h5>
					</div>
					<div class="mnbv-kiidjr">
						<?php if($client['address']) { ?>
						<p><i class="fa fa-map-marker"></i><?=$client['address']?></p>
						<?php } ?>
						<?php if($client['phone']) { ?>
						<p><i class="fa fa-phone"></i><?=$client['phone']?></p>
						<?php } ?>
						<?php if($client['email']) { ?>
						<p><i class="fa fa-envelope"></i> <?=$client['email']?></p>
						<?php } ?>
					</div>
				</div>
			</div>
			<?php } ?>
        
		</div>
	</div>
</section>
<?php } ?>

<section class="new-fqr-svgd">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<?=webdata('map')?>
			</div>
			<div class="col-md-6 bac-co-njjd">
				<div class="main-ksm">
					<div class="heading-upper"><h3>Get In Touch</h3></div>
					@include('front.form.enquiry')
				</div>
			</div>
		</div>
   </div>
</section>



@endsection