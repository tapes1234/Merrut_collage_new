@extends('front.layout.layout')
@section('content')
<section class="maininnersec" style=" background:url({{url('assets/front_assets/assets/images/our_history_bg.jpg')}}) no-repeat center top; background-size:cover" >
  <div class="container" >
    <div class="maininnerchilld d-flex align-items-center">
      <div class="commanheadsec  allwhitehd">
        <h1 class="innersubHD  mb-1">
      <?=$heading?>
        </h1>
        <p>We fit an impressive array of activities onto our small campus and the city of Meerut. The only thing you must fear is ... "missing out". Explore your worth with Meerut College. Meerut College has all you'd expect from a top-tier college.</p>
      </div>
    </div>
  </div>
</section>

<section class="commanspace commanheadsec overflow-hidden">

  <div class="container" >


      <div class="row justify-content-center mb-2">
        <div class="col-md-8 mb-2">
          <div class="pe-0 pe-md-5 ">
            <h3 class="pb-3 comansubhead">Open <span>Positions</span></h3>
            <ul>
              <li>Open position for the Post of Field Assistant</li><li>
Open position for the Post of Field Assistant for UPHED Research Project. 03-07-2023</li><li>
Open position for the Post of Field Assistant for UPHED Research Project.</li>
            </ul>
          </div>
        </div>
        <div class="col-md-4 mb-2">
          <div class="ps-0 ps-md-5">
            <h3 class="pb-3 comansubhead">Contact us <span>To know more</span></h3>
            <p>Additionally, there are ten executives working alongside them in various capacities. To enhance online reach and connectivity with all members, we have set up an email address at </p>
          </div>
        </div>
      </div>
      

      
  
</div></section>




<!--

<?=$breadcrumb?>
<section class="dropex-section faq-section">
	<div class="container">
		<div class="row">
			<div class="col-lg-10 col-md-8 col-12" style="margin-left: auto; margin-right: auto;">
				<div class="njjjdur-mkkkdir-mkkkks">
					<form id="contactform" method="post" enctype="multipart/form-data">
					@csrf
					<div class="row">
						<div class="col-md-6">
							<div class="amjjiryufhyt">
								<input type="text" class="abnnnndur-omruu" name="name" placeholder="Name">
								<span class="formerror text-danger" id="name_err"></span>
							</div>
						</div>
						<div class="col-md-6">
							<div class="amjjiryufhyt">
								<input type="text" class="abnnnndur-omruu" name="email" placeholder="Email">
								<span class="formerror text-danger" id="email_err"></span>
							</div>
						</div>
						<div class="col-md-12">
							<div class="amjjiryufhyt">
								<input type="text" class="abnnnndur-omruu" name="phone" placeholder="Phone No">
								<span class="formerror text-danger" id="phone_err"></span>
							</div>
						</div>
						<div class="col-md-12">
							<div class="amjjiryufhyt">
								<label>Upload Resume</label>
								<input type="file" class="abnnnndur-omruu" name="resume" placeholder="Resume">
								<span class="formerror text-danger" id="resume_err"></span>
							</div>
						</div>
						<div class="col-md-12">
							<div class="amjjiryufhyt">
								<input type="text" class="abnnnndur-omruu-2" name="subject" placeholder="Subject">
								<span class="formerror text-danger" id="subject_err"></span>
							</div>
						</div>
						<div class="col-md-12">
							<div class="amjjiryufhyt text-center">
								<button type="submit" id="formsubmitbtn" class="dggggbr-koooeir">Submit Now</button>
							</div>
						</div>
					</div>
					</form>
				</div>
			</div>
		</div>
   </div>
</section>-->
<script type="text/javascript">
	$('#contactform').submit(function(e) {
		$('#formsubmitbtn').html('Processing...');
		document.getElementById("formsubmitbtn").disabled = true; 
        e.preventDefault();
		$('.formerror').empty();
        let formData = new FormData(this);
        $.ajax({
            type:'POST',
            url: '<?php echo url('careerform')?>',
            data: formData,
			contentType: false,
			processData: false,
			success: (response) => {
				
				if(response['status'] === false){
						for(i in response['errors']){
							var elements  = i+'_err';
							document.getElementById(elements).innerHTML = response['errors'][i]; 
						}
				}
				
				if(response['status'] === true){
					document.getElementById("contactform").reset();
					console.log('true');
				}

				$('#formsubmitbtn').html('Submit');
				document.getElementById("formsubmitbtn").disabled = false; 
				
			},
			
			
		});
    });
</script>


@endsection