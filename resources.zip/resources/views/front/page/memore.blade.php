@extends('front.layout.layout')
@section('content')
<?php //echo $breadcrumb?>
@include('front.category.slider')
<style type="text/css">
    .mob-shooo{
		display: none;
	}

	@media(max-width: 768px){
		.mob-hide-sloor{
			display: none;
		}
		.mob-shooo{
			display: block;
      		margin-top: 10px;
      		margin-bottom: 10px;
      	}

	}
</style>
<?php if(isset($allwebdata['memore_section_1_enable']) && $allwebdata['memore_section_1_enable'] == 1) { ?>
<section class="product-serd-njjd">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="main-koooei">
					<div class="title-holder-mkkkdiu">
						<h2 class="elementor-heading-title text-center border-0"><?=isset($allwebdata['memore_section_1_heading']) ?  $allwebdata['memore_section_1_heading'] : ''?></h2>
					</div>
					<div class="content-mkkkdi row pillow_advatages">

						<div class="col-md-2 offset-md-1 text-center">
							<img src="<?=isset($allwebdata['memore_section_1_row_1_page_file']) ? resizeimg($allwebdata['memore_section_1_row_1_page_file'],120,120,false) : resizeimg('no_image.jpg',120,120,false)?>">
							<h5 class="tittle text-center"><?=isset($allwebdata['memore_section_1_row_1_heading']) ?  $allwebdata['memore_section_1_row_1_heading'] : ''?></h5>
						</div>
						
						<div class="col-md-2 text-center">
							<img src="<?=isset($allwebdata['memore_section_1_row_2_page_file']) ? resizeimg($allwebdata['memore_section_1_row_2_page_file'],120,120,false) : resizeimg('no_image.jpg',120,120,false)?>">
							<h5 class="tittle text-center"><?=isset($allwebdata['memore_section_1_row_2_heading']) ?  $allwebdata['memore_section_1_row_2_heading'] : ''?></h5>
						</div>
						
						<div class="col-md-2 text-center">
							<img src="<?=isset($allwebdata['memore_section_1_row_3_page_file']) ? resizeimg($allwebdata['memore_section_1_row_3_page_file'],120,120,false) : resizeimg('no_image.jpg',120,120,false)?>">
							<h5 class="tittle text-center"><?=isset($allwebdata['memore_section_1_row_3_heading']) ?  $allwebdata['memore_section_1_row_3_heading'] : ''?></h5>
						</div>	
						
						<div class="col-md-2 text-center">
							<img src="<?=isset($allwebdata['memore_section_1_row_4_page_file']) ? resizeimg($allwebdata['memore_section_1_row_4_page_file'],120,120,false) : resizeimg('no_image.jpg',120,120,false)?>">
							<h5 class="tittle text-center"><?=isset($allwebdata['memore_section_1_row_4_heading']) ?  $allwebdata['memore_section_1_row_4_heading'] : ''?></h5>
						</div>	
						
						<div class="col-md-2 text-center">
							<img src="<?=isset($allwebdata['memore_section_1_row_5_page_file']) ? resizeimg($allwebdata['memore_section_1_row_5_page_file'],120,120,false) : resizeimg('no_image.jpg',120,120,false)?>">
							<h5 class="tittle text-center"><?=isset($allwebdata['memore_section_1_row_5_heading']) ?  $allwebdata['memore_section_1_row_5_heading'] : ''?></h5>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php } ?>

<section class="product-serd-njjd ">
	<div class="container ">
		<div class="row horizontal-slider">
     
			<div class="col-md-4 mt-4 item">
				<div class=" pr_bg text-center">
					<img  src="assets/images/curv.jpg" alt="Card image cap" class="">
					<div class="card-body text-center">
						<h3 class="card-title ">Memory Foam Curve Pillow</h3>
						<div class="link_btn " >
							<a href="https://www.amazon.in/dp/B0B12TVY8S?ref=myi_title_dp&amp;th=1" target="_blank" class="mr-3"> <img src="assets/images/ama.png" class="shadow-0"> </a>
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</div>
</section>

<section class="feautreimg">
	<div class="container">
		<div class="row">
			<div class="col-12 text-center">
				<img src="<?=isset($allwebdata['memore_section_3_page_file']) ?  $allwebdata['memore_section_3_page_file'] : ''?>" class="img-responsive">
			</div>
		</div>
	</div>
</section>

<?php if(isset($allwebdata['memore_section_4_enable']) && $allwebdata['memore_section_4_enable'] == 1) { ?>
<section class="product_Memory my-5 ">
	<div class="container-fluid ">
		<div class="row">
			<div class="col-md-12 text-center mb-5">
				<h1 class="Best_Seller_Products text-uppercase "><?=isset($allwebdata['memore_section_4_heading']) ?  $allwebdata['memore_section_4_heading'] : ''?></h1>
			</div>
		   <div class=" col-md-6 ">
				<div class="title_holder_memo text-left pl-4">
					<?=isset($allwebdata['memore_section_4_row_1_content']) ?  $allwebdata['memore_section_4_row_1_content'] : ''?>
				</div>
			</div>
			<div class=" col-md-6  p-0">
				<div class="img_bg" style="background-image:url(<?=isset($allwebdata['memore_section_4_row_1_page_file']) ? resizeimg($allwebdata['memore_section_4_row_1_page_file'],1050,500,false) : resizeimg('no_image.jpg',1050,500,false)?>)"> </div>
			</div>
		</div>

		<!--single-->
		<div class="row mob-hide-sloor">
			<div class=" col-md-7  p-0">
				<div class="img_bg1"  style="background-image:url(<?=isset($allwebdata['memore_section_4_row_2_page_file']) ? resizeimg($allwebdata['memore_section_4_row_2_page_file'],1050,500,false) : resizeimg('no_image.jpg',1050,500,false)?>)"></div>
			</div>
			<div class=" col-md-5 ">
				<div class="title_holder_memo text-right pr-4">
					<?=isset($allwebdata['memore_section_4_row_2_content']) ?  $allwebdata['memore_section_4_row_1_content'] : ''?> 
				</div>
			</div>
		</div>
		<div class="row mob-shooo">
			<div class=" col-md-5 ">
				<div class="title_holder_memo text-right pr-4">
				<?=isset($allwebdata['memore_section_4_row_2_content']) ?  $allwebdata['memore_section_4_row_1_content'] : ''?>
				</div>
			</div>
			<div class=" col-md-7  p-0">
				<div class="img_bg1"  style="background-image:url(<?=isset($allwebdata['memore_section_4_row_2_page_file']) ? resizeimg($allwebdata['memore_section_4_row_2_page_file'],1050,500,false) : resizeimg('no_image.jpg',1050,500,false)?>)"></div>
			</div>
		</div>
		<!--single-->

		<div class="row">
			<div class=" col-md-5 ">
				<div class="title_holder_memo text-left pl-4">
					<?=isset($allwebdata['memore_section_4_row_3_content']) ?  $allwebdata['memore_section_4_row_3_content'] : ''?>
				</div>
			</div>
			<div class=" col-md-7  p-0">
				<div class="img_bg2" style="background-image:url(<?=isset($allwebdata['memore_section_4_row_3_page_file']) ? resizeimg($allwebdata['memore_section_4_row_3_page_file'],1050,500,false) : resizeimg('no_image.jpg',1050,500,false)?>)"></div>
			</div>
		</div>
		
	</div>
</section>
<?php } ?>
<section class="product-serd-njjd new-bac-kkksur">
	<div class="container">
		<div class="row">
			<div class=" col-md-6">
				<img src="<?=resizeimg($allwebdata['memore_page_file'],1000,1000,false)?>" >
			</div>
			  
			<div class=" col-md-6">
				<div class="main-koooei">
					<?=isset($allwebdata['memore_description']) ? $allwebdata['memore_description'] : '' ?>
				</div>
			</div>
		</div>
	</div>
</section>

@endsection