@extends('front.layout.layout')
@section('content')
<?=$breadcrumb?>

<section class="clent-sec-bhhd">
	<div class="container">
		<div class="row">
			<?php if($clients) { ?>
				<?php foreach($clients as $client) { ?>
				<div class="iklm-dnhjjdue">
					<a href="#">
						<img class="" src="<?=resizeimg($client['image'],306,138,false)?>" alt="image">
					</a>
				</div>
				<?php } ?>
				
			<?php } else { ?>
				<div class="col-sm-12">
					<div class="text-center">
						<h3>Data Not Found</h3>
					</div>
				</div>
			<?php } ?>
			
		</div>
	</div>
</section>
@endsection