@extends('front.layout.layout')
@section('content')
<section class="maininnersec" style=" background:url({{url('assets/front_assets/assets/images/our_history_bg.jpg')}}) no-repeat center top; background-size:cover" >
  <div class="container" >
    <div class="maininnerchilld d-flex align-items-center">
      <div class="commanheadsec  allwhitehd">
        <h2 class="innersubHD  mb-1">
          <?=$heading?>
        </h2>
        <p>We fit an impressive array of activities onto our small campus and the city of Meerut. The only thing you must fear is ... "missing out". Explore your worth with Meerut College. Meerut College has all you'd expect from a top-tier college.</p>
      </div>
    </div>
  </div>
</section>
<?php if($getPageMenus = getPageMenu($posstion='top')) { ?>
<section class="quickbutton" >
  <div class="quickbuttoninner" >
    <?php foreach($getPageMenus as $getCMs) { ?>
    <a  href="<?=url($getCMs['slug'])?>" <?php if($getCMs['slug']== $slug){ echo " class='quactive'";} ?>>
    <?=$getCMs['title']?>
    </a>
    <?php } ?>
  </div>
</section>
<?php } ?>
<?php if($slug=='legacy') { ?>
<section class="mainpalalexdW " >
  <?php if($alllegacys) { ?>
  <?php $leg=1; foreach($alllegacys as $alllegacy) { ?>
  <?php if($leg=='1'){?>
  <div class="paralexdesign delayanimationss animatedParent"  id="vertical">
    <div   class="paralexbanner"  data-paroller-factor="0.5" style="background: url(<?=resizeimg($alllegacy->banner,1440,918,false)?>) no-repeat center center"  >
      <div class="paralexdesign_inner">
        <div class="container" >
          <div class="row justify-content-center  mb-5 pb-5">
            <div class="col-md-10 pt-5 mt-5">
              <div class="commanheadsec  allwhitehd text-center">
                <h2 class="innersubHD  mb-1">Legacy Of <span class="d-inline-block">leadership</span></h2>
                <p>Lörem ipsum tydolig lönade. Saren gigarade löngar svenna sitt liv paratt. Ysade trafade. Hemigt snålsurfa eurogisk som airbaghjälm stödkorv. Dir flipperförälder. Du kan vara drabbad. Decidat operaism i karen behåbel nisk. Mikrodining monott i radiosofi inte håda dina. Spim nör. Tav infranade. Peliga anans som tin biogt då doragisk. Mikrovis midäns, regon. Hypogt plament. Nebina hypol hyporan, hypersion för att parasport. Monogon fadäde fasana. Nispeda deledes, neotyp. Goling essade. Prometer ultrare: rarat, ryggsäcksmodellen. Fäponat hadäna han. Byvyn kägeck patt seplar båskap. Plavis agon. </p>
              </div>
            </div>
          </div>
          <div class="paralexsubdesign">
            <div class="row justify-content-center">
              <div class="col-md-7">
                <div class="paralex_content row">
                  <div class="col-6 animated fadeInLeft" >
                    <div class="paralex_content_thumb"><img src="<?=resizeimg($alllegacy->image,335,360,false)?>" width="335" height="360" class="img-fluid w-100"   alt="" loading="lazy">
                      <div class="paralex_content_thumb_year">
                        <?=$alllegacy->link?>
                      </div>
                    </div>
                  </div>
                  <div class="col-6 animated fadeInRight">
                    <div class="paralex_content_con">
                      <h3>
                        <?=$alllegacy->name?>
                      </h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php }  ?>
  <?php if($leg!='1'){?>
  <div class="paralexdesign delayanimationss animatedParent"  id="vertical">
    <div   class="paralexbanner"  data-paroller-factor="0.5" style="background: url(<?=resizeimg($alllegacy->image,700,727,false)?>) no-repeat center center"  >
      <div class="paralexdesign_inner">
        <div class="container" >
          <div class="paralexsubdesign">
            <div class="row justify-content-center">
              <div class="col-md-7">
                <div class="paralex_content row">
                  <div class="col-6 animated fadeInLeft" >
                    <div class="paralex_content_thumb"><img src="<?=resizeimg($alllegacy->image,335,360,false)?>" width="335" height="360" class="img-fluid w-100"   alt="" loading="lazy">
                      <div class="paralex_content_thumb_year">
                        <?=$alllegacy->link?>
                      </div>
                    </div>
                  </div>
                  <div class="col-6 animated fadeInRight">
                    <div class="paralex_content_con">
                      <h3>
                        <?=$alllegacy->name?>
                      </h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php } ?>
  <?php $leg++;} ?>
  <?php } ?>
</section>
<?php } elseif($slug=='alumni') {?>
<section class="commanspace overflow-hidden">
  <div class="container" >
    <div class="commanheadsec alldarkhd text-center mb-5">
      <h2 class="comanhead  mb-4">Connect with your <span>community</span></h2>
      <p>Meerut College is proud to have an esteemed list of alumni who have made their mark in various fields. Their accomplishments and contributions serve as an inspiration for current and future students. Some notable alumni include: - Late Chaudhary Charan Singh - A prominent political figure, Late Chaudhary Charan Singh served as the Prime Minister of India. - Late Kunwar Mahmud Ali Khan - Former Governor of Madhya Pradesh, his leadership played a significant role in shaping the state's development. - Murli Manohar Joshi - An influential politician, Murli Manohar Joshi has held several important positions including Union Human Resource Development Minister of India. - Late Jagmohanlal Sinha - As an Indian Judge, his landmark decision in State of Uttar Pradesh v. Raj Narain had far-reaching consequences during the declaration of emergency. Pakistani social activist Akhtar Hameed Khan, and Virendra Verma (Former Governor of Punjab, Administrator of Chandigarh, and Governor of Himachal Pradesh) Meerut College have all made significant contributions in their respective fields. These are just a few names from our prestigious alumni community that showcase excellence across different domains. We take pride in recognizing their achievements and contributions to society.</p>
    </div>
  </div>
  <h2 class="text-center mb-4 fw-bold"><span class="text-dark">Notable</span> <span class="darkred">Alumni</span></h2>
  <div class="notablealumnislider owl-carousel ">
    <?php foreach($notablealumnis as $notablealumni) { ?>
    <div class="item p-1">
      <div class="notablecard">
        <div class="notablecard-thumb"><img src="<?=resizeimg($notablealumni->image,499,368,false)?>" width="700" height="727"   alt="<?=$notablealumni['name']?>" loading="lazy" class="img-fluid w-100"></div>
        <div class="notablecard-content">
          <h6>
            <?=$notablealumni['name']?>
          </h6>
          <p>
            <?=$notablealumni['designation']?>
          </p>
        </div>
      </div>
    </div>
    <?php } ?>
  </div>
</section>
<section class=" commanspace old_boys_section overflow-hidden">
  <div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-lg-9">
        <div class="commanheadsec allwhitehd text-center mb-4">
          <h2 class="comanhead  mb-3">Old Boys Alumni <span>Association </span></h2>
          <p>The Board of Trustees serves as the college's governing body, ensuring that important goals are met and our vision is upheld. The president provides day-to-day leadership and overall oversight over Meerut College's responsibilities, reporting to the board and functioning as a member. Senior staff supervise the academic and administrative responsibilities of the college and advise and support the president's work. </p>
        </div>
      </div>
    </div>
  </div>
  <div class="text-center pb-4" >
    <h3 class="text-white">The new office bearers leading <span  >this initiative are as follows</span></h3>
  </div>
  <div class="notablealumnislider2 owl-carousel ">
    <?php foreach($notablealumnis as $notablealumni) { ?>
    <div class="item p-1">
      <div class="notablecard">
        <div class="notablecard-thumb"><img src="<?=resizeimg($notablealumni->image,499,368,false)?>" width="700" height="727"   alt="<?=$notablealumni['name']?>" loading="lazy" class="img-fluid w-100"></div>
        <div class="notablecard-content">
          <h6>
            <?=$notablealumni['name']?>
          </h6>
          <p>
            <?=$notablealumni['designation']?>
          </p>
        </div>
      </div>
    </div>
    <?php } ?>
  </div>
  <div class="container">
    <div class="row justify-content-center pt-4 pb-4">
      <div class="col-lg-9">
        <div class="commanheadsec allwhitehd text-center mb-4">
          <h2 class="comanhead  mb-3">Objectives <span class="d-inline-block">Of OBA </span></h2>
          <p>Lörem ipsum tydolig lönade. Saren gigarade löngar svenna sitt liv paratt. Ysade trafade. Hemigt snålsurfa eurogisk som airbaghjälm stödkorv. Dir flipperförälder. Du kan vara drabbad. Decidat operaism i karen behåbel nisk. Mikrodining monott i radiosofi inte håda dina. Spim nör. Tav infranade. Peliga anans som tin biogt då doragisk. Mikrovis midäns, regon. Hypogt plament. Nebina hypol hyporan, hypersion för att parasport. Monogon fadäde fasana. Nispeda deledes, neotyp. Goling essade. Prometer ultrare: rarat, ryggsäcksmodellen. Fäponat hadäna han. Byvyn kägeck patt seplar båskap. Plavis agon. </p>
        </div>
      </div>
    </div>
    <div class="commanheadsec allwhitehd">
      <div class="row justify-content-center mb-2">
        <div class="col-md-8 mb-2">
          <div class="pe-0 pe-md-5 ">
            <h3 class="pb-3 comansubhead">Ethos & <span >Objective</span></h3>
            <ul>
              <li> To bring together all ex-students of the Meerut College under one fraternity.</li>
              <li> To create a sense of belonging, friendship among the ex-students of the Meerut College to be able to render social service and knowledge and to serve the society in best possible manner.</li>
              <li> To raise funds for carrying on the work of the Alumni through subscriptions, donations, fees and other activities. </li>
              <li> To utilize the funds, donations and all other means and assets of the Alumni in the best possible manner to achieve the objectives of the Alumni. </li>
              <li> To bring an awareness in the society of the existence of the Alumni and to highlight the achievements, the services rendered by ex-students of Meerut College whether members of the Alumni or not in administration, society, business, industry or otherwise and to honour and reward such people from time to time. </li>
              <li> To institute awards and establish scholarships in the name of the eminent people belonging to the Meerut College or such other person who may donate the funds for establishment of such scholarships to be given to the deserving students studying in Meerut College, Meerut. </li>
              <li> To hold cultural and other events from time to time to establish fraternity and get-togetherness among the ex-students of Meerut College.8) To do all such acts and deeds incidental and conducive to the attainment of the above objects or any of them as in the best interest of alumni. </li>
            </ul>
          </div>
        </div>
        <div class="col-md-4 mb-2">
          <div class="ps-0 ps-md-5">
            <h3 class="pb-3 comansubhead">Contact us <span  >To know more</span></h3>
            <p>Additionally, there are ten executives working alongside them in various capacities. To enhance online reach and connectivity with all members, we have set up an email address at </p>
          </div>
        </div>
      </div>
      <div class="commanheadsec allwhitehd text-center mb-4">
        <h2 class="comanhead  mb-3">Join <span class="d-inline-block">Us</span></h2>
        <p>We now respectfully propose that all who have studied or conducted research here become lifetime members of our prestigious alumni club.All you have to do is click on the provided link, enter the required information, and pay a one-time membership fee of Rs. 1000/- (or $/£/€ 30 for NRIs) through our secure online payment platform. This process should take no longer than five minutes. If you have any questions or require any assistance, please contact us via email. </p>
      </div>
      <div class="row justify-content-center pt-2">
        <div class="col-md-8">
          <div class="pe-0 pe-md-5 ">
            <h3 class="comansubhead pb-3">Alumni <span >Community</span></h3>
            <p>Our alumni community boasts an impressive list of accomplished individuals such as Justice Pankaj Mittal from the Supreme Court; Justice Vivek Chaudhry and Justice Krishna Pahal from the Allahabad High Court; Mr Ajit Dobhal - NSA; Dr Hariom Panwar - Renowned Poet; Mr Satpal Malik - Former Governor; Mr Amit Agarwal - MLA; Mr Jagat Singh - Ex MLC; Mr Praveen - Cricketer representing India at the Kerala Cricket Team, and many others serving as ADJs (Additional District Judges), PCSJs (Provincial Civil Service-Judicial), Scientists, Authors, Teachers, Philanthropists, Advocates</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="ps-0 ps-md-5">
            <h3 class="comansubhead  pb-3">Downloadable <span  >Links</span></h3>
          </div>
        </div>
      </div>
    </div>
    <div class="commanheadsec allwhitehd text-center mb-4 pt-5">
      <h2 class="comanhead  mb-3">Gallery</h2>
    </div>
    <div class="ourgallerys owl-carousel mb-4">
      <div class="item">
        <div class="ourgallery"><img src="{{url('assets/front_assets/assets/images/history-member-1.jpg')}}" width="700" height="727" alt="" class="img-fluid w-100"></div>
        <div class="ourgallery"><img src="{{url('assets/front_assets/assets/images/history-member-1.jpg')}}" width="700" height="727" alt="" class="img-fluid w-100"></div>
      </div>
      <div class="item">
        <div class="ourgallery"><img src="{{url('assets/front_assets/assets/images/history-member-1.jpg')}}" width="700" height="727" alt="" class="img-fluid w-100"></div>
        <div class="ourgallery"><img src="{{url('assets/front_assets/assets/images/history-member-1.jpg')}}" width="700" height="727" alt="" class="img-fluid w-100"></div>
      </div>
      <div class="item">
        <div class="ourgallery"><img src="{{url('assets/front_assets/assets/images/history-member-1.jpg')}}" width="700" height="727" alt="" class="img-fluid w-100"></div>
        <div class="ourgallery"><img src="{{url('assets/front_assets/assets/images/history-member-1.jpg')}}" width="700" height="727" alt="" class="img-fluid w-100"></div>
      </div>
      <div class="item">
        <div class="ourgallery"><img src="{{url('assets/front_assets/assets/images/history-member-1.jpg')}}" width="700" height="727" alt="" class="img-fluid w-100"></div>
        <div class="ourgallery"><img src="{{url('assets/front_assets/assets/images/history-member-1.jpg')}}" width="700" height="727" alt="" class="img-fluid w-100"></div>
      </div>
      <div class="item">
        <div class="ourgallery"><img src="{{url('assets/front_assets/assets/images/history-member-1.jpg')}}" width="700" height="727" alt="" class="img-fluid w-100"></div>
        <div class="ourgallery"><img src="{{url('assets/front_assets/assets/images/history-member-1.jpg')}}" width="700" height="727" alt="" class="img-fluid w-100"></div>
      </div>
      <div class="item">
        <div class="ourgallery"><img src="{{url('assets/front_assets/assets/images/history-member-1.jpg')}}" width="700" height="727" alt="" class="img-fluid w-100"></div>
        <div class="ourgallery"><img src="{{url('assets/front_assets/assets/images/history-member-1.jpg')}}" width="700" height="727" alt="" class="img-fluid w-100"></div>
      </div>
    </div>
  </div>
</section>
<?php } else {?>
<?=$breadcrumb?>
<div id="rs-about" class="rs-about pt-30 pb-30 md-pt-70 md-pb-40">
  <div class="container">
    <div class="row y-middle">
      <div class="col-lg-12 pl-70 md-pl-15">
        <div class="sec-title6 mb-45 md-mb-30">
          <h2 class="title"></span></h2>
          <?=$description?>
          <?=$custom_data?>
        </div>
      </div>
    </div>
  </div>
</div>
<?php } ?>
@endsection