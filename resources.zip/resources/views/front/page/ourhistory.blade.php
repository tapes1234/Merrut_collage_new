@extends('front.layout.layout')
@section('content')
<section class="maininnersec" style=" background:url({{url('assets/front_assets/assets/images/our_history_bg.jpg')}}) no-repeat center top; background-size:cover" >
  <div class="container" >
    <div class="maininnerchilld d-flex align-items-center">
      <div class="commanheadsec  allwhitehd">
        <h2 class="innersubHD  mb-1">
          <?=webdata('about_title')?>
        </h2>
        <p>We fit an impressive array of activities onto our small campus and the city of Meerut. The only thing you must fear is ... "missing out". Explore your worth with Meerut College. Meerut College has all you'd expect from a top-tier college.</p>
      </div>
    </div>
  </div>
</section>
<?php if($getPageMenus = getPageMenu($posstion='top')) { ?>
<section class="quickbutton" >
  <div class="quickbuttoninner" > 
                <?php foreach($getPageMenus as $getCMs) { ?>
               <a  href="<?=url($getCMs['slug'])?>" <?php if($getCMs['slug']== 'our-history'){ echo " class='quactive'";} ?>>
                  <?=$getCMs['title']?>
                  </a>
                  <?php } ?>
                  </div>
</section><?php } ?>
<section class="commanspace">
  <div class="container" >
    <div class="row">
      <div class="col-md-6 mb-4">
        <div class="commanheadsec alldarkhd">
          <h2 class="comanhead  mb-4">
            <?=webdata('our_vission_description')?>
          </h2>
          <?=webdata('about_description')?>
        </div>
      </div>
      <div class="col-md-6 mb-4">
        <?php if($banners) { ?>
        <div class="ourtestimonakls owl-carousel fullsliderss">
          <?php foreach($banners as $banner) { ?>
          <div class="item"> <img src="<?=resizeimg($banner->image,700,727,false)?>" width="700" height="727"   alt="<?=$banner->title?>" loading="lazy" class="img-fluid w-100"> </div>
          <?php } ?>
        </div>
        <?php } ?>
      </div>
    </div>
  </div>
</section>
<section class="pt-5 pt-md-5 darkred_bg">
  <div class="container-fluid" >
    <div class="row ">
      <div class="col-md-6 mb-4 mb-md-3	"> <img src="<?=resizeimg(webdata('goals_and_vission_page_file'),701,728,false)?>" width="701" height="728"   alt="" loading="lazy" class="img-fluid w-100"> </div>
      <div class="col-md-6 mb-3">
        <div class="commanheadsec allwhitehd ps-0 ps-md-4">
          <h2 class="comanhead  mb-4">
            <?=webdata('goals_and_vission_description')?>
          </h2>
          <?=webdata('about_data')?>
        </div>
      </div>
    </div>
  </div>
</section>

<!---


<?=$breadcrumb?>
<section class="dropex-section about-section">
	<div class="container">
		<div class="row align-items-center justify-content-center">
			<div class="col-lg-7 col-md-12 col-12">
				<div class="wrap_about_section b-align-left">
					<?=webdata('about_description')?>
				</div>
			</div>
			<div class="col-lg-5 col-md-12 col-12 col-experienced">
				<div class="alllor-mjjru-left">
					<img src="<?=resizeimg(webdata('about_us_page_file'),500,400,false)?>">
				</div>
			</div>
		</div>
	</div>
</section>

<section class="dropex-section service-5-section">
	<div class="container">
		<div class="row row_fs_5">
			<div class="col-lg-6 col-md-12 col-12 col_simg">
				<div class="wrap_simg_5">
					
				</div>
			</div>
			<div class="col-lg-6 col-md-12 col-12">
				<div class="wrap_scontent_5">
					<?=webdata('goals_and_vission_description')?>
				</div>
			</div>
		</div>
		<div class="row row_fs_5 right_img">
			<div class="col-lg-6 col-md-12 col-12">
				<div class="wrap_scontent_5">
					<?=webdata('our_vission_description')?>
				</div>
			</div>
			<div class="col-lg-6 col-md-12 col-12 col_simg">
				<div class="wrap_simg_5">
					<img src="<?=resizeimg(webdata('our_vission_page_file'),1200,800,false)?>">
				</div>
			</div>
		</div>
		<div class="row row_fs_5">
			<div class="col-lg-6 col-md-12 col-12 col_simg">
				<div class="wrap_simg_5">
					<img src="<?=resizeimg(webdata('our_mission_page_file'),1200,800,false)?>">
				</div>
			</div>
			<div class="col-lg-6 col-md-12 col-12">
				<div class="wrap_scontent_5">
					<?=webdata('our_mission_description')?>
				</div>
			</div>
		</div>
    
   </div>
</section>---> 

@endsection