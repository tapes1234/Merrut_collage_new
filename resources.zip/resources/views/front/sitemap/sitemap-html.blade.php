@extends('front.layout.layout')
@section('content')
<?=$breadcrumb?>
<section class="tc-about-about pd-ennnd">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-sm-12 mb-3">
				<h2><u>Quick Links</u></h2>
			</div>
			<?php if($allSitemapLinks['custom']) { ?>
				<?php foreach($allSitemapLinks['custom'] as $custom) { ?>
					<div class="col-sm-3">
						<div class="border border-secondary m-2 p-2">
							<a href="<?=$custom['href']?>" >
								<?=$custom['text']?>
							</a>
						</div>
					</div>
				<?php } ?>
			<?php } ?>
		</div>	
		<div class="row align-items-center mt-5">
			<div class="col-sm-12 mb-3">
				<h2><u>Blog Category</u></h2>
			</div>
			<?php if($allSitemapLinks['blog_category']) { ?>
				<?php foreach($allSitemapLinks['blog_category'] as $blog_category) { ?>
					<div class="col-sm-4">
						<div class="border border-secondary m-2 p-2">
							<a href="<?=url('category/'.$blog_category['slug'])?>" >
								<?=$blog_category['title']?>
							</a>
						</div>
					</div>
				<?php } ?>
			<?php } ?>
		</div>	
		
		<div class="row align-items-center mt-5">
			<div class="col-sm-12 mb-3">
				<h2><u>Blogs</u></h2>
			</div>
			<?php if($allSitemapLinks['blogs']) { ?>
				<?php foreach($allSitemapLinks['blogs'] as $blog) { ?>
					<div class="col-sm-6">
						<div class="border border-secondary m-2 p-2">
							<a href="<?=url('blog/'.$blog['slug'])?>" >
								<?=$blog['title']?>
							</a>
						</div>
					</div>
				<?php } ?>
			<?php } ?>
		</div>	
		
		<div class="row align-items-center mt-5">
			<div class="col-sm-12 mb-3">
				<h2><u>Informations</u></h2>
			</div>
			<?php if($allSitemapLinks['pages']) { ?>
				<?php foreach($allSitemapLinks['pages'] as $pages) { ?>
					<div class="col-sm-6">
						<div class="border border-secondary m-2 p-2">
							<a href="<?=url($pages['slug'])?>" >
								<?=$pages['title']?>
							</a>
						</div>
					</div>
				<?php } ?>
			<?php } ?>
		</div>
		
	</div>
</section>

       


@endsection