
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">

	<?php if($allSitemapLinks['custom']) { ?>
		<?php foreach($allSitemapLinks['custom'] as $custom) { ?>
			<url>
				<loc><?=$custom['href']?></loc>
				<changefreq>weekly</changefreq>
				<priority>0.8</priority>
			</url>
		<?php } ?>
	<?php } ?>	
	
	<?php if($allSitemapLinks['blog_category']) { ?>
		<?php foreach($allSitemapLinks['blog_category'] as $blog_category) { ?>
			<url>
				<loc><?=url('category/'.$blog_category['slug'])?></loc>
				<changefreq>weekly</changefreq>
				<priority>0.8</priority>
			</url>
		<?php } ?>
	<?php } ?>
	
	<?php if($allSitemapLinks['blogs']) { ?>
		<?php foreach($allSitemapLinks['blogs'] as $blogs) { ?>
			<url>
				<loc><?=url('blog/'.$blogs['slug'])?></loc>
				<changefreq>weekly</changefreq>
				<priority>0.8</priority>
			</url>
		<?php } ?>
	<?php } ?>
	<?php if($allSitemapLinks['pages']) { ?>
		<?php foreach($allSitemapLinks['pages'] as $pages) { ?>
			<url>
				<loc><?=url($pages['slug'])?></loc>
				<changefreq>weekly</changefreq>
				<priority>0.8</priority>
			</url>
		<?php } ?>
	<?php } ?>

</urlset>