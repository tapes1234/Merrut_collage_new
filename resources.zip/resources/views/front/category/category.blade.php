@extends('front.layout.layout')
@section('content')
<?php //echo $breadcrumb?>
@include('front.category.slider')
<section class="maininnersec" style=" background:url({{url('assets/front_assets/assets/images/faculty_bg.jpg')}}) no-repeat center top; background-size:cover" >
  <div class="container" >
    <div class="maininnerchilld d-flex align-items-center">
      <div class="commanheadsec  allwhitehd">
        <h1 class="innersubHD  mb-1">
          <?=$heading?>
        </h1>
        
      </div>
    </div>
  </div>
</section>
<?php if($getResults) { ?>
<section class="quickbutton" >
  <div class="quickbuttoninner" >
    <?php foreach($getResults as $result) { ?>
    <a href="<?=url($result['cattype']."/".$result['slug'])?>">
    <?=$result['title']?>
    </a>
   
    <?php } ?>
  </div>
</section>
<?php } ?>

  
<section class="commanspace">
  <div class="container" >
    <div class="row">
    
    
     <?php foreach($allproducts as $allproduct) { ?>
     
     
     <div class="col-md-4 col-sm-6  mb-3 mb-md-5">
        <div class="hw_artical">
        <a href="<?=url("product/".$allproduct['slug'])?>">
          <div class="hw_artical_head">
            <div class="hw_artical_head_icon"><img src="assets/images/hs-icon-1.svg" class="img-fluid"   alt="" loading="lazy"></div>
            <h3><?=$allproduct['name']?></h3>
          </div></a>
          
          <div class="hw_artical_content">
            <p>The Bachelor of Arts in Sociology is a three-year undergraduate curriculum designed to help students understand how social structures, human relationships, and individual behavior shape civilizations and cultures. The program introduces students to a sociological perspective, a specific way of viewing the world, its societies, and the changes that occur. </p>
          </div>
        </div>
        <div></div>
      </div>
     
     
     
     
     
  
  
  <?php } ?>
    
    
    
      
    </div>
  </div>
</section>











<!---

<section class="spesification">
  <div class="container">
    <div class="row">
      <div class="col-md-3">
        <div class="anhhheygdgte"> <img src="<?=isset($allwebdata['category_column_1_page_file']) ? resizeimg($allwebdata['category_column_1_page_file'],100,100,false) : resizeimg('no_image.jpg',100,100,false)?>" />
          <h2>
            <?=isset($allwebdata['category_column_1_title']) ? $allwebdata['category_column_1_title'] : '' ?>
          </h2>
        </div>
      </div>
      <div class="col-md-3">
        <div class="anhhheygdgte"> <img src="<?=isset($allwebdata['category_column_2_page_file']) ? resizeimg($allwebdata['category_column_2_page_file'],100,100,false) : resizeimg('no_image.jpg',100,100,false)?>" />
          <h2>
            <?=isset($allwebdata['category_column_2_title']) ? $allwebdata['category_column_2_title'] : '' ?>
          </h2>
        </div>
      </div>
      <div class="col-md-3">
        <div class="anhhheygdgte"> <img src="<?=isset($allwebdata['category_column_3_page_file']) ? resizeimg($allwebdata['category_column_3_page_file'],100,100,false) : resizeimg('no_image.jpg',100,100,false)?>" />
          <h2>
            <?=isset($allwebdata['category_column_3_title']) ? $allwebdata['category_column_3_title'] : '' ?>
          </h2>
        </div>
      </div>
      <div class="col-md-3">
        <div class="anhhheygdgte"> <img src="<?=isset($allwebdata['category_column_4_page_file']) ? resizeimg($allwebdata['category_column_4_page_file'],100,100,false) : resizeimg('no_image.jpg',100,100,false)?>" />
          <h2>
            <?=isset($allwebdata['category_column_4_title']) ? $allwebdata['category_column_4_title'] : '' ?>
          </h2>
        </div>
      </div>
    </div>
  </div>
</section>
<?php if($getResults) { ?>
<section class="bottomnshfey">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="mkkksdjweruu">
          <h1>Our Product Range</h1>
        </div>
      </div>
    </div>
    <div class="row">
      <?php foreach($getResults as $result) { ?>
      <div class="col-md-4">
        <div class="item jjfg-yyyr">
          <div class="top-image-jjjsy"> <img src="<?=resizeimg($result['image'],600,400,false)?>" alt="<?=$result['title']?>" title="<?=$result['title']?>" class="scale-imf-uue"> </div>
          <div class="bottom-dat-hhhsg">
            <h2>
              <?=$result['title']?>
            </h2>
            <button class="kkkks-nwehwy">
            <a href="<?=createCategoryUrl($result['slug'])?>">Shop Now</a>
            </button>
          </div>
        </div>
      </div>
      <?php } ?>
    </div>
  </div>
</section>
<?php } ?>
<section class="product-serd-njjd new-bac-kkksur">
  <div class="container">
    <div class="row">
      <div class=" col-md-6"> <img src="<?=resizeimg($allwebdata['category_page_file'],1000,1000,false)?>" > </div>
      <div class=" col-md-6">
        <div class="main-koooei">
          <?=isset($allwebdata['catetgory_description']) ? $allwebdata['catetgory_description'] : '' ?>
        </div>
      </div>
    </div>
  </div>
</section>--->
@endsection