@extends('front.layout.layout')
@section('content')
<?php //echo $breadcrumb?>
@include('front.category.slider')
<section class="maininnersec" style=" background:url({{url('assets/front_assets/assets/images/faculty_bg.jpg')}}) no-repeat center top; background-size:cover" >
  <div class="container" >
    <div class="maininnerchilld d-flex align-items-center">
      <div class="commanheadsec  allwhitehd">
        <h1 class="innersubHD  mb-1"><?=$heading?> </h1>
		 <?=$short_description?>
      </div>
    </div>
  </div>
</section>

<section class="commanspace">
  <div class="container" >
    <div class="row">
    
    
     <?php foreach($allproducts as $allproduct) { ?>
     
     
     <div class="col-md-4 col-sm-6  mb-3 mb-md-5">
        <div class="hw_artical">
        <a href="<?=url("product/".$allproduct['slug'])?>">
          <div class="hw_artical_head">
            <div class="hw_artical_head_icon"><img src="assets/images/hs-icon-1.svg" class="img-fluid"   alt="" loading="lazy"></div>
            <h3><?=$allproduct['name']?></h3>
          </div></a>
          
          <div class="hw_artical_content">
            <p>The Bachelor of Arts in Sociology is a three-year undergraduate curriculum designed to help students understand how social structures, human relationships, and individual behavior shape civilizations and cultures. The program introduces students to a sociological perspective, a specific way of viewing the world, its societies, and the changes that occur. </p>
          </div>
        </div>
        <div></div>
      </div>
     
     
     
     
     
  
  
  <?php } ?>
    
    
    
      
    </div>
  </div>
</section>






<!----


<section class="spesification">
	<div class="container">
		<div class="row">
			<div class="col-md-3">
				<div class="anhhheygdgte">
					<img src="<?=isset($allwebdata['category_column_1_page_file']) ? resizeimg($allwebdata['category_column_1_page_file'],100,100,false) : resizeimg('no_image.jpg',100,100,false)?>" />
				   <h2><?=isset($allwebdata['category_column_1_title']) ? $allwebdata['category_column_1_title'] : '' ?></h2>
				</div>
			</div>
			<div class="col-md-3">
				<div class="anhhheygdgte">
					<img src="<?=isset($allwebdata['category_column_2_page_file']) ? resizeimg($allwebdata['category_column_2_page_file'],100,100,false) : resizeimg('no_image.jpg',100,100,false)?>" />
				  <h2><?=isset($allwebdata['category_column_2_title']) ? $allwebdata['category_column_2_title'] : '' ?></h2>
				</div>
			</div>		
			<div class="col-md-3">
				<div class="anhhheygdgte">
					<img src="<?=isset($allwebdata['category_column_3_page_file']) ? resizeimg($allwebdata['category_column_3_page_file'],100,100,false) : resizeimg('no_image.jpg',100,100,false)?>" />
				   <h2><?=isset($allwebdata['category_column_3_title']) ? $allwebdata['category_column_3_title'] : '' ?></h2>
				</div>
			</div>		
			<div class="col-md-3">
				<div class="anhhheygdgte">
					<img src="<?=isset($allwebdata['category_column_4_page_file']) ? resizeimg($allwebdata['category_column_4_page_file'],100,100,false) : resizeimg('no_image.jpg',100,100,false)?>" />
				   <h2><?=isset($allwebdata['category_column_4_title']) ? $allwebdata['category_column_4_title'] : '' ?></h2>
				</div>
			</div>
		</div>
	</div>
</section>


    

<section class="new-product-detail">
    <div class="container">
        <div class="row">
            
			<div class="col-md-6">
				<?php 	 if($image && (file_exists(public_path().$image))){ ?>
					<div id="a1" class="tabcontent">
						<a class="z-mines" data-fancybox="gallery" href="<?=resizeimg($image,600,400,false)?>"><img  src="<?=resizeimg($image,600,400,false)?>" alt="<?=$title?>"  title="<?=$title?>"></a> 
					</div>
				<?php } ?>
			
				
				<?php 	 if($image1 && (file_exists(public_path().$image1))){ ?>
					<div id="a2" class="tabcontent">
						<a class="z-mines" data-fancybox="gallery" href="<?=resizeimg($image1,600,400,false)?>"><img src="<?=resizeimg($image1,600,400,false)?>" alt="<?=$title?>"  title="<?=$title?>"></a> 
					</div>
				<?php } ?>
				
				<?php 	 if($image2 && (file_exists(public_path().$image2))){ ?>
					<div id="a3" class="tabcontent">
						<a class="z-mines" data-fancybox="gallery" href="<?=resizeimg($image2,600,400,false)?>"><img src="<?=resizeimg($image2,600,400,false)?>" alt="<?=$title?>"  title="<?=$title?>"></a> 
					</div>
				<?php } ?>	
				
				<?php 	 if($image3 && (file_exists(public_path().$image3))){ ?>
					<div id="a4" class="tabcontent">
						<a class="z-mines" data-fancybox="gallery" href="<?=resizeimg($image3,600,400,false)?>"><img src="<?=resizeimg($image3,600,400,false)?>" alt="<?=$title?>"  title="<?=$title?>"></a> 
					</div>
				<?php } ?>

				<?php 	 if($image4 && (file_exists(public_path().$image4))){ ?>
						<div id="a5" class="tabcontent">
						<a class="z-mines" data-fancybox="gallery" href="<?=resizeimg($image4,600,400,false)?>"><img src="<?=resizeimg($image4,600,400,false)?>" alt="<?=$title?>"  title="<?=$title?>"></a> 
					</div>
				<?php } ?>

				<?php 	 if($image5 && (file_exists(public_path().$image5))){ ?>
						<div id="a6" class="tabcontent">
						<a class="z-mines" data-fancybox="gallery" href="<?=resizeimg($image5,600,400,false)?>"><img src="<?=resizeimg($image5,600,400,false)?>" alt="<?=$title?>"  title="<?=$title?>"></a> 
					</div>
				<?php } ?>


				<div class="tabnjjjjdh">
					<ul>
						<?php if($image && (file_exists(public_path().$image))){ ?>
						<li class="tablinks" onclick="openCity(event, 'a1')" id="defaultOpen">
							<img  src="<?=resizeimg($image,600,400,false)?>" alt="<?=$title?>"  title="<?=$title?>" width="100%">   
						</li>
						<?php } ?>
						
						<?php if($image1 && (file_exists(public_path().$image1))){ ?>
						<li class="tablinks" onclick="openCity(event, 'a2')" id="defaultOpen">
							<img  src="<?=resizeimg($image1,600,400,false)?>" alt="<?=$title?>"  title="<?=$title?>" width="100%">   
						</li>
						<?php } ?>	
						
						<?php if($image2 && (file_exists(public_path().$image2))){ ?>
						<li class="tablinks" onclick="openCity(event, 'a3')" id="defaultOpen">
							<img  src="<?=resizeimg($image2,600,400,false)?>" alt="<?=$title?>"  title="<?=$title?>" width="100%">   
						</li>
						<?php } ?>	
						
						<?php if($image3 && (file_exists(public_path().$image3))){ ?>
						<li class="tablinks" onclick="openCity(event, 'a4')" id="defaultOpen">
							<img  src="<?=resizeimg($image3,600,400,false)?>" alt="<?=$title?>"  title="<?=$title?>" width="100%">   
						</li>
						<?php } ?>	
						
						<?php if($image4 && (file_exists(public_path().$image4))){ ?>
						<li class="tablinks" onclick="openCity(event, 'a5')" id="defaultOpen">
							<img  src="<?=resizeimg($image4,600,400,false)?>" alt="<?=$title?>"  title="<?=$title?>" width="100%">   
						</li>
						<?php } ?>

						<?php if($image5 && (file_exists(public_path().$image5))){ ?>
						<li class="tablinks" onclick="openCity(event, 'a6')" id="defaultOpen">
							<img  src="<?=resizeimg($image5,600,400,false)?>" alt="<?=$title?>"  title="<?=$title?>" width="100%">   
						</li>
						<?php } ?>
			
					
					</ul>
				</div>
			</div>

			<div class="col-md-6">
				<div class="bnthnsdu">
					<h1>
					<button class="kkkks-nwehwy" data-toggle="modal" data-target="#myModal">Buy Now</button>
				</div>
			</div>
        </div>
    </div>
</section>


<section class="new-product-dspyrnjjf">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="njjdfhsyfuw-jsjq"><?=$custom_data?></div>
			</div>
		</div>
	</div>
</section>


<div class="modal" id="myModal">
    <div class="modal-dialog">
        <div class="modal-content njjdur-mkkksuur">
            <div class="modal-header new-co-mnjkjkjks">
              <h4 class="modal-title md-njjd"> Inquery Form</h4>
              <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
               @include('front.form.enquiry')
            </div>
        </div>
    </div>
</div>
<section class="product-serd-njjd new-bac-kkksur">
	<div class="container">
		<div class="row">
			<div class=" col-md-6">
				<img src="<?=resizeimg($allwebdata['category_page_file'],1000,1000,false)?>" >
			</div>
			  
			<div class=" col-md-6">
				<div class="main-koooei">
					<?=isset($allwebdata['catetgory_description']) ? $allwebdata['catetgory_description'] : '' ?>
				</div>
			</div>
		</div>
	</div>
</section>



<script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}
// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>--->
@endsection