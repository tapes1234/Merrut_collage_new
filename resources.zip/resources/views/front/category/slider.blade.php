<?php if($banners) { ?>
<section class="dropex-slider dropex-slider-6">
	<div class="owl-carousel r_slider" data-dots="off">
		<?php foreach($banners as $banner) { ?>
		<div class="r_wrap_slider r_wrap_slider_6">
			<div class="r_slider_img kenburn-scale" style="background-image:url(<?=resizeimg($banner->image,1366,566,false)?>)"></div>
			<div class="r-slider-container r-slider-container-6">
				<div class="r-slider-conten r-slider-conten-6">
					<h1 class="slider-title-6 tp_animate_when_visible zoom-out" data-speed="300"><?=$banner->title?></h1>
					<p class="tp_animate_when_visible zoom-out" data-delay="600" data-speed="300"><?=$banner->heading?></p>
					<?php if($banner->link) { ?>
						<a href="<?=$banner->heading?>" class="slider-btn get-qoute tp_animate_when_visible zoom-in" >Contact Us</a>
					<?php } ?>
				</div>
			</div>
		</div>
		<?php } ?>
	</div>
</section>
<?php } ?>