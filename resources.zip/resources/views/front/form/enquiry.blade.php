<form class="tp-form-1" id="contact-form" method="post" >
@csrf
	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-12">
			<p class="tp-form-el">
				<input type="text" name="name" id="tp-username" class="tp-feild tp-user-name" placeholder="Full Name *">
				<span class="formerror text-danger" id="name_err"></span>
			</p>
		</div>
		<div class="col-lg-12 col-md-6 col-sm-6 col-12 ">
			<p class="tp-form-el">
				<input type="text" id="phone" name="phone" class="tp-feild tp-phone" placeholder="Your Phone *">
				<span class="formerror text-danger" id="phone_err"></span>
			</p>
		</div> 
		<div class="col-lg-12 col-md-6 col-sm-6 col-12 ">
			<p class="tp-form-el">
				<input type="text" id="email" name="email" class="tp-feild tp-email" placeholder="Your Email *">
				<span class="formerror text-danger" id="email_err"></span>
			</p>
		</div>
		<div class="col-12">
			<p class="tp-form-el">
				<textarea name="message" class="tp-message" placeholder="Write Your Message *."></textarea>
				<span class="formerror text-danger" id="message_err"></span>
			</p>
		</div>
		<div class="col-12 ">
			<div id="response_message"></div>
			<div class="tp-wrap-btn">
				<button type="submit" id="formsubmitbtn" class="sendmessage_btn dropex-btn" id="tp-submit">Request A Qoute</button> <span id="mess_respon"></span>
			</div>
		</div>
	</div>
</form>


<script type="text/javascript">
	$('#contact-form').submit(function(e) {
		$('#formsubmitbtn').html('Processing...');
		document.getElementById("formsubmitbtn").disabled = true; 
        e.preventDefault();
		$('.formerror').empty();
        let formData = new FormData(this);
        $.ajax({
            type:'POST',
            url: '<?php echo url('contactform')?>',
            data: formData,
			contentType: false,
			processData: false,
			success: (response) => {
				
				if(response['status'] === false){
						for(i in response['errors']){
							var elements  = i+'_err';
							document.getElementById(elements).innerHTML = response['errors'][i]; 
						}
				}
				
				if(response['status'] === true){
					if(response['type'] == 'success'){
						reseponse_mes = '<span class="alert alert-success">'+response['message']+'</span><br>';
						document.getElementById("contact-form").reset();
					}else{
						reseponse_mes = '<span class="alert alert-danger">'+response['message']+'</span><br>';
					}
					$('#response_message').html(reseponse_mes);
				}

				$('#formsubmitbtn').html('Request A Qoute');
				document.getElementById("formsubmitbtn").disabled = false; 
				
			},
			
			
		});
    });
</script>

