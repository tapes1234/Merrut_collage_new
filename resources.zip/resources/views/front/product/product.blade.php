@extends('front.layout.layout')
@section('content')
<?=$breadcrumb?>
<section class="dropex-section services-3-section" style="background-color: #f1faff !important;">
	<div class="container">
		<div class="row row-services-3 bnjjdhyrvbhf">
			<?php if($results) { ?>
				<?php foreach($results as $result) { ?>
					<div class="col-lg-4 col-md-6 col-sm-6 col-12">
						<div class="wrap_service_3 snjjfutyhg-border-mkkdi">
							<div class="alk-im">
							   <a href="<?=createProductUrl($result['slug'])?>"><img src="<?=resizeimg($result['image'],500,360,false)?>" alt="<?=$result['name']?>" alt="<?=$result['name']?>"></a>
							</div>
							<div class="service_text new-bghd-co">
								<h3><a class="text-dark" href="<?=createProductUrl($result['slug'])?>"><?=$result['name']?></a></h3>
								<?=$result['short_description']?>
								<button class="fbnnvhuryhf"><a style="color: #fff;" href="<?=createProductUrl($result['slug'])?>">Read More</a></button>
							</div>
						</div>
					</div> 
				<?php } ?>
				
			<?php } else { ?>
				<div class="col-lg-4 col-md-6 col-sm-6 col-12">
					<h3>Data Not Found</h3>
				</div> 
			<?php } ?>
			
			
		</div>
	</div>
</section>



@endsection