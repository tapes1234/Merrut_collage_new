@extends('front.layout.layout')
@section('content')
<!--<?=$breadcrumb?>-->
<section class="maininnersec" style=" background:url({{url('assets/front_assets/assets/images/faculty_bg.jpg')}}) no-repeat center top; background-size:cover" >

  <div class="container" >
    <div class="maininnerchilld d-flex align-items-center">
      <div class="commanheadsec  allwhitehd">
        <h2 class="innersubHD  mb-1"><?=$name?> </h2>
        <p>Meerut's alumni — entrepreneurs, researchers, policymakers, and above all, leaders — have helped to shape the world we know today.</p>
      </div>
    </div>
  </div>
</section>
<section class="quickbutton" >
  <div class="quickbuttoninner" > <a href="our-history.php"  >Our History</a><a href="legacy.php" >Legasy</a><a href="#" >Officials</a><a href="alumni.php" class="quactive" >Alumni</a><a href="#" >Publication</a></div>
</section>
<section class="commanspace">
  <div class="container" >
    <div class="commanheadsec alldarkhd text-center mb-5">
      <h2 class="comanhead  mb-4"> B.A <span class="d-inline-block">Sociology</span></h2>
      <p>The Bachelor of Arts in Sociology is a three-year undergraduate curriculum designed to help students understand how social structures, human relationships, and individual behavior shape civilizations and cultures. The program introduces students to a sociological perspective, a specific way of viewing the world, its societies, and the changes that occur. Throughout the programme, students participate in analytical discussions and research of various socio economic groupings. Along with regular lessons, guest lecturers, and field trips, students gain a global perspective through study abroad experiences and internships.</p>
      <p>The program's core subjects include applied sociology, comparative sociology, cultural sociology, collective behavior, crime and delinquency, community, and demography. The curriculum seeks to provide a thorough introduction to sociology and its fundamental principles. Students are exposed to a variety of sociological views in order to develop the abilities required to analyze the many social processes in a given setting.</p>
    </div>
    <div class="row">
      <div class="col-lg-6 mb-3">
        <div class="detableds">
          <table  class="w-100" >
            <tr>
              <td colspan="2" class="text-center"><h4>Eligibility <span class="darkred">criteria</span></h4></td>
            </tr>
            <tr>
              <td width="50%" class="text-dark">For National Students</td>
              <td width="50%">Sr. Secondary (10+2) with minimum 50% marks.</td>
            </tr>
            <tr>
              <td class="text-dark">No. of Seats</td>
              <td>40 Seats ( 40% For Pwd, sC, St)</td>
            </tr>
          </table>
        </div>
      </div>
      <div class="col-lg-6 mb-3">
        <div class="detableds">
          <table  class="w-100 text-center" >
            <tr>
              <td colspan="2" ><h4>Semester <span class="darkred">Syllabus</span></h4></td>
            </tr>
            <tr>
              <td width="50%"><p>Lörem ipsum tydolig lönade. Saren gigarade löngar svenna sitt liv paratt. Ysade trafadelöngar svenna sitt liv paratt. Ysade trafade. Hemigt snålsurfa eurogisk som airbaghjälm stödkorv. Dir flipperförälder. Du kan varaeurogisk som airbaghjälm stödkorv. Dir flipperförälder. Du kan vara</p></td>
            </tr>
          </table>
        </div>
      </div>
    </div>
  </div>
</section>
<section class=" commanspace commanheadsec darkred_bg">
  <div class="container-fluid">
    <h2 class="comanhead mb-4 fw-bold text-white">Notable <span class="d-inline-block" >Alumni</span></h2>
    <div class="notablealumnislider owl-carousel ">
      <div class="item p-1">
        <div class="notablecard">
          <div class="notablecard-thumb"><img src="assets/images/history-member-1.jpg" width="700" height="727"   alt="" loading="lazy" class="img-fluid w-100"></div>
          <div class="notablecard-content">
            <h6>Late CH. Charan Singh </h6>
            <p>Ex - Prime Minister Of India</p>
          </div>
        </div>
      </div>
      <div class="item p-1">
        <div class="notablecard">
          <div class="notablecard-thumb"><img src="assets/images/history-member-1.jpg" width="700" height="727"   alt="" loading="lazy" class="img-fluid w-100"></div>
          <div class="notablecard-content">
            <h6>Late CH. Charan Singh </h6>
            <p>Ex - Prime Minister Of India</p>
          </div>
        </div>
      </div>
      <div class="item p-1">
        <div class="notablecard">
          <div class="notablecard-thumb"><img src="assets/images/history-member-1.jpg" width="700" height="727"   alt="" loading="lazy" class="img-fluid w-100"></div>
          <div class="notablecard-content">
            <h6>Late CH. Charan Singh </h6>
            <p>Ex - Prime Minister Of India</p>
          </div>
        </div>
      </div>
      <div class="item p-1">
        <div class="notablecard">
          <div class="notablecard-thumb"><img src="assets/images/history-member-1.jpg" width="700" height="727"   alt="" loading="lazy" class="img-fluid w-100"></div>
          <div class="notablecard-content">
            <h6>Late CH. Charan Singh </h6>
            <p>Ex - Prime Minister Of India</p>
          </div>
        </div>
      </div>
      <div class="item p-1">
        <div class="notablecard">
          <div class="notablecard-thumb"><img src="assets/images/history-member-1.jpg" width="700" height="727"   alt="" loading="lazy" class="img-fluid w-100"></div>
          <div class="notablecard-content">
            <h6>Late CH. Charan Singh </h6>
            <p>Ex - Prime Minister Of India</p>
          </div>
        </div>
      </div>
      <div class="item p-1">
        <div class="notablecard">
          <div class="notablecard-thumb"><img src="assets/images/history-member-1.jpg" width="700" height="727"   alt="" loading="lazy" class="img-fluid w-100"></div>
          <div class="notablecard-content">
            <h6>Late CH. Charan Singh </h6>
            <p>Ex - Prime Minister Of India</p>
          </div>
        </div>
      </div>
      <div class="item p-1">
        <div class="notablecard">
          <div class="notablecard-thumb"><img src="assets/images/history-member-1.jpg" width="700" height="727"   alt="" loading="lazy" class="img-fluid w-100"></div>
          <div class="notablecard-content">
            <h6>Late CH. Charan Singh </h6>
            <p>Ex - Prime Minister Of India</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<section class=" commanspace  pb-0">
  <div class="container-fluid">
    <div class="commanheadsec alldarkhd">
      <h2 class="comanhead mb-4 fw-bold ">More <span class="d-inline-block" >Courses</span></h2>
    </div>
    <div class="row">
      <div class="col-md-4 col-sm-6  mb-3 mb-md-5">
        <div class="hw_artical">
          <div class="hw_artical_head">
            <div class="hw_artical_head_icon"><img src="assets/images/hs-icon-1.svg" class="img-fluid"   alt="" loading="lazy"></div>
            <h3>BA <span >Sociology</span></h3>
          </div>
        </div>
        <div></div>
      </div>
      <div class="col-md-4 col-sm-6  mb-3 mb-md-5">
        <div class="hw_artical">
          <div class="hw_artical_head">
            <div class="hw_artical_head_icon"><img src="assets/images/hs-icon-1.svg" class="img-fluid"   alt="" loading="lazy"></div>
            <h3>BA <span >Sociology</span></h3>
          </div>
        </div>
        <div></div>
      </div>
      <div class="col-md-4 col-sm-6  mb-3 mb-md-5">
        <div class="hw_artical">
          <div class="hw_artical_head">
            <div class="hw_artical_head_icon"><img src="assets/images/hs-icon-1.svg" class="img-fluid"   alt="" loading="lazy"></div>
            <h3>BA <span >Sociology</span></h3>
          </div>
        </div>
        <div></div>
      </div>
    </div>
  </div>
</section>





<!--
<section class="product-serd-njjd">
	<div class="container">
		<div class="row">
			<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
				<div class="single-blog-post-mkkkdir">
					<img src="<?=$image?>" alt="<?=$name?>"  title="<?=$name?>" width="100%">
				</div>
			</div>
      
			<div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
				<div class="main-koooei">
					<div class="title-holder-mkkkdiu">
						<h2></h2>
					</div>
					<div class="content-mkkkdi">
						<?=$description?>
						<button class="scdffsrew-njjsh-mkkksi" data-toggle="modal" data-target="#myModal">Enquire Now For Best Deals</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<div class="modal" id="myModal">
	<div class="modal-dialog">
		<div class="modal-content njjdur-mkkksuur">
			<div class="modal-header new-co-mnjkjkjks">
				<h4 class="modal-title md-njjd"> Enquiry Form</h4>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>
			<div class="modal-body">
				<div class="">
					@include('front.form.enquiry')
				</div>
			</div>
		</div>
	</div>
</div>-->

@endsection