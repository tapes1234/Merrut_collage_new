<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="content-type" content="text/html;charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title><?php echo $meta_title;?></title>
<meta name="robots" content="noindex,nofollow">
<meta name="keywords" content="<?=$meta_keyword?>">
<meta name="description" content="<?php echo $meta_description?>">
<?php if(webdata('favicon_file'))  {?>
<link rel="icon" href="<?php echo resizeimg(webdata('favicon_file'),64, 64,$aspectRatio=false)?>" type="image/x-icon">
<?php } ?>
<?php $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";?>
<link href="<?=$actual_link?>" rel="canonical" />

<!-- Facebook OpenGraph -->
<meta property="og:locale" content="en">
<meta property="og:url" content="<?=$actual_link?>">
<meta property="og:site_name" content="<?=webdata('webname')?>">
<meta property="og:title" content="<?php echo $meta_title;?>">
<meta property="og:description" content="<?php echo $meta_description?>">
<meta property="og:type" content="Article">
<meta property="og:image" content="<?php echo resizeimg($og_image,1200,630,$aspectRatio=false)?>">
<meta property="og:image" content="<?php echo resizeimg($og_image,1200,630,$aspectRatio=false)?>">
<meta property="og:image" content="<?php echo resizeimg($og_image,1200,630,$aspectRatio=false)?>">
<meta property="og:image" content="<?php echo resizeimg($og_image,1200,630,$aspectRatio=false)?>">
<meta property="og:image" content="<?php echo resizeimg($og_image,1200,630,$aspectRatio=false)?>">
<meta property="og:image:width" content="1200" />
<meta property="og:image:height" content="630" />
<!-- Twitter Card -->
<meta name="twitter:title" content="<?php echo $meta_title;?>">
<meta name="twitter:description" content="<?php echo $meta_description;?>">
<meta name="twitter:image" content="<?php echo resizeimg($og_image,1200, 630,$aspectRatio=false)?>">
<meta name="twitter:image:alt" content="<?php echo $meta_title;?>">
<base href="<?php echo url('/')?>">
<link rel="shortcut icon" href="{{url('assets/front_assets/assets/images/favicon.png')}}">
<link href="{{url('assets/front_assets/assets/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css" media="all">
<link href="{{url('assets/front_assets/assets/css/comman.css')}}" rel="stylesheet" type="text/css" media="all">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet preload" as="style" type="text/css" media="all" >
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<?php 
		echo getanalytics($position="Head",$select_path="All Page",$url=''); 
		$urlforscript = str_replace(url('/'),"",url()->current());
		echo getanalytics($position="Head",$select_path="Custom",$url=$urlforscript); 
	?>
</head>
<body>
<?php 
		echo getanalytics($position="Body",$select_path="All Page",$url=''); 
		$urlforscript = str_replace(url('/'),"",$actual_link);
		echo getanalytics($position="Body",$select_path="Custom",$url=$urlforscript); 
	?>
<div class="sidewarper d-block d-xl-none">
  <div id="slidesection">
    <div class="topclose "><a id="slide1" class="white  d-flex align-items-center justify-content-between"><strong>Merrut Collage</strong> <i class="fa-times fa "></i></a></div>
    <div class="overscroll">
      <div id="sidelinks">
        <ul class="mobilemenuu pt-4 accordion accordion-flush" id="accordionFlushExample">
          <li class="accordion-item">
            <div class="accordion-heading"  id="headingThree1"> <a  class="moblink">About us</a>
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree1" aria-expanded="false" > </button>
            </div>
            <div id="collapseThree1" class="accordion-collapse collapse"  data-bs-parent="#accordionFlushExample">
              <div class="accordion-body p-0">
                <ul class="p-0">
                  <li><a href="our-history.php" >Our History</a></li>
                  <li><a href="legacy.php" >Legasy</a></li>
                  <li><a href="#" >Officials</a></li>
                  <li><a href="alumni.php" >Alumni</a></li>
                </ul>
              </div>
            </div>
          </li>
          <li class="accordion-item">
            <div class="accordion-heading"  id="headingThree2"> <a class="moblink">ACADEMICS</a>
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree2" aria-expanded="false" > </button>
            </div>
            <div id="collapseThree2" class="accordion-collapse collapse"  data-bs-parent="#accordionFlushExample">
              <div class="accordion-body p-0">
                <ul class="p-0">
                  <li><a href="graduation.php" >Graduation</a></li>
                  <li><a href="#" >Post Graduation</a></li>
                  <li><a href="#" >Doctorate</a></li>
                  <li><a href="#" >Professional Co.</a></li>
                  <li><a href="#" >Vocational Co.</a></li>
                  <li><a href="#" >Scholarship</a></li>
                  <li><a href="#" >Faculty</a></li>
                  <li><a href="publication.php" >Publication</a></li>
                </ul>
              </div>
            </div>
          </li>
          <li class="accordion-item">
            <div class="accordion-heading"  id="headingThree3"> <a  class="moblink">BEYOND ACADEMICS</a>
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree3" aria-expanded="false" > </button>
            </div>
            <div id="collapseThree3" class="accordion-collapse collapse"  data-bs-parent="#accordionFlushExample">
              <div class="accordion-body p-0">
                <ul class="p-0">
                  <li><a href="#" >Students Corner</a></li>
                  <li><a href="#" >Committee</a></li>
                </ul>
              </div>
            </div>
          </li>
          <li class="accordion-item "><a href="#" class="moblink">Admission</a></li>
          <li class="accordion-item "><a href="#" class="moblink">CAREER</a></li>
          <li class="accordion-item">
            <div class="accordion-heading"  id="headingThree4"> <a class="moblink">LOG IN</a>
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree4" aria-expanded="false" > </button>
            </div>
            <div id="collapseThree4" class="accordion-collapse collapse"  data-bs-parent="#accordionFlushExample">
              <div class="accordion-body p-0">
                <ul class="p-0">
                  <li><a href="#" >Student</a></li>
                  <li><a href="#" >Teacher</a></li>
                </ul>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</div>
<header id="myHeader">
  <div class="container splpadd position-relative">
    <div class="d-flex  align-items-center justify-content-between">
      <div class="logo"> <a href="<?=url('/')?>"> <img src="<?=resizeimg(webdata('logo_file'),871,217,false)?>" alt="<?=webdata('webname')?>" title="<?=webdata('webname')?>" width="871" height="217"  class="img-fluid"> </a> </div>
      <div class=" align-items-center justify-content-end d-lg-flex d-none  ">
        <nav class=" mainloinks  ">
          <ul class="clearfix d-flex  align-items-center justify-content-between p-0 mainul mb-0">
            <li class="mainli miicons"><a href="#">About us<i class="fa-angle-down fa"></i></a>
              <ul class="p-0">
                <?php if($getPageMenus = getPageMenu($posstion='top')) { ?>
                <?php foreach($getPageMenus as $getCMs) { ?>
                <li ><a  href="<?=url($getCMs['slug'])?>">
                  <?=$getCMs['title']?>
                  </a>
                  <?php } ?>
                  <?php } ?>
              </ul>
            </li>
            <li class="mainli miicons"><a >ACADEMICS<i class="fa-angle-down fa"></i></a>
              <ul class="p-0">
                <?php if($getCategoryMenu = getCategoryMenu($posstion='top')) { ?>
                <?php foreach($getCategoryMenu as $getCMs) { ?>
                <?php if($getCMs['cattype']=='academics'){?>
                <li ><a  href="<?=url($getCMs['cattype']."/".$getCMs['slug'])?>">
                  <?=$getCMs['title']?>
                  </a>
                  <?php if($getCMs['children']){?>
                  <ul>
                    <?php foreach($getCMs['children'] as $getproduct) { ?>
                    <li> <a  href="<?=url($getCMs['cattype']."/".$getproduct['slug'])?>">
                      <?=$getproduct['title']?>
                      </a> </li>
                    <?php } ?>
                  </ul>
                  <?php } ?>
                </li>
                <?php } ?>
                <?php } ?>
                <?php } ?>
              </ul>
            </li>
            <li class="mainli miicons"><a >BEYOND ACADEMICS<i class="fa-angle-down fa"></i></a>
              <ul class="p-0">
                <?php if($getCategoryMenu = getCategoryMenu($posstion='top')) { ?>
                <?php foreach($getCategoryMenu as $getCMs) { ?>
                <?php if($getCMs['cattype']=='beyond-academics'){?>
                <li ><a  href="<?=url($getCMs['cattype']."/".$getCMs['slug'])?>">
                  <?=$getCMs['title']?>
                  </a>
                  <?php if($getCMs['children']){?>
                  <ul>
                    <?php foreach($getCMs['children'] as $getproduct) { ?>
                    <li> <a  href="<?=url($getCMs['cattype']."/".$getproduct['slug'])?>">
                      <?=$getproduct['title']?>
                      </a> </li>
                    <?php } ?>
                  </ul>
                  <?php } ?>
                </li>
                <?php } ?>
                <?php } ?>
                <?php } ?>
              </ul>
            </li>
            <li class="mainli "><a href="#">Admission</a></li>
            <li class="mainli "><a href="<?=url('career')?>">CAREER</a></li>
            <li class="mainli miicons"><a href="#">LOG IN<i class="fa-angle-down fa"></i></a>
              <ul class="p-0">
                <li><a href="#" >Student</a></li>
                <li><a href="#" >Teacher</a></li>
              </ul>
            </li>
          </ul>
        </nav>
      </div>
      <div class="d-block d-lg-none"><a id="slide" class="bgsrt  bgsrt-4 cartss"><i class="fa fa-bars"></i></a> </div>
    </div>
  </div>
</header>
<header class="tp-main-menu header-menu-3 sticky-header d-none">
  <div class="top-nav-2">
    <div class="container">
      <ul class="wrap_socail_icons">
        <?php if($facebook = webdata('facebook')) { ?>
        <li> <a class="bhhfg-fr" href="<?=$facebook?>" target="_blank"><i class="fa fa-facebook-f"></i></a> </li>
        <?php } ?>
        <?php if($twitter = webdata('twitter')) { ?>
        <li> <a class="bhhfg-fr-2" href="<?=$twitter?>" target="_blank"><i 	class="fa fa-twitter"></i></a> </li>
        <?php } ?>
        <?php if($linked = webdata('linked')) { ?>
        <li> <a class="bhhfg-fr-3" href="<?=$linked?>" target="_blank"><i class="fa fa-linkedin-in"></i></a> </li>
        <?php } ?>
        <?php if($instagram = webdata('instagram')) { ?>
        <li> <a class="bhhfg-fr-4" href="<?=$instagram?>" target="_blank"><i class="fa fa-instagram"></i></a> </li>
        <?php } ?>
        <?php if($pinterest = webdata('pinterest')) { ?>
        <li> <a class="bhhfg-fr-5" href="<?=$pinterest?>" target="_blank"><i class="fa fa-pinterest"></i></a> </li>
        <?php } ?>
        <?php if($google = webdata('google')) { ?>
        <li> <a class="bhhfg-fr-6" href="<?=$google?>" target="_blank"><i class="fa fa-youtube"></i></a> </li>
        <?php } ?>
      </ul>
    </div>
  </div>
  <div class="bottom-menu-nav">
    <div class="container">
      <div class="row row_menu_1">
        <div class="col-lg-3 col-md-12 col-12 col-logo-3">
          <div class="tagpoint-wrap-logo "> <span class="phone_menu  primary-color"> <i class="fas fa-bars"></i> </span> </div>
        </div>
        <div class="col-lg-9 col-md-12 col-12">
          <nav class="tp-menu tagpoint-menu-2">
            <ul class="tagpoint-main-menu ">
              <li class="current_page_item has-sub"> <i class="  fas fa-chevron-down tp_phone_dropdown"></i> <a title="Home" href="<?=url('/')?>"> Home </a> </li>
              <li class="has-sub"> <i class="  fas fa-chevron-down tp_phone_dropdown"></i> <a  href="<?=url('about-us')?>"> About Us</a> </li>
              <li class="has-sub"> <a  href="<?=url('memore')?>"> Memore </a> </li>
              <li class="has-sub"> <a  href="<?=createDefaultCategoryUrl()?>"> Bus Seat </a> </li>
              <?php if($getProducts = getProduct()) { ?>
              <li class="has-sub"> <i class="  fas fa-chevron-down tp_phone_dropdown"></i> <a  href="<?=createDefaultProductUrl()?>"> Products</a>
                <ul class="sub-menu ">
                  <?php foreach($getProducts as $getproduct) { ?>
                  <li> <a  href="<?=createProductUrl($getproduct['slug'])?>">
                    <?=$getproduct['name']?>
                    </a> </li>
                  <?php } ?>
                </ul>
              </li>
              <?php } ?>
              <li class="has-sub"> <a  href="<?=url('clients')?>"> Clients </a> </li>
              <li class="has-sub"> <a  href="<?=url('career')?>"> Careers </a> </li>
              <li> <a href="<?=url('contact')?>"> Contact Us </a> </li>
            </ul>
          </nav>
        </div>
      </div>
    </div>
  </div>
</header>
@yield('content')
<?php 
			$urlforscript = str_replace(url('/'),"",$actual_link);
			echo faqs($urlforscript); 
		?>
<footer class="dropex-section b-footer d-none">
  <div class="container">
    <div class="row row-top-footer">
      <div class="col-lg-3 col-md-6 col-sm-12 col-12">
        <div class="wrap_footer_col"> <img src="<?=resizeimg(webdata('footer_logo_file'),297,90,false)?>" alt="<?=webdata('webname')?>" title="<?=webdata('webname')?>" >
          <p></p>
          <ul class="footer_sicons">
            <?php if($facebook = webdata('facebook')) { ?>
            <li> <a class="bhhfg-fr" href="<?=$facebook?>" target="_blank"><i class="fa fa-facebook-f"></i></a> </li>
            <?php } ?>
            <?php if($twitter = webdata('twitter')) { ?>
            <li> <a class="bhhfg-fr-2" href="<?=$twitter?>" target="_blank"><i 	class="fa fa-twitter"></i></a> </li>
            <?php } ?>
            <?php if($linked = webdata('linked')) { ?>
            <li> <a class="bhhfg-fr-3" href="<?=$linked?>" target="_blank"><i class="fa fa-linkedin-in"></i></a> </li>
            <?php } ?>
            <?php if($instagram = webdata('instagram')) { ?>
            <li> <a class="bhhfg-fr-4" href="<?=$instagram?>" target="_blank"><i class="fa fa-instagram"></i></a> </li>
            <?php } ?>
            <?php if($pinterest = webdata('pinterest')) { ?>
            <li> <a class="bhhfg-fr-5" href="<?=$pinterest?>" target="_blank"><i class="fa fa-pinterest"></i></a> </li>
            <?php } ?>
            <?php if($google = webdata('google')) { ?>
            <li> <a class="bhhfg-fr-6" href="<?=$google?>" target="_blank"><i class="fa fa-youtube"></i></a> </li>
            <?php } ?>
          </ul>
        </div>
      </div>
      <div class="col-lg-3 col-md-4 col-sm-12 col-12">
        <div class="wrap_footer_col footer_col_links">
          <h6 class="footer-head ">Useful Links</h6>
          <ul class="footer_list bhhhhfhhffhh">
            <li><a href="<?=url('/')?>" >Home</a></li>
            <li><a href="<?=url('about-us')?>">about us</a></li>
            <li><a href="<?=createDefaultCategoryUrl()?>">Bus Seat</a></li>
            <li><a href="<?=createDefaultProductUrl()?>">Products</a></li>
            <li><a href="<?=url('clients')?>">clients</a></li>
            <li><a href="<?=createDefaultBlogUrl('blogs')?>">Blog</a></li>
            <li><a href="<?=url('contact')?>">Contact Us</a></li>
          </ul>
        </div>
      </div>
      <div class="col-lg-3 col-md-6 col-sm-12 col-12">
        <div class="wrap_footer_col footer_address">
          <h6 class="footer-head ">Contact Us</h6>
          <p>
            <?=webdata('address')?>
          </p>
          <p><a href="mailto:<?=webdata('email')?>">
            <?=webdata('email')?>
            </a></p>
          <p><a href="tel:<?=webdata('contact_no')?>">
            <?=webdata('contact_no')?>
            </a></p>
          <p><a href="tel:<?=webdata('contact_no_2')?>">
            <?=webdata('contact_no_2')?>
            </a></p>
          <p><a target="_blank" style="font-weight: 600;" href="https://m92.in/">To Purchase All Products </a></p>
        </div>
      </div>
      <div class="col-lg-3 col-md-3 col-sm-12 col-12">
        <div class="wrap_footer_col instagram_col">
          <h3 class="footer-head ">Newsletter </h3>
          <div class="subscripe_section"> <span>Subscribe to our newsletter & get the insights and news</span>
            <form action="#" class="subscribe_form">
              <p>
                <input type="text" name="email" placeholder="Your email address">
                <button type="submit" class="subcribe">Go!</button>
              </p>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="bootom-footer">
    <div class="container">
      <div class="row copywright_row">
        <div class="col-lg-7 col-md-7 col-12 ">
          <p class="copywright">Copyright ©
            <?=date('Y')?>
            </p>
        </div>
      </div>
    </div>
  </div>
</footer>
<footer>
  <div class="container" >
    <div class="row ">
      <div class="col-md-4 mb-4">
        <div class="footerlinkss pe-md-3"> <a href="<?=url('/')?>"> <img src="<?=resizeimg(webdata('logo_file'),871,217,false)?>" alt="<?=webdata('webname')?>" title="<?=webdata('webname')?>" width="871" height="217"  class="img-fluid footerlogo"> </a>
          <p>
            <?=webdata('footer_about')?>
          </p>
          <div class="footersocial">
            <?php if($instagram = webdata('instagram')) { ?>
            <a  href="<?=$instagram?>" target="_blank"><img src="{{url('assets/front_assets/assets/images/ins-iocn.svg')}}"   alt="" loading="lazy" class="img-fluid"></a>
            <?php } ?>
            <?php if($twitter = webdata('twitter')) { ?>
            <a  href="<?=$twitter?>" target="_blank"><img src="{{url('assets/front_assets/assets/images/twitter-icon.svg')}}"   alt="" loading="lazy" class="img-fluid"></a>
            <?php } ?>
            <a href="#"><img src="{{url('assets/front_assets/assets/images/social-icon.svg')}}"   alt="" loading="lazy" class="img-fluid"></a> </div>
        </div>
      </div>
      <div class="col-md-8 mb-4">
        <div class="footerlinkss">
          <div class="row ">
            <div class="col-lg-3 col-6 mb-3">
              <h4>About us</h4>
              <ul>
                <li><a href="#">From Our Principal</a></li>
                <li><a href="#">Leadership</a></li>
                <li><a href="#">Why Choose Us</a></li>
                <li><a href="#">Community</a></li>
                <li><a href="#">Sustainability</a></li>
              </ul>
            </div>
            <div class="col-lg-3 col-6 mb-3">
              <h4>Enrolments</h4>
              <ul>
                <li><a href="#">Admission</a></li>
                <li><a href="#">Tour & open day</a></li>
                <li><a href="#">Tuition</a></li>
              </ul>
            </div>
            <div class="col-lg-3 col-6 mb-3">
              <h4>Links</h4>
              <ul>
                <li><a href="#">Activities</a></li>
                <li><a href="#">Campus life</a></li>
                <li><a href="#">Community</a></li>
                <li><a href="#">Sports</a></li>
              </ul>
            </div>
            <div class="col-lg-3 col-6 mb-3">
              <h4>News & Events</h4>
              <ul>
                <li><a href="#">Latest News</a></li>
                <li><a href="#">Annual Report</a></li>
                <li><a href="#">Events</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous" defer></script> 
<script src="{{url('assets/front_assets/assets/js/owl.carousel.js')}}" ></script> 
<script src="{{url('assets/front_assets/assets/js/jquery.easy-ticker.js')}}"></script> 
<script src="{{url('assets/front_assets/assets/js/custom.js')}}" ></script>
<?php 
		echo getanalytics($position="Footer",$select_path="All Page",$url=''); 
		$urlforscript = str_replace(url('/'),"",$actual_link);
		echo getanalytics($position="Footer",$select_path="Custom",$url=$urlforscript); 
	?>
</body>
</html>
