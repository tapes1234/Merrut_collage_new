<script type="text/javascript">

$(document).ready(function () {
	$.validator.setDefaults({
	});
	$('#quickForm').validate({
		rules: {
			pid:{ required:true, },  	  
			title:{ required:true, },  	    
			meta_title:{ required:true, },  	  
			slug:{ required:true, },  	  
		},
		errorElement: 'span',
		errorPlacement: function (error, element) {
			error.addClass('invalid-feedback');
			element.closest('.form-group').append(error);
		},
		highlight: function (element, errorClass, validClass) {
			$(element).addClass('is-invalid');
		},
		unhighlight: function (element, errorClass, validClass) {
			$(element).removeClass('is-invalid');
		}
	});
	
	
	
	
	
	
	
var i = <?php echo $sn?>;
$('#potofolio_layout_btn').click(function(){
	i++;
	$('#potofolio_layout_div').append('<div class="row form-group" id="newpotofolio_layout_div'+i+'" style="background: #ececec;padding: 12px;"><div class="col-lg-3"><div class="form-group"><label> Title <span class="text-danger">*</span>  </label><div class="input-group">  <input type="text" class="form-control" name="portolio_image['+i+'][title]" required> </div></div></div><div class="col-lg-2"><div class="form-group"><label>Sort <span class="text-danger">*</span></label><div class="input-group">  <input type="number" class="form-control" name="portolio_image['+i+'][sort]" required> </div></div></div><div class="col-sm-6"><div class="form-group"><label>Image <span class="text-danger">*</span></label><div class="input-group"><span class="input-group-btn"><a data-input="image'+i+'" data-preview="image_holder'+i+'" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a></span><input id="image'+i+'" class="form-control" type="text" name="portolio_image['+i+'][image]" required></div><div id="image_holder'+i+'" style="margin-top:15px;max-height:100px;"></div></div></div><div class="col-lg-1"><div class="form-group"> <label>Remove</label><div class="form-group"><span class="btn btn-danger btn_remove" id="'+i+'">X</span></div> </div></div></div>');
	$('#potofolio_layout_div').find('.uploadfile').filemanager('image', {prefix: '/laravel-filemanager'});	
});
$(document).on('click', '.btn_remove', function(){  
	var button_id = $(this).attr("id");   
   $('#newpotofolio_layout_div'+button_id+'').remove();  
});

	
	
	
	
	
});
</script>