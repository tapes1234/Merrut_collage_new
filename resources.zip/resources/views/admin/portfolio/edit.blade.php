@extends('admin.layout.layout')
@section('content')
<div class="content-wrapper">
    <div class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?=$pageheading?></h1>
				</div>
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="<?=url(config('global.ADMIN_URL').'/dashboard')?>">Dashboard</a></li>
						<li class="breadcrumb-item active"><?=$pageheading?></li>
					</ol>
				</div>
			</div>
		</div>
    </div>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-secondary">
						<div class="card card-danger">
							@if ($error = Session::get('error'))
								<div class="card-header">
									<h3 class="card-title">{{$error}}</h3>
									<div class="card-tools">
										<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
										</button>
									</div>
								</div>
							@endif
						</div>
						<form method="post" id="quickForm" enctype="multipart/form-data">
							@csrf
							<div class="card-body">
								<div class="row">		
									<div class="col-sm-6">
										<div class="form-group">
											<label>Select parent <span class="text-danger">*</span></label>
											<select name="pid" class="form-control">
												<option value="" hidden> --Select-- </option>
												<option value="0" <?php if($pageInfo->pid == 0){ echo "selected";}?>> Self </option>
												<?php foreach($getAllPorfolio as $portfolio) { ?>
													<?php if($pageInfo->id != $portfolio->id) { ?>
														<option value="<?=$portfolio->id?>" <?php if($pageInfo->pid == $portfolio->id){ echo "selected";}?>><?=$portfolio->title?></option>
													<?php } ?>
												<?php } ?>
											</select>
										</div>
									</div>						
									<div class="col-sm-6">
										<div class="form-group">
											<label>Title <span class="text-danger">*</span></label>
											<input type="text"   class="form-control" name="title" value="<?=$pageInfo->title?>">
										</div>
									</div>	
									<div class="col-sm-12">
										<div class="form-group">
											<label>Slug <span class="text-danger">*</span></label>
											<input type="text" name="slug" class="form-control" value="<?=$pageInfo->slug?>" >
										</div>
									</div>	
									<div class="col-sm-3">
										<div class="form-group">
											<label>Top</label>
											<select class="form-control" name="top">
												<option value="1" <?php if($pageInfo->top == 1){ echo "selected";}?>>Enable</option>
												<option value="0" <?php if($pageInfo->top == 0){ echo "selected";}?>>Disable</option>
											</select>
										</div>
									</div>	
									<div class="col-sm-3">
										<div class="form-group">
											<label>Bottom</label>
											<select class="form-control" name="bottom">
												<option value="1" <?php if($pageInfo->bottom == 1){ echo "selected";}?>>Enable</option>
												<option value="0" <?php if($pageInfo->bottom == 0){ echo "selected";}?>>Disable</option>
											</select>
										</div>
									</div>	
									<div class="col-sm-3">
										<div class="form-group">
											<label>Status</label>
											<select class="form-control" name="status">
												<option value="1" <?php if($pageInfo->status == 1){ echo "selected";}?>>Enable</option>
												<option value="0" <?php if($pageInfo->status == 0){ echo "selected";}?>>Disable</option>
											</select>
										</div>
									</div>						
									<div class="col-sm-3">
										<div class="form-group">
											<label>Sort</label>
											<input type="number" class="form-control" name="sort" min="0" value="<?=$pageInfo->sort?>">
										</div>
									</div>	
									<div class="col-sm-6">
										<div class="form-group">
											<label>Meta Title <span class="text-danger">*</span></label>
											<textarea class="form-control" name="meta_title"><?=$pageInfo->meta_title?></textarea>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<label>Meta Keyword</label>
											<textarea class="form-control" name="meta_keyword"><?=$pageInfo->meta_keyword?></textarea>
										</div>
									</div>
									<div class="col-sm-12">
										<div class="form-group">
											<label>Meta Description</label>
											<textarea class="form-control" name="meta_description"><?=$pageInfo->meta_description?></textarea>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<label>Image</label>
											<div class="input-group">
												<span class="input-group-btn">
													<a data-input="image" data-preview="image_holder" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a>
												</span>
												<input id="image" class="form-control" type="text" name="image" value="<?=$pageInfo->image?>">
											</div>
											<div id="image_holder" style="margin-top:15px;max-height:100px;">
												<img src="<?=resizeimg($pageInfo->image,80,80,false)?>">
											</div>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<label>Banner</label>
											<div class="input-group">
												<span class="input-group-btn">
													<a data-input="banner" data-preview="banner_holder" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a>
												</span>
												<input id="banner" class="form-control" type="text" name="banner" value="<?=$pageInfo->banner?>">
											</div>
											<div id="banner_holder" style="margin-top:15px;max-height:100px;">
											<img src="<?=resizeimg($pageInfo->banner,80,80,false)?>"></div>
										</div>
									</div>
									<div class="col-sm-12">
										<div class="form-group">
											<label>Short Description</label>
											<textarea class="textarea" id="short_description" name="short_description"><?=$pageInfo->short_description?></textarea>
										</div>
									</div>
									<div class="col-sm-12">
										<div class="form-group">
											<label>Description</label>
											<textarea class="textarea" id="description" name="description"><?=$pageInfo->description?></textarea>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-12">
										<div class="row alert alert-secondary">
											<div class="col-sm-6">
												<h6 style="margin:0">Add Porfolio Images</h6>
											</div>
											<div class="col-sm-6">
												<span class="btn btn-success btn-sm float-sm-right" id="potofolio_layout_btn"> + Add </span>
											</div>
										</div>
										<div id="potofolio_layout_div">
											<?php if($allportfolio_image){ $sn=1; ?>
												<?php foreach($allportfolio_image as $portfolio_image) { ?>
													<div class="row form-group" id="newpotofolio_layout_div<?=$sn?>" style="background: #ececec;padding: 12px;">
													   <div class="col-lg-3">
														  <div class="form-group">
															 <label> Title  </label>
															 <div class="input-group">  <input type="text" class="form-control" name="portolio_image[<?=$sn?>][title]" value="<?=$portfolio_image->title?>"> </div>
														  </div>
													   </div>
													   <div class="col-lg-2">
														  <div class="form-group">
															 <label>Sort</label>
															 <div class="input-group">  <input type="number" class="form-control" name="portolio_image[<?=$sn?>][sort]" value="<?=$portfolio_image->sort?>"> </div>
														  </div>
													   </div>
													   <div class="col-sm-6">
														  <div class="form-group">
															 <label>Image</label>
															 <div class="input-group"><span class="input-group-btn"><a data-input="image<?=$sn?>" data-preview="image_holder<?=$sn?>" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a></span><input id="image<?=$sn?>" class="form-control" type="text" name="portolio_image[<?=$sn?>][image]" value="<?=$portfolio_image->image?>"></div>
															 <div id="image_holder<?=$sn?>" style="margin-top:15px;max-height:100px;">
																<img src="<?=resizeimg($portfolio_image->image,80,80,false)?>">
															 </div>
														  </div>
													   </div>
													   <div class="col-lg-1">
														  <div class="form-group">
															 <label>Remove</label>
															 <div class="form-group"><span class="btn btn-danger btn_remove" id="<?=$sn?>">X</span></div>
														  </div>
													   </div>
													</div>

												<?php $sn++; }?>
											<?php }else{ $sn=1;} ?>
										</div>
									</div>
								</div>
							</div>
							<div class="card-footer">
								<input type="submit" class="btn btn-primary" value="Submit" name="submit">
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
    </section>
</div>
<?php $sn=1;?>
@include('admin.portfolio.script')
@endsection