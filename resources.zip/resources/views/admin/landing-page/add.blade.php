@extends('admin.layout.layout')
@section('content')
<div class="content-wrapper">
    <div class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?=$pageheading?></h1>
				</div>
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="<?=url(config('global.ADMIN_URL').'/dashboard')?>">Dashboard</a></li>
						<li class="breadcrumb-item active"><?=$pageheading?></li>
					</ol>
				</div>
			</div>
		</div>
    </div>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-secondary">
						<div class="card card-danger">
							@if ($error = Session::get('error'))
								<div class="card-header">
									<h3 class="card-title">{{$error}}</h3>
									<div class="card-tools">
										<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
										</button>
									</div>
								</div>
							@endif
						</div>
						<form method="post" id="quickForm" enctype="multipart/form-data">
							@csrf
							<div class="card-body">
								<div class="row">		
									<div class="col-sm-5">
										<div class="form-group">
											<label>Title <span class="text-danger">*</span></label>
											<input type="text"   class="form-control" name="title">
										</div>
									</div>						
									<div class="col-sm-5">
										<div class="form-group">
											<label>Heading </label>
											<input type="text" class="form-control" name="heading">
										</div>
									</div>	
									<div class="col-sm-2">
										<div class="form-group">
											<label>Status</label>
											<select class="form-control" name="status">
												<option value="1">Enable</option>
												<option value="0">Disable</option>
											</select>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<label>Slug <span class="text-danger">*</span></label>
											<input type="text"   class="form-control" name="slug">
										</div>
									</div>	
									<div class="col-sm-6">
										<div class="form-group">
											<label>Meta Title <span class="text-danger">*</span></label>
											<input type="text" class="form-control" name="meta_title">
										</div>
									</div>	
									<div class="col-sm-6">
										<div class="form-group">
											<label>Meta Keyword</label>
											<textarea class="form-control" name="meta_keyword"></textarea>
										</div>
									</div>		
									<div class="col-sm-6">
										<div class="form-group">
											<label>Meta Description</label>
											<textarea class="form-control" name="meta_description"></textarea>
										</div>
									</div>										
									
															
								</div>						
								<div class="row">		
									<div class="col-sm-12">
										<h6 class="alert alert-secondary text-center">Banner Section</h6>
									</div>		
									<div class="col-sm-4">
										<div class="form-group">
											<label>Banner Image</label>
											<div class="input-group">
												<span class="input-group-btn">
													<a data-input="banner_image" data-preview="banner_image_holder" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a>
												</span>
												<input id="banner_image" class="form-control" type="text" name="banner_image">
											</div>
											<div id="banner_image_holder" style="margin-top:15px;max-height:100px;"></div>
										</div>
									</div>
										
									<div class="col-sm-4">
										<div class="form-group">
											<label>Banner Button Text </label>
											<input type="text" class="form-control" name="banner_button_text">
										</div>
									</div>	
									<div class="col-sm-4">
										<div class="form-group">
											<label>Banner Button Link </label>
											<input type="text" class="form-control" name="banner_button_link">
										</div>
									</div>	
									<div class="col-sm-12">
										<div class="form-group">
											<label>Banner Heading </label>
											<textarea class="textarea" name="banner_text" id="banner_text"></textarea>
										</div>
									</div>	
								</div>
								<div class="row">
									<div class="col-sm-12">
										<h6 class="alert alert-secondary text-center">About Section</h6>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<label>About Image</label>
											<div class="input-group">
												<span class="input-group-btn">
													<a data-input="about_image" data-preview="about_image_holder" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a>
												</span>
												<input id="about_image" class="form-control" type="text" name="about_image">
											</div>
											<div id="about_image_holder" style="margin-top:15px;max-height:100px;"></div>
										</div>
									</div>	
									<div class="col-sm-3">
										<div class="form-group">
											<label>About Button Text </label>
											<input type="text" class="form-control" name="about_button_text">
										</div>
									</div>	
									<div class="col-sm-3">
										<div class="form-group">
											<label>About Button Link </label>
											<input type="text" class="form-control" name="about_button_link">
										</div>
									</div>		
									<div class="col-sm-12">
										<div class="form-group">
											<label>About Description</label>
											<textarea name="about_description" class="textarea" id="about_description"></textarea>
											
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-12">
										<h6 class="alert alert-secondary text-center">Service Section <span class="btn btn-success btn-sm float-sm-right" id="service_layout_btn"> + Add Service </span></h6>
									</div>
									<div class="col-sm-12">
										<div class="form-group">
											<label>Service Heading</label>
											<input type="text" name="service_heading" class="form-control">
										</div>
									</div>
									<div class="col-sm-12" id="service_layout_div">
										
									</div>
									
								</div>
								<div class="row">
									<div class="col-sm-12">
										<h6 class="alert alert-secondary text-center">Custom Section</h6>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<label>Image</label>
											<div class="input-group">
												<span class="input-group-btn">
													<a data-input="custom_section_image" data-preview="custom_image_holder" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a>
												</span>
												<input id="custom_section_image" class="form-control" type="text" name="custom_section_image">
											</div>
											<div id="custom_image_holder" style="margin-top:15px;max-height:100px;"></div>
										</div>
									</div>	
									<div class="col-sm-3">
										<div class="form-group">
											<label>Custom Button Text </label>
											<input type="text" class="form-control" name="custom_button_text">
										</div>
									</div>	
									<div class="col-sm-3">
										<div class="form-group">
											<label>Custom Button Link </label>
											<input type="text" class="form-control" name="custom_section_button_link">
										</div>
									</div>		
									<div class="col-sm-12">
										<div class="form-group">
											<label>Custom Description</label>
											<textarea name="custom_description" class="textarea" id="custom_description"></textarea>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-12">
										<h6 class="alert alert-secondary text-center">Why Choose Section <span class="btn btn-success btn-sm float-sm-right" id="why_choose_layout_btn"> + Add why choose </span></h6>
									</div>
									<div class="col-sm-12">
										<div class="form-group">
											<label>Heading</label>
											<input type="text" name="why_choose_heading" class="form-control">
										</div>
									</div>
									<div class="col-sm-12" id="why_choose_layout_div">
										
									</div>
									
								</div>
								<div class="row">
									<div class="col-sm-12">
										<h6 class="alert alert-secondary text-center">Counter Section</h6>
									</div>
									<div class="col-sm-3">
										<div class="form-group">
											<div class="form-group">
												<label>Text</label>
												<input type="text" name="counter_1_text" class="form-control">
											</div>
											<div class="form-group">
												<label>Value</label>
												<input type="text" name="counter_1_value" class="form-control">
											</div>
										</div>
									</div>
									<div class="col-sm-3">
										<div class="form-group">
											<div class="form-group">
												<label>Text</label>
												<input type="text" name="counter_2_text" class="form-control">
											</div>
											<div class="form-group">
												<label>Value</label>
												<input type="text" name="counter_2_value" class="form-control">
											</div>
										</div>
									</div>	
									<div class="col-sm-3">
										<div class="form-group">
											<div class="form-group">
												<label>Text</label>
												<input type="text" name="counter_3_text" class="form-control">
											</div>
											<div class="form-group">
												<label>Value</label>
												<input type="text" name="counter_3_value" class="form-control">
											</div>
										</div>
									</div>		
									<div class="col-sm-3">
										<div class="form-group">
											<div class="form-group">
												<label>Text</label>
												<input type="text" name="counter_4_text" class="form-control">
											</div>
											<div class="form-group">
												<label>Value</label>
												<input type="text" name="counter_4_value" class="form-control">
											</div>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-12">
										<h6 class="alert alert-secondary text-center">Custom Description</h6>
									</div>
									<div class="col-sm-12">
										<div class="form-group">
											<label>Custom Description 1</label>
											<textarea name="custom_description_1" class="textarea" id="custom_description_1"></textarea>
										</div>
									</div>
									<div class="col-sm-12">
										<div class="form-group">
											<label>Custom Description 2</label>
											<textarea name="custom_description_2" class="textarea" id="custom_description_2"></textarea>
										</div>
									</div>
									
								</div>
							</div>
							<div class="card-footer">
								<input type="submit" class="btn btn-primary" value="Submit" name="submit">
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
    </section>
</div>
<?php $sn=1; $sn2=2;?>
@include('admin.landing-page.script')
@endsection