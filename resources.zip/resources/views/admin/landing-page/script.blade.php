<script type="text/javascript">
$(document).ready(function () {
	//validdation
	$.validator.setDefaults({
	});
	$('#quickForm').validate({
		rules: {
			title:{ required:true, },  	  
			slug:{ required:true, },  	  
			meta_title:{ required:true, },  	  
		},
		errorElement: 'span',
		errorPlacement: function (error, element) {
			error.addClass('invalid-feedback');
			element.closest('.form-group').append(error);
		},
		highlight: function (element, errorClass, validClass) {
			$(element).addClass('is-invalid');
		},
		unhighlight: function (element, errorClass, validClass) {
			$(element).removeClass('is-invalid');
		}
	});


	//service add section
	var i = <?=$sn?>;
	$('#service_layout_btn').click(function(){
		i++;
		$('#service_layout_div').append('<div class="row form-group" id="newservice_layout_div'+i+'" style="background: #ececec;padding: 12px;"><div class="col-lg-4"><div class="form-group"><label> Title <span class="text-danger">*</span>  </label><div class="input-group">  <input type="text" class="form-control" name="service_data['+i+'][title]" required> </div></div></div><div class="col-lg-4"><div class="form-group"><label>Link</label><div class="input-group">  <input type="text" class="form-control" name="service_data['+i+'][link]" required> </div></div></div><div class="col-sm-3"><div class="form-group"><label>Image <span class="text-danger">*</span></label><div class="input-group"><span class="input-group-btn"><a data-input="image'+i+'" data-preview="image_holder'+i+'" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a></span><input id="image'+i+'" class="form-control" type="text" name="service_data['+i+'][image]" required></div><div id="image_holder'+i+'" style="margin-top:15px;max-height:100px;"></div></div></div><div class="col-lg-1"><div class="form-group"> <label>Remove</label><div class="form-group"><span class="btn btn-danger btn_remove" id="'+i+'">X</span></div> </div></div></div>');
		$('#service_layout_div').find('.uploadfile').filemanager('image', {prefix: '/laravel-filemanager'});	
	});
	$(document).on('click', '.btn_remove', function(){  
		var button_id = $(this).attr("id");   
	   $('#newservice_layout_div'+button_id+'').remove();  
	});	
	
	//Why Choose Service section
	var j = <?=$sn2?>;
	$('#why_choose_layout_btn').click(function(){
		j++;
		$('#why_choose_layout_div').append('<div class="row form-group" id="newwhy_choose_layout_div'+j+'" style="background: #ececec;padding: 12px;"><div class="col-lg-3"><div class="form-group"><label> Heading <span class="text-danger">*</span>  </label><div class="input-group">  <input type="text" class="form-control" name="why_choose_data['+j+'][heading]" required> </div></div></div><div class="col-lg-5"><div class="form-group"><label>Description</label><div class="input-group">  <input type="text" class="form-control" name="why_choose_data['+j+'][description]"> </div></div></div><div class="col-sm-3"><div class="form-group"><label>Image <span class="text-danger">*</span></label><div class="input-group"><span class="input-group-btn"><a data-input="image_2'+j+'" data-preview="image_holder_2'+j+'" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a></span><input id="image_2'+j+'" class="form-control" type="text" name="why_choose_data['+j+'][image]" required></div><div id="image_holder_2'+j+'" style="margin-top:15px;max-height:100px;"></div></div></div><div class="col-lg-1"><div class="form-group"> <label>Remove</label><div class="form-group"><span class="btn btn-danger btn_remove_2" id="'+j+'">X</span></div> </div></div></div>');
		$('#why_choose_layout_div').find('.uploadfile').filemanager('image', {prefix: '/laravel-filemanager'});	
	});
	$(document).on('click', '.btn_remove_2', function(){  
		var button_id = $(this).attr("id");   
	   $('#newwhy_choose_layout_div'+button_id+'').remove();  
	});












});






</script>