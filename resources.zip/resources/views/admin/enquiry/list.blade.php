@extends('admin.layout.layout')
@section('content')
<div class="content-wrapper">
    <div class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-left">
						<li class="breadcrumb-item"><a href="<?=url(config('global.ADMIN_URL').'/dashboard')?>">Dashboard</a></li>
						<li class="breadcrumb-item active"><?=$pageheading?></li>
					</ol>
				</div>
				<div class="col-sm-6">
					<div class="float-sm-right">
						
						<a href='javascript:void()' onclick=" $('#bannerform').attr('action', '<?php echo $deleteaction ; ?>'); $('#bannerform').submit();  " class="btn btn-danger btn-sm"> Delete</a>
						<button type="button" class="btn btn-success btn-sm"  data-toggle="modal" data-target="#modal-default">Search</button>
						<button type="button" class="btn btn-primary btn-sm"  data-toggle="modal" data-target="#modal-download">Download</button>
						<a href="<?=url()->current();?>" class="btn btn-warning btn-sm">Clear<a/>
					</div>
				</div>
			</div>
		</div>
    </div>
	<section class="content">
		<div class="row">
			<div class="col-12">
				@if ($success = Session::get('success'))
				<div class="card card-success">
					<div class="card-header">
						<h3 class="card-title">{{$success}}</h3>
					</div>
				</div>
				@endif	
				 
				@if ($error = Session::get('error'))
				<div class="card card-danger">
					<div class="card-header">
						<h3 class="card-title">{{$error}}</h3>
					</div>
				</div>
				@endif

				<div class="card-body">
					<?php if($allresults) { ?>
					<form id="bannerform" name="bannerform" method="post">
					@csrf
				
						<table id="tables" class="table table-bordered table-striped">
							<thead>
								<tr>
								  <th>#</th>
								  <th>Name</th>
								  <th>Email</th>
								  <th>Phone</th>
								  <th>Message</th>
								
								</tr>
							</thead>
							<tbody>
								<?php foreach($allresults as $result){ ?>
									<tr>
										<td>
											<input type="checkbox" name="delete_ids[]" value="<?=$result->id?>">
										</td>
										<td><?=$result->name?></td>
										<td><?=$result->email?></td>
										<td><?=$result->phone?></td>
										<td><?=$result->message?></td>
									</tr>
									
								<?php  }?>
							</tbody>
  
						</table>
					</form>

					<?=$allresults->withQueryString()->links('pagination::bootstrap-5')?>
					<?php } else { ?>
						<h3 class="text-center">Data Not Found</h3>
					<?php } ?>
				</div>
			</div>
        </div>
    </section>
</div>


<div class="modal fade" id="modal-default">
	<div class="modal-dialog">
		<form id="enquiryModalForm" name="enquiryModalForm">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Search</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-sm-6">
						<div class="form-group">
							<label>Start Date</label>
							<input type="date" name="start_date" value="<?=$start_date?>" class="form-control" required>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="form-group">
							<label>End Date</label>
							<input type="date" name="end_date" value="<?=$end_date?>" class="form-control" required>
						</div>
					</div>
				</div>
			</div>
			<div class="modal-footer justify-content-end">
				<button type="submit" class="btn btn-success btn-sm">Search</button>
			</div>
		</div>
		</form>
	</div>
</div>

<div class="modal fade" id="modal-download">
	<div class="modal-dialog">
		<form id="downloadEnquiryModalForm" name="downloadEnquiryModalForm" action="<?php echo url(config('global.ADMIN_URL').'/enquiry/downloadxlsx')?>" method="POST">
		@csrf
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Search</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-sm-6">
						<div class="form-group">
							<label>Start Date</label>
							<input type="date" name="start_date" value="<?=$start_date?>" class="form-control" required>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="form-group">
							<label>End Date</label>
							<input type="date" name="end_date" value="<?=$end_date?>" class="form-control" required>
						</div>
					</div>
				</div>
			</div>
			<div class="modal-footer justify-content-end">
				<button type="submit" class="btn btn-primary btn-sm">Download</button>
			</div>
		</div>
		</form>
	</div>
</div>



@endsection