@extends('admin.layout.layout')
@section('content')
<div class="content-wrapper">
    <div class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?=$pageheading?></h1>
				</div>
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="<?=url(config('global.ADMIN_URL').'/dashboard')?>">Dashboard</a></li>
						<li class="breadcrumb-item active"><?=$pageheading?></li>
					</ol>
				</div>
			</div>
		</div>
    </div>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-secondary">
						<div class="card card-danger">
							@if ($error = Session::get('error'))
								<div class="card-header">
									<h3 class="card-title">{{$error}}</h3>
									<div class="card-tools">
										<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
										</button>
									</div>
								</div>
							@endif
						</div>
						<form method="post" id="quickForm" enctype="multipart/form-data">
						@csrf
							<div class="card-body">
								<div class="row">							
									<div class="col-sm-6">
										<div class="form-group">
											<label>Position <span class="text-danger">*</span></label>
											<select class="form-control" name="position">
												<option value="" hidden>Select</option>
												<option <?php if($pageInfo->position == 'Head') { echo "selected";}?>>Head</option>
												<option <?php if($pageInfo->position == 'Body') { echo "selected";}?>>Body</option>
												<option <?php if($pageInfo->position == 'Footer') { echo "selected";}?>>Footer</option>
											</select>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<label>Select Path <span class="text-danger">*</span></label>
											<select class="form-control" name="select_path" id="select_path" onchange="changefunc(this.value)">
												<option value="" hidden>Select</option>
												<option  <?php if($pageInfo->select_path == 'All Page') { echo "selected";}?>>All Page</option>
												<option  <?php if($pageInfo->select_path == 'Custom') { echo "selected";}?>>Custom</option>
											</select>
										</div>
									</div>	
							
									<div class="col-sm-12" style="display: <?php if($pageInfo->select_path == 'All Page') { echo "none";}else { echo "block"; }?>;" id="path">
										<div class="form-group">
											<label>Path <span class="text-danger">*</span></label>
											<textarea name="path" class="form-control"><?=$pageInfo->path?></textarea>
										</div>
									</div>	
									<div class="col-sm-12">
										<div class="form-group">
											<label>Code <span class="text-danger">*</span></label>
											<textarea name="code" class="form-control"><?=$pageInfo->code?></textarea>
										</div>
									</div>	
									<div class="col-sm-12">
										<div class="form-group">
											<label>sort</label>
											<input type="number" min="0" name="sort" class="form-control" value="<?=$pageInfo->sort?>">
										</div>
									</div>	
								</div>
							</div>
							<div class="card-footer">
								<input type="submit" class="btn btn-primary" value="Submit" name="submit">
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
    </section>
</div>
<script>
function changefunc(value){
	
	if(value=="Custom"){
		
		$("#path").show();
	}
	else{
		$("#path").hide();
		
	}
}
</script>
<script type="text/javascript">
$(document).ready(function () {
  $.validator.setDefaults({
  });
  $('#quickForm').validate({
    rules: {
		
		position:{ required:true, },  	  
		select_path:{ required:true, },  	  
		path:{ required:true, },  	  
		code:{ required:true, },  	  
    },
    errorElement: 'span',
    errorPlacement: function (error, element) {
      error.addClass('invalid-feedback');
      element.closest('.form-group').append(error);
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
    }
  });
});
</script>
@endsection