@extends('admin.layout.layout')
@section('content')
<div class="content-wrapper">
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">
            <?=$pageheading?>
          </h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?=url(config('global.ADMIN_URL').'/dashboard')?>">Dashboard</a></li>
            <li class="breadcrumb-item active">
              <?=$pageheading?>
            </li>
          </ol>
        </div>
      </div>
    </div>
  </div>
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card card-secondary">
            <div class="card card-danger"> @if ($error = Session::get('error'))
              <div class="card-header">
                <h3 class="card-title">{{$error}}</h3>
                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i> </button>
                </div>
              </div>
              @endif </div>
            <form method="post" id="quickForm" enctype="multipart/form-data">
              @csrf
              <div class="card-body">
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                  <li class="nav-item"> <a class="nav-link active" id="general-tab" data-toggle="tab" href="#general" role="tab" aria-controls="general" aria-selected="true">General</a> </li>
                  <li class="nav-item"> <a class="nav-link" id="web-tab" data-toggle="tab" href="#web" role="tab" aria-controls="web"aria-selected="true">Web</a> </li>
                  <li class="nav-item"> <a class="nav-link" id="image-tab" data-toggle="tab" href="#image" role="tab" aria-controls="image"aria-selected="false">Image</a> </li>
                  <li class="nav-item"> <a class="nav-link" id="social-tab" data-toggle="tab" href="#social" role="tab" aria-controls="social" aria-selected="false">Social Links</a> </li>
                  <li class="nav-item"> <a class="nav-link" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="false">Home Page</a> </li>
                  <li class="nav-item"> <a class="nav-link" id="about-tab" data-toggle="tab" href="#about" role="tab" aria-controls="about" aria-selected="false">Our History</a> </li>
                  <li class="nav-item"> <a class="nav-link" id="category-tab" data-toggle="tab" href="#category" role="tab" aria-controls="category" aria-selected="false">Category Page (Bus Seat)</a> </li>
                  <li class="nav-item"> <a class="nav-link" id="memore-tab" data-toggle="tab" href="#memore" role="tab" aria-controls="memore" aria-selected="false">Memore</a> </li>
                  <li class="nav-item"> <a class="nav-link" id="mail-tab" data-toggle="tab" href="#mail" role="tab" aria-controls="mail" aria-selected="false">Mail</a> </li>
                </ul>
                <div class="tab-content" id="myTabContent">
                  <div class="tab-pane fade show active" id="general" role="tabpanel" aria-labelledby="general-tab">
                    <div class="sectiondiv">
                      <div class="row">
                        <div class="col-sm-12">
                          <div class="form-group">
                            <label>Meta Title <span class="text-danger">*</span></label>
                            <input type="text" value="<?=webdata('page_title')?>"  class="form-control" name="page_title">
                          </div>
                        </div>
                        <div class="col-sm-12">
                          <div class="form-group">
                            <label>Meta Keyword <span class="text-danger">*</span></label>
                            <textarea class="form-control" name="meta_keyword"><?=webdata('meta_keyword')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-sm-12">
                          <div class="form-group">
                            <label>Meta Description <span class="text-danger">*</span></label>
                            <textarea class="form-control" name="meta_description"><?=webdata('meta_description')?>
</textarea>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="tab-pane fade" id="web" role="tabpanel" aria-labelledby="web-tab">
                    <div class="sectiondiv">
                      <div class="row">
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Web Name </label>
                            <input type="text" value="<?=webdata('webname')?>"  class="form-control" name="webname">
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Email</label>
                            <input type="text"  value="<?=webdata('email')?>"  class="form-control" name="email">
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Contact No. </label>
                            <input type="text"  value="<?=webdata('contact_no')?>"  class="form-control" name="contact_no">
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Contact No. 2 </label>
                            <input type="text"  value="<?=webdata('contact_no_2')?>"  class="form-control" name="contact_no_2">
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Address</label>
                            <textarea name="address" class="form-control"><?=webdata('address')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>About Us (Footer)</label>
                            <textarea name="footer_about" class="form-control"><?=webdata('footer_about')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-sm-12">
                          <div class="form-group">
                            <label>Map</label>
                            <textarea class="form-control" name="map"><?=webdata('map')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-sm-12">
                          <h5 class="alert alert-secondary text-center">For Sales & Marketing queries Section</h5>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Email</label>
                            <textarea name="sales_email" id="sales_email" class="textarea"><?=webdata('sales_email')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Phone</label>
                            <textarea name="sales_phone" id="sales_phone"   class="textarea"><?=webdata('sales_phone')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-sm-12">
                          <div class="form-group">
                            <label>Address</label>
                            <textarea name="sales_address" id="sales_address"  class="textarea"><?=webdata('sales_address')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-sm-12">
                          <h5 class="alert alert-secondary text-center">Corporate Office Section</h5>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Email</label>
                            <textarea name="corporate_email" id="corporate_email"  class="textarea"><?=webdata('corporate_email')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Phone</label>
                            <textarea name="corporate_phone" id="corporate_phone"  class="textarea"><?=webdata('corporate_phone')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-sm-12">
                          <div class="form-group">
                            <label>Address</label>
                            <textarea name="corporate_address" id="corporate_address"  class="textarea"><?=webdata('corporate_address')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-sm-12">
                          <h5 class="alert alert-secondary text-center">Spiring candidates may contact at: </h5>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Email</label>
                            <textarea name="spiring_email" id="spiring_email"  class="textarea"><?=webdata('spiring_email')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Phone</label>
                            <textarea name="spiring_phone" id="spiring_phone"  class="textarea"><?=webdata('spiring_phone')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-sm-12">
                          <div class="form-group">
                            <label>Address</label>
                            <textarea name="spiring_address" id="spiring_address"  class="textarea"><?=webdata('spiring_address')?>
</textarea>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="tab-pane fade" id="image" role="tabpanel" aria-labelledby="image-tab">
                    <div class="sectiondiv">
                      <div class="row">
                        <div class="col-sm-10">
                          <div class="form-group">
                            <label>Logo</label>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="logo_thumbnail" data-preview="logo_file" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="logo_thumbnail" class="form-control" type="text" name="logo_file" value="<?=webdata('logo_file')?>">
                            </div>
                          </div>
                        </div>
                        <div class="col-sm-2"> <span id="logo_file" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('logo_file'),80,80,false)?>"> </span> </div>
                      </div>
                      <div class="row">
                        <div class="col-sm-10">
                          <div class="form-group">
                            <label>Footer Logo</label>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="footer_logo_thumbnail" data-preview="footer_logo_file" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="footer_logo_thumbnail" class="form-control" type="text" name="footer_logo_file" value="<?=webdata('footer_logo_file')?>">
                            </div>
                          </div>
                        </div>
                        <div class="col-sm-2"> <span id="footer_logo_file" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('footer_logo_file'),80,80,false)?>"> </span> </div>
                      </div>
                      <div class="row">
                        <div class="col-sm-10">
                          <div class="form-group">
                            <label>Favicon</label>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="favicon_thumbnail" data-preview="favicon_file" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="favicon_thumbnail" class="form-control" type="text" name="favicon_file" value="<?=webdata('favicon_file')?>">
                            </div>
                          </div>
                        </div>
                        <div class="col-sm-2"> <span id="favicon_file" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('favicon_file'),80,80,false)?>"> </span> </div>
                      </div>
                    </div>
                  </div>
                  <div class="tab-pane fade" id="social" role="tabpanel" aria-labelledby="social-tab">
                    <div class="sectiondiv">
                      <div class="row">
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>YouTube</label>
                            <input type="text" class="form-control" name="google" value="<?=webdata('google')?>">
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Facebook</label>
                            <input type="text" class="form-control" name="facebook" value="<?=webdata('facebook')?>">
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Instagram</label>
                            <input type="text" class="form-control" name="instagram" value="<?=webdata('instagram')?>">
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Linked</label>
                            <input type="text" class="form-control" name=	"linked" value="<?=webdata('linked')?>">
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Twitter</label>
                            <input type="text" class="form-control" name="twitter" value="<?=webdata('twitter')?>">
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Pinterest</label>
                            <input type="text" class="form-control" name="pinterest" value="<?=webdata('pinterest')?>">
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="tab-pane fade" id="home" role="tabpanel" aria-labelledby="home-tab">
                    <div class="sectiondiv">
                      <div class="row">
                        <div class="col-sm-12">
                          <h5 class="alert alert-secondary text-center">Section 1 (About Us Section)</h5>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Is section Enable?</label>
                            <select class="form-control" name="section_1_enable">
                              <option value='1' <?php if(webdata('section_1_enable') == '1'){ echo "selected";}?>>Enable</option>
                              <option value='0' <?php if(webdata('section_1_enable') == '0'){ echo "selected";}?>>Disable</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="row">
                            <div class="col-sm-10">
                              <div class="form-group">
                                <label>Image</label>
                                <div class="input-group"> <span class="input-group-btn"><a data-input="section_1_image_thumbnail" data-preview="section_1_image" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                                  <input id="section_1_image_thumbnail" class="form-control" type="text" name="section_1_image" value="<?=webdata('section_1_image')?>">
                                </div>
                              </div>
                            </div>
                            <div class="col-sm-2"> <span id="section_1_image" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('section_1_image'),80,80,false)?>"> </span> </div>
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Title</label>
                            <input type="text" name="section_1_title" class="form-control" value="<?=webdata('section_1_title')?>">
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Heading</label>
                            <input type="text" name="section_1_heading" class="form-control" value="<?=webdata('section_1_heading')?>">
                          </div>
                        </div>
                        <div class="col-sm-12">
                          <div class="form-group">
                            <label>Link</label>
                            <input type="text" name="section_1_link" class="form-control" value="<?=webdata('section_1_link')?>">
                          </div>
                        </div>
                        <div class="col-sm-12">
                          <div class="form-group">
                            <label>Description</label>
                            <textarea name="section_1_description" class="textarea" id="section_1_description"><?=webdata('section_1_description')?>
</textarea>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-sm-12">
                          <h5 class="alert alert-secondary text-center">Section 2 (Product Section)</h5>
                        </div>
                        <div class="col-sm-2">
                          <div class="form-group">
                            <label>Is section Enable?</label>
                            <select class="form-control" name="section_2_enable">
                              <option value='1' <?php if(webdata('section_2_enable') == '1'){ echo "selected";}?>>Enable</option>
                              <option value='0' <?php if(webdata('section_2_enable') == '0'){ echo "selected";}?>>Disable</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Title</label>
                            <input type="text" name="section_2_title" class="form-control"value="<?=webdata('section_2_title')?>">
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Heading</label>
                            <input type="text" name="section_2_heading" class="form-control" value="<?=webdata('section_2_heading')?>">
                          </div>
                        </div>
                        <div class="col-sm-12">
                          <div class="form-group">
                            <label>Description</label>
                            <textarea class="form-control" name="section_2_description"><?=webdata('section_2_description')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-sm-12">
                          <div class="form-group">
                            <label>Products </label>
                            <input type="text" name="product" value="" placeholder="Product" id="input-product" class="form-control"/>
                            <div id="product_ids" class="well well-sm" style="height: 150px; overflow: auto;background: #ececec;padding: 10px;">
                              <?php if($product_ids  = json_decode(webdata('product_ids'))) { ?>
                              <?php foreach($product_ids as $product_id){ ?>
                              <?php if($getProductInfo = getProductInfo($column='id',$product_id)) { ?>
                              <div id="product_ids<?=$getProductInfo->id?>"><i class="fa fa-minus-circle"></i>
                                <?=$getProductInfo->name?>
                                <input type="hidden" name="product_ids[]" value="<?=$getProductInfo->id?>">
                              </div>
                              <?php } ?>
                              <?php } ?>
                              <?php } ?>
                            </div>
                          </div>
                        </div>
                        <!--div class="col-sm-12">
													<div class="form-group">
														<label>Categories </label>
														<input type="text" name="category" value="" placeholder="Category" id="input-category" class="form-control"/>
														<div id="category_ids" class="well well-sm" style="height: 150px; overflow: auto;background: #ececec;padding: 10px;">
														<?php if($category_ids  = json_decode(webdata('category_ids'))) { ?>
														<?php foreach($category_ids as $category_id){ 
														?>
														<?php if($categoryInfo = getCategoryInfo($column='id',$category_id)) { ?>
														<div id="category_ids<?=$categoryInfo->id?>">
														<i class="fa fa-minus-circle"></i> <?=$categoryInfo->title?>
														<input type="hidden" name="category_ids[]" value="<?=$categoryInfo->id?>">
														</div>
														<?php } ?>
														<?php } ?>
														<?php } ?>
														</div>
													</div>
												</div--> 
                      </div>
                      <div class="row">
                        <div class="col-sm-12">
                          <h5 class="alert alert-secondary text-center">Section 3 (Why Choose us Section)</h5>
                        </div>
                        <div class="col-sm-2">
                          <div class="form-group">
                            <label>Is section Enable?</label>
                            <select class="form-control" name="section_3_enable">
                              <option value='1' <?php if(webdata('section_3_enable') == '1'){ echo "selected";}?>>Enable</option>
                              <option value='0' <?php if(webdata('section_3_enable') == '0'){ echo "selected";}?>>Disable</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-sm-5">
                          <div class="form-group">
                            <label>Title</label>
                            <input type="text" name="section_3_title" class="form-control"value="<?=webdata('section_3_title')?>">
                          </div>
                        </div>
                        <div class="col-sm-5">
                          <div class="form-group">
                            <label>Heading</label>
                            <input type="text" name="section_3_heading" class="form-control"value="<?=webdata('section_3_heading')?>">
                          </div>
                        </div>
                        <div class="col-sm-12">
                          <div class="form-group">
                            <label>Description</label>
                            <textarea class="form-control" name="section_3_description"><?=webdata('section_3_description')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Title 1</label>
                            <input type="text" name="section_3_coloum_1_title" class="form-control"value="<?=webdata('section_3_coloum_1_title')?>">
                          </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Description 1</label>
                            <input type="text" name="section_3_coloum_1_description" class="form-control"value="<?=webdata('section_3_coloum_1_description')?>">
                          </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Image 1</label>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="section_3_image_1_thumbnail" data-preview="section_3_image_1" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="section_3_image_1_thumbnail" class="form-control" type="text" name="section_3_coloum_1_image_1_file" value="<?=webdata('section_3_coloum_1_image_1_file')?>">
                            </div>
                            <span id="section_3_image_1" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('section_3_coloum_1_image_1_file'),80,80,false)?>"> </span> </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Title 2</label>
                            <input type="text" name="section_3_coloum_2_title" class="form-control"value="<?=webdata('section_3_coloum_2_title')?>">
                          </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Description 2</label>
                            <input type="text" name="section_3_coloum_2_description" class="form-control"value="<?=webdata('section_3_coloum_2_description')?>">
                          </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Image 2</label>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="section_3_image_2_thumbnail" data-preview="section_3_image_2" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="section_3_image_2_thumbnail" class="form-control" type="text" name="section_3_coloum_2_image_2_file" value="<?=webdata('section_3_coloum_2_image_2_file')?>">
                            </div>
                            <span id="section_3_image_2" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('section_3_coloum_2_image_2_file'),80,80,false)?>"> </span> </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Title 3</label>
                            <input type="text" name="section_3_coloum_3_title" class="form-control"value="<?=webdata('section_3_coloum_3_title')?>">
                          </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Description 3</label>
                            <input type="text" name="section_3_coloum_3_description" class="form-control"value="<?=webdata('section_3_coloum_3_description')?>">
                          </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Image 3</label>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="section_3_image_3_thumbnail" data-preview="section_3_image_3" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="section_3_image_3_thumbnail" class="form-control" type="text" name="section_3_coloum_3_image_3_file" value="<?=webdata('section_3_coloum_3_image_3_file')?>">
                            </div>
                            <span id="section_3_image_3" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('section_3_coloum_3_image_3_file'),80,80,false)?>"> </span> </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Title 4</label>
                            <input type="text" name="section_3_coloum_4_title" class="form-control"value="<?=webdata('section_3_coloum_4_title')?>">
                          </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Description 4</label>
                            <input type="text" name="section_3_coloum_4_description" class="form-control"value="<?=webdata('section_3_coloum_4_description')?>">
                          </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Image 4</label>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="section_3_image_4_thumbnail" data-preview="section_3_image_4" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="section_3_image_4_thumbnail" class="form-control" type="text" name="section_3_coloum_4_image_4_file" value="<?=webdata('section_3_coloum_4_image_4_file')?>">
                            </div>
                            <span id="section_3_image_4" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('section_3_coloum_4_image_4_file'),80,80,false)?>"> </span> </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Title 5</label>
                            <input type="text" name="section_3_coloum_5_title" class="form-control"value="<?=webdata('section_3_coloum_5_title')?>">
                          </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Description 5</label>
                            <input type="text" name="section_3_coloum_5_description" class="form-control"value="<?=webdata('section_3_coloum_5_description')?>">
                          </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Image 5</label>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="section_3_image_5_thumbnail" data-preview="section_3_image_5" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="section_3_image_5_thumbnail" class="form-control" type="text" name="section_3_coloum_5_image_5_file" value="<?=webdata('section_3_coloum_5_image_5_file')?>">
                            </div>
                            <span id="section_3_image_5" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('section_3_coloum_5_image_5_file'),80,80,false)?>"> </span> </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Title 6</label>
                            <input type="text" name="section_3_coloum_6_title" class="form-control"value="<?=webdata('section_3_coloum_6_title')?>">
                          </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Description 6</label>
                            <input type="text" name="section_3_coloum_6_description" class="form-control"value="<?=webdata('section_3_coloum_6_description')?>">
                          </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Image 6</label>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="section_3_image_6_thumbnail" data-preview="section_3_image_6" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="section_3_image_6_thumbnail" class="form-control" type="text" name="section_3_coloum_6_image_6_file" value="<?=webdata('section_3_coloum_6_image_6_file')?>">
                            </div>
                            <span id="section_3_image_6" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('section_3_coloum_6_image_6_file'),80,80,false)?>"> </span> </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-sm-12">
                          <h5 class="alert alert-secondary text-center">Section 4 (Mission & Vission Section)</h5>
                        </div>
                        <div class="col-sm-2">
                          <div class="form-group">
                            <label>Is section Enable?</label>
                            <select class="form-control" name="section_4_enable">
                              <option value='1' <?php if(webdata('section_4_enable') == '1'){ echo "selected";}?>>Enable</option>
                              <option value='0' <?php if(webdata('section_4_enable') == '0'){ echo "selected";}?>>Disable</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-sm-5">
                          <div class="form-group">
                            <label>Mission & Vission Title</label>
                            <input type="text" name="section_3_mission_title" class="form-control" value="<?=webdata('section_3_mission_title')?>">
                          </div>
                        </div>
                        <div class="col-sm-5">
                          <div class="form-group">
                            <label>Mission & Vission Heading</label>
                            <input type="text" name="section_3_mission_heading" class="form-control" value="<?=webdata('section_3_mission_heading')?>">
                          </div>
                        </div>
                        <div class="col-sm-12">
                          <div class="form-group">
                            <label>Mission & Vission Description</label>
                            <textarea class="form-control" name="section_3_mission_description"><?=webdata('section_3_mission_description')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Our Vission Content</label>
                            <textarea class="textarea" id="section_3_vission_content"  name="section_3_vission_content"><?=webdata('section_3_vission_content')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Our Mission Content</label>
                            <textarea class="textarea" id="section_3_mission_content" name="section_3_mission_content"><?=webdata('section_3_mission_content')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Why Us Content</label>
                            <textarea class="textarea" id="section_3_why_us_content" name="section_3_why_us_content"><?=webdata('section_3_why_us_content')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Contact Title</label>
                            <input type="text" name="section_3_contact_title" class="form-control" value="<?=webdata('section_3_contact_title')?>">
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Contact Heading</label>
                            <input type="text" name="section_3_contact_heading" class="form-control" value="<?=webdata('section_3_contact_heading')?>">
                          </div>
                        </div>
                        <div class="col-sm-12">
                          <div class="form-group">
                            <label>Contact Description</label>
                            <textarea class="form-control" name="section_3_contact_description"><?=webdata('section_3_contact_description')?>
</textarea>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-sm-12">
                          <h5 class="alert alert-secondary text-center">Section 4 (Banner Section)</h5>
                        </div>
                        <div class="col-sm-2">
                          <div class="form-group">
                            <label>Is section Enable?</label>
                            <select class="form-control" name="section_4_enable">
                              <option value='1' <?php if(webdata('section_4_enable') == '1'){ echo "selected";}?>>Enable</option>
                              <option value='0' <?php if(webdata('section_4_enable') == '0'){ echo "selected";}?>>Disable</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-sm-5">
                          <div class="form-group">
                            <label>Banner Heading</label>
                            <input type="text" name="section_4_banner_heading" class="form-control" value="<?=webdata('section_4_banner_heading')?>">
                          </div>
                        </div>
                        <div class="col-sm-5">
                          <div class="form-group">
                            <label>Banner Image</label>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="section_4_banner_image" data-preview="section_3_bannerimage" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="section_4_banner_image" class="form-control" type="text" name="section_4_banner_image_file" value="<?=webdata('section_4_banner_image_file')?>">
                            </div>
                            <span id="section_3_bannerimage" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('section_4_banner_image_file'),80,80,false)?>"> </span> </div>
                        </div>
                        <div class="col-sm-12">
                          <div class="form-group">
                            <label>Banner Description</label>
                            <textarea class="form-control" name="section_4_banner_description"><?=webdata('section_4_banner_description')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Button Label</label>
                            <input type="text" name="section_4_button_label" class="form-control" value="<?=webdata('section_4_button_label')?>">
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Button Link</label>
                            <input type="text" name="section_4_button_link" class="form-control" value="<?=webdata('section_4_button_link')?>">
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="tab-pane fade" id="about" role="tabpanel" aria-labelledby="about-tab">
                    <div class="sectiondiv">
                      <div class="row">
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Title</label>
                            <input type="text" class="form-control" name="about_title" value="<?=webdata('about_title')?>">
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Heading</label>
                            <input type="text" class="form-control" name="about_heading_title" value="<?=webdata('about_heading_title')?>">
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Image</label>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="about_us_file_thumbnail" data-preview="about_us_file_file" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="about_us_file_thumbnail" class="form-control" type="text" name="about_us_page_file" value="<?=webdata('about_us_page_file')?>">
                            </div>
                          </div>
                          <span id="about_us_file_file" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('about_us_page_file'),80,80,false)?>"> </span> </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Meta Title</label>
                            <input type="text" class="form-control" name="about_page_title" value="<?=webdata('about_page_title')?>">
                          </div>
                        </div>
                        <div class="col-lg-6">
                          <div class="form-group">
                            <label>About Meta Keyword</label>
                            <textarea name="about_meta_keyword" class="form-control"><?=webdata('about_meta_keyword')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-lg-6">
                          <div class="form-group">
                            <label>About Meta Description</label>
                            <textarea name="about_meta_description" class="form-control"><?=webdata('about_meta_description')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-lg-12">
                          <div class="form-group">
                            <label>Section 1 Heading</label>
                            <input name="our_vission_description"  id="our_vission_description" class="form-control" value="<?=webdata('our_vission_description')?>">
                          </div>
                          <div class="form-group">
                            <label>About Description</label>
                            <textarea name="about_description" class="textarea" id="about2"><?=webdata('about_description')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-lg-6">
                          <div class="form-group">
                            <label>Section 2 heading</label>
                            <input name="goals_and_vission_description"   class="form-control"   id="goals_and_vission_description" value="<?=webdata('goals_and_vission_description')?>">
                          </div>
                        </div>
                        <div class="col-lg-6">
                          <div class="form-group">
                            <label>Section 2 Image</label>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="goals_and_vission_file_thumbnail" data-preview="goals_and_vission_file_file" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="goals_and_vission_file_thumbnail" class="form-control" type="text" name="goals_and_vission_page_file" value="<?=webdata('goals_and_vission_page_file')?>">
                            </div>
                            <span id="goals_and_vission_file_file" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('goals_and_vission_page_file'),80,80,false)?>"> </span> </div>
                        </div>
                        <div class="col-lg-12">
                          <div class="form-group">
                            <label>Section 2 Contrnt</label>
                            <textarea name="about_data" class="textarea"id="about3"><?=webdata('about_data')?>
</textarea>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="tab-pane fade" id="category" role="tabpanel" aria-labelledby="category-tab">
                    <div class="sectiondiv">
                      <div class="row">
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Title</label>
                            <input type="text" class="form-control" name="category_title" value="<?=webdata('category_title')?>">
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Heading</label>
                            <input type="text" class="form-control" name="category_heading" value="<?=webdata('category_heading')?>">
                          </div>
                        </div>
                        <div class="col-sm-12">
                          <div class="form-group">
                            <label>Meta Title</label>
                            <input type="text" class="form-control" name="category_meta_title" value="<?=webdata('category_meta_title')?>">
                          </div>
                        </div>
                        <div class="col-lg-6">
                          <div class="form-group">
                            <label>Meta Keyword</label>
                            <textarea name="category_meta_keyword" class="form-control"><?=webdata('category_meta_keyword')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-lg-6">
                          <div class="form-group">
                            <label>Meta Description</label>
                            <textarea name="category_meta_description" class="form-control"><?=webdata('category_meta_description')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-sm-12">
                          <h5 class="alert alert-secondary text-center">Custom Section</h5>
                        </div>
                        <div class="col-sm-3">
                          <div class="form-group">
                            <label>Column 1</label>
                            <input type="text" class="form-control" name="category_column_1_title" value="<?=webdata('category_column_1_title')?>">
                            <br>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="category_column_1_file_thumbnail" data-preview="category_column_1_file_file" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="category_column_1_file_thumbnail" class="form-control" type="text" name="category_column_1_page_file" value="<?=webdata('category_column_1_page_file')?>">
                            </div>
                            <span id="category_column_1_file_file" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('category_column_1_page_file'),80,80,false)?>"> </span> </div>
                        </div>
                        <div class="col-sm-3">
                          <div class="form-group">
                            <label>Column 2</label>
                            <input type="text" class="form-control" name="category_column_2_title" value="<?=webdata('category_column_2_title')?>">
                            <br>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="category_column_2_file_thumbnail" data-preview="category_column_2_file_file" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="category_column_2_file_thumbnail" class="form-control" type="text" name="category_column_2_page_file" value="<?=webdata('category_column_2_page_file')?>">
                            </div>
                            <span id="category_column_2_file_file" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('category_column_2_page_file'),80,80,false)?>"> </span> </div>
                        </div>
                        <div class="col-sm-3">
                          <div class="form-group">
                            <label>Column 3</label>
                            <input type="text" class="form-control" name="category_column_3_title" value="<?=webdata('category_column_3_title')?>">
                            <br>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="category_column_3_file_thumbnail" data-preview="category_column_3_file_file" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="category_column_3_file_thumbnail" class="form-control" type="text" name="category_column_3_page_file" value="<?=webdata('category_column_3_page_file')?>">
                            </div>
                            <span id="category_column_3_file_file" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('category_column_3_page_file'),80,80,false)?>"> </span> </div>
                        </div>
                        <div class="col-sm-3">
                          <div class="form-group">
                            <label>Column 4</label>
                            <input type="text" class="form-control" name="category_column_4_title" value="<?=webdata('category_column_4_title')?>">
                            <br>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="category_column_4_file_thumbnail" data-preview="category_column_4_file_file" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="category_column_4_file_thumbnail" class="form-control" type="text" name="category_column_4_page_file" value="<?=webdata('category_column_4_page_file')?>">
                            </div>
                            <span id="category_column_4_file_file" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('category_column_4_page_file'),80,80,false)?>"> </span> </div>
                        </div>
                        <div class="col-sm-12">
                          <h5 class="alert alert-secondary text-center">Bottom Content Section</h5>
                        </div>
                        <div class="col-sm-12">
                          <div class="form-group">
                            <label>Image</label>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="category_file_thumbnail" data-preview="category_file_file" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="category_file_thumbnail" class="form-control" type="text" name="category_page_file" value="<?=webdata('category_page_file')?>">
                            </div>
                          </div>
                          <span id="category_file_file" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('category_page_file'),80,80,false)?>"> </span> </div>
                        <div class="col-lg-12">
                          <div class="form-group">
                            <label>Description</label>
                            <textarea name="catetgory_description" class="textarea" id="catetgory_description"><?=webdata('catetgory_description')?>
</textarea>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="tab-pane fade" id="memore" role="tabpanel" aria-labelledby="memore-tab">
                    <div class="sectiondiv">
                      <div class="row">
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Title</label>
                            <input type="text" class="form-control" name="memore_title" value="<?=webdata('memore_title')?>">
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Heading</label>
                            <input type="text" class="form-control" name="memore_heading" value="<?=webdata('memore_heading')?>">
                          </div>
                        </div>
                        <div class="col-sm-12">
                          <div class="form-group">
                            <label>Meta Title</label>
                            <input type="text" class="form-control" name="memore_meta_title" value="<?=webdata('memore_meta_title')?>">
                          </div>
                        </div>
                        <div class="col-lg-6">
                          <div class="form-group">
                            <label>Meta Keyword</label>
                            <textarea name="memore_meta_keyword" class="form-control"><?=webdata('memore_meta_keyword')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-lg-6">
                          <div class="form-group">
                            <label>Meta Description</label>
                            <textarea name="memore_meta_description" class="form-control"><?=webdata('memore_meta_description')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-sm-12">
                          <h5 class="alert alert-secondary text-center">Section 1</h5>
                        </div>
                        <div class="col-sm-2">
                          <div class="form-group">
                            <label>Is section Enable?</label>
                            <select class="form-control" name="memore_section_1_enable">
                              <option value='1' <?php if(webdata('memore_section_1_enable') == '1'){ echo "selected";}?>>Enable</option>
                              <option value='0' <?php if(webdata('memore_section_1_enable') == '0'){ echo "selected";}?>>Disable</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-sm-10">
                          <div class="form-group">
                            <label>Heading</label>
                            <input type="text" class="form-control" name="memore_section_1_heading" value="<?=webdata('memore_section_1_heading')?>">
                          </div>
                        </div>
                        <div class="col-sm-8">
                          <div class="form-group">
                            <label>Image 1</label>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="memore_section_1_row_1_file_thumbnail" data-preview="memore_section_1_row_1_file_file" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="memore_section_1_row_1_file_thumbnail" class="form-control" type="text" name="memore_section_1_row_1_page_file" value="<?=webdata('memore_section_1_row_1_page_file')?>">
                            </div>
                            <span id="memore_section_1_row_1_file_file" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('memore_section_1_row_1_page_file'),80,80,false)?>"> </span> </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Image Heading 1</label>
                            <input type="text" class="form-control" name="memore_section_1_row_1_heading" value="<?=webdata('memore_section_1_row_1_heading')?>">
                          </div>
                        </div>
                        <div class="col-sm-8">
                          <div class="form-group">
                            <label>Image 2</label>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="memore_section_1_row_2_file_thumbnail" data-preview="memore_section_1_row_2_file_file" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="memore_section_1_row_2_file_thumbnail" class="form-control" type="text" name="memore_section_1_row_2_page_file" value="<?=webdata('memore_section_1_row_2_page_file')?>">
                            </div>
                            <span id="memore_section_1_row_2_file_file" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('memore_section_1_row_2_page_file'),80,80,false)?>"> </span> </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Image Heading 2</label>
                            <input type="text" class="form-control" name="memore_section_1_row_2_heading" value="<?=webdata('memore_section_1_row_2_heading')?>">
                          </div>
                        </div>
                        <div class="col-sm-8">
                          <div class="form-group">
                            <label>Image 3</label>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="memore_section_1_row_3_file_thumbnail" data-preview="memore_section_1_row_3_file_file" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="memore_section_1_row_3_file_thumbnail" class="form-control" type="text" name="memore_section_1_row_3_page_file" value="<?=webdata('memore_section_1_row_3_page_file')?>">
                            </div>
                            <span id="memore_section_1_row_3_file_file" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('memore_section_1_row_3_page_file'),80,80,false)?>"> </span> </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Image Heading 3</label>
                            <input type="text" class="form-control" name="memore_section_1_row_3_heading" value="<?=webdata('memore_section_1_row_3_heading')?>">
                          </div>
                        </div>
                        <div class="col-sm-8">
                          <div class="form-group">
                            <label>Image 4</label>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="memore_section_1_row_4_file_thumbnail" data-preview="memore_section_1_row_4_file_file" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="memore_section_1_row_4_file_thumbnail" class="form-control" type="text" name="memore_section_1_row_4_page_file" value="<?=webdata('memore_section_1_row_4_page_file')?>">
                            </div>
                            <span id="memore_section_1_row_4_file_file" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('memore_section_1_row_4_page_file'),80,80,false)?>"> </span> </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Image Heading 4</label>
                            <input type="text" class="form-control" name="memore_section_1_row_4_heading" value="<?=webdata('memore_section_1_row_4_heading')?>">
                          </div>
                        </div>
                        <div class="col-sm-8">
                          <div class="form-group">
                            <label>Image 5</label>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="memore_section_1_row_5_file_thumbnail" data-preview="memore_section_1_row_5_file_file" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="memore_section_1_row_5_file_thumbnail" class="form-control" type="text" name="memore_section_1_row_5_page_file" value="<?=webdata('memore_section_1_row_5_page_file')?>">
                            </div>
                            <span id="memore_section_1_row_5_file_file" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('memore_section_1_row_5_page_file'),80,80,false)?>"> </span> </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Image Heading 5</label>
                            <input type="text" class="form-control" name="memore_section_1_row_5_heading" value="<?=webdata('memore_section_1_row_5_heading')?>">
                          </div>
                        </div>
                        <div class="col-sm-12">
                          <h5 class="alert alert-secondary text-center">Section 3</h5>
                        </div>
                        <div class="col-sm-12">
                          <div class="form-group">
                            <label>Big Image</label>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="memore_section_3_file_thumbnail" data-preview="memore_section_3_file_file" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="memore_section_3_file_thumbnail" class="form-control" type="text" name="memore_section_3_page_file" value="<?=webdata('memore_section_3_page_file')?>">
                            </div>
                            <span id="memore_section_3_file_file" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('memore_section_3_page_file'),80,80,false)?>"> </span> </div>
                        </div>
                        <div class="col-sm-12">
                          <h5 class="alert alert-secondary text-center">Section 4</h5>
                        </div>
                        <div class="col-sm-2">
                          <div class="form-group">
                            <label>Is section Enable?</label>
                            <select class="form-control" name="memore_section_4_enable">
                              <option value='1' <?php if(webdata('memore_section_4_enable') == '1'){ echo "selected";}?>>Enable</option>
                              <option value='0' <?php if(webdata('memore_section_4_enable') == '0'){ echo "selected";}?>>Disable</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-sm-10">
                          <div class="form-group">
                            <label>Heading</label>
                            <input type="text" class="form-control" name="memore_section_4_heading" value="<?=webdata('memore_section_4_heading')?>">
                          </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Row 1</label>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="memore_section_4_row_1_file_thumbnail" data-preview="memore_section_4_row_1_file_file" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="memore_section_4_row_1_file_thumbnail" class="form-control" type="text" name="memore_section_4_row_1_page_file" value="<?=webdata('memore_section_4_row_1_page_file')?>">
                            </div>
                            <span id="memore_section_4_row_1_file_file" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('memore_section_4_row_1_page_file'),80,80,false)?>"> </span>
                            <textarea class="textarea" id="memore_section_4_row_1_content" name="memore_section_4_row_1_content"><?=webdata('memore_section_4_row_1_content')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Row 2</label>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="memore_section_4_row_2_file_thumbnail" data-preview="memore_section_4_row_2_file_file" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="memore_section_4_row_2_file_thumbnail" class="form-control" type="text" name="memore_section_4_row_2_page_file" value="<?=webdata('memore_section_4_row_2_page_file')?>">
                            </div>
                            <span id="memore_section_4_row_2_file_file" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('memore_section_4_row_2_page_file'),80,80,false)?>"> </span>
                            <textarea class="textarea" id="memore_section_4_row_2_content" name="memore_section_4_row_2_content"><?=webdata('memore_section_4_row_2_content')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="form-group">
                            <label>Row 3</label>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="memore_section_4_row_3_file_thumbnail" data-preview="memore_section_4_row_3_file_file" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="memore_section_4_row_3_file_thumbnail" class="form-control" type="text" name="memore_section_4_row_3_page_file" value="<?=webdata('memore_section_4_row_3_page_file')?>">
                            </div>
                            <span id="memore_section_4_row_3_file_file" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('memore_section_4_row_3_page_file'),80,80,false)?>"> </span>
                            <textarea class="textarea" id="memore_section_4_row_3_content" name="memore_section_4_row_3_content"><?=webdata('memore_section_4_row_3_content')?>
</textarea>
                          </div>
                        </div>
                        <div class="col-sm-12">
                          <h5 class="alert alert-secondary text-center">Bottom Content Section</h5>
                        </div>
                        <div class="col-sm-12">
                          <div class="form-group">
                            <label>Image</label>
                            <div class="input-group"> <span class="input-group-btn"><a data-input="memore_file_thumbnail" data-preview="memore_file_file" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a> </span>
                              <input id="memore_file_thumbnail" class="form-control" type="text" name="memore_page_file" value="<?=webdata('memore_page_file')?>">
                            </div>
                          </div>
                          <span id="memore_file_file" style="margin-top:15px;max-height:100px;"> <img src="<?=resizeimg(webdata('memore_page_file'),80,80,false)?>"> </span> </div>
                        <div class="col-lg-12">
                          <div class="form-group">
                            <label>Description</label>
                            <textarea name="memore_description" class="textarea" id="memore_description"><?=webdata('memore_description')?>
</textarea>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="tab-pane fade" id="mail" role="tabpanel" aria-labelledby="mail-tab">
                    <div class="sectiondiv">
                      <div class="row">
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>Mail Engine</label>
                            <select class="form-control" name="config_mail_engine">
                              <option <?php if(webdata('config_mail_engine') == 'SMTP'){ echo "selected";}?>>SMTP</option>
                              <option <?php if(webdata('config_mail_engine') == 'Mail'){ echo "selected";}?>>Mail</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>SMTP Hostname</label>
                            <input type="text" class="form-control" name="config_mail_hostname" value="<?=webdata('config_mail_hostname')?>">
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>SMTP Username</label>
                            <input type="text" class="form-control" name="config_mail_username" value="<?=webdata('config_mail_username')?>">
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>SMTP Password</label>
                            <input type="text" class="form-control" name="config_mail_password" value="<?=webdata('config_mail_password')?>">
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label>SMTP Port</label>
                            <input type="text" class="form-control" name="config_mail_port" value="<?=webdata('config_mail_port')?>">
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-footer">
                <input type="submit" class="btn btn-primary" value="Submit">
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
<script>
// Sliding
$('input[name=\'product\']').autocomplete({
	'source': function(request, response) {
		$.ajax({
			url: '<?php echo url(config('global.ADMIN_URL').'/product/autocomplete?filter_name=')?>'+encodeURIComponent(request),
			dataType: 'json',
			success: function(json) {
				response($.map(json, function(item) {
					return {
						label: item['name'],
						value: item['product_id']
					}
				}));
			}
		});
	},
	'select': function(item) {
		$('input[name=\'product\']').val('');
		$('#product_ids' + item['value']).remove();
		$('#product_ids').append('<div id="product_ids' + item['value'] + '"><i class="fa fa-minus-circle"></i> ' + item['label'] + '<input type="hidden" name="product_ids[]" value="' + item['value'] + '" /></div>');
	}
});

$('#product_ids').delegate('.fa-minus-circle', 'click', function() {
	$(this).parent().remove();
});
</script> 
@endsection