@extends('admin.layout.layout')
@section('content')
<div class="content-wrapper">
    <div class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?=$pageheading?></h1>
				</div>
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="<?=url(config('global.ADMIN_URL').'/dashboard')?>">Dashboard</a></li>
						<li class="breadcrumb-item active"><?=$pageheading?></li>
					</ol>
				</div>
			</div>
		</div>
    </div>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-secondary">
						
							@if ($error = Session::get('error'))
								<div class="card card-danger">
									<div class="card-header">
										<h3 class="card-title">{{$error}}</h3>
										<div class="card-tools">
											<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
											</button>
										</div>
									</div>
								</div>
							@endif
							
							@if ($success = Session::get('success'))
								<div class="card card-success">
									<div class="card-header">
										<h3 class="card-title">{{$success}}</h3>
										<div class="card-tools">
											<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
											</button>
										</div>
									</div>
								</div>
							@endif
						
						<div class="card-body">
							<div class="row">
								<div class="col-sm-6">
									<div class="form-group">
										<a class="btn btn-primary" href="<?=url(config('global.ADMIN_URL').'/clear-cache')?>" target="_blank">Clear Cache</a>
									</div>
								</div>
								<div class="col-sm-6">
									<div class="form-group">
										<a class="btn btn-info" href="<?=url(config('global.ADMIN_URL').'/clear-route-cache')?>" target="_blank">Clear Route Cache</a>
									</div>
								</div>
								<div class="col-sm-6">
									<div class="form-group">
										<a class="btn btn-secondary" href="<?=url(config('global.ADMIN_URL').'/clear-view-compiled-cache')?>" target="_blank">Clear View Compiled Cache</a>
									</div>
								</div>
								<div class="col-sm-6">
									<div class="form-group">
										<a class="btn btn-warning" href="<?=url(config('global.ADMIN_URL').'/clear-config-cache')?>" target="_blank">Clear Config Cache</a>
									</div>
								</div>
								<div class="col-sm-6">
									<div class="form-group">
										<a class="btn btn-success" href="<?=url(config('global.ADMIN_URL').'/image-cache')?>">Clear Image Cache</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
    </section>
</div>







@endsection