<script type="text/javascript">
$(document).ready(function () {
	$.validator.setDefaults({
	});
	$('#quickForm').validate({
		rules: {
			pid:{ required:true, },  	  
			title:{ required:true, },  	  
			heading:{ required:true, },  	  
			meta_title:{ required:true, },  	  
			slug:{ required:true, },  	  
		},
		errorElement: 'span',
		errorPlacement: function (error, element) {
			error.addClass('invalid-feedback');
			element.closest('.form-group').append(error);
		},
		highlight: function (element, errorClass, validClass) {
			$(element).addClass('is-invalid');
		},
		unhighlight: function (element, errorClass, validClass) {
			$(element).removeClass('is-invalid');
		}
	});
});


// Sliding
$('input[name=\'category\']').autocomplete({
	'source': function(request, response) {
		$.ajax({
			url: '<?php echo url(config('global.ADMIN_URL').'/category/autocomplete?filter_name=')?>'+encodeURIComponent(request),
			dataType: 'json',
			success: function(json) {
				response($.map(json, function(item) {
					return {
						label: item['name'],
						value: item['category_id']
					}
				}));
			}
		});
	},
	'select': function(item) {
		$('input[name=\'category\']').val('');
		$('#category_ids' + item['value']).remove();
		$('#category_ids').append('<div id="category_ids' + item['value'] + '"><i class="fa fa-minus-circle"></i> ' + item['label'] + '<input type="hidden" name="category_ids[]" value="' + item['value'] + '" /></div>');
	}
});

$('#category_ids').delegate('.fa-minus-circle', 'click', function() {
	$(this).parent().remove();
});
</script>