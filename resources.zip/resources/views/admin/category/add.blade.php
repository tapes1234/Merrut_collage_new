@extends('admin.layout.layout')
@section('content')
<div class="content-wrapper">
    <div class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?=$pageheading?></h1>
				</div>
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="<?=url(config('global.ADMIN_URL').'/dashboard')?>">Dashboard</a></li>
						<li class="breadcrumb-item active"><?=$pageheading?></li>
					</ol>
				</div>
			</div>
		</div>
    </div>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-secondary">
						<div class="card card-danger">
							@if ($error = Session::get('error'))
								<div class="card-header">
									<h3 class="card-title">{{$error}}</h3>
									<div class="card-tools">
										<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
										</button>
									</div>
								</div>
							@endif
						</div>
						<form method="post" id="quickForm" enctype="multipart/form-data">
							@csrf
							<div class="card-body">
							
								<div class="row">		
									<div class="col-sm-6">
										<div class="form-group">
											<label>Select parent <span class="text-danger">*</span></label>
											<select name="pid" class="form-control">
												<option value="" hidden> --Select-- </option>
												<option value="0"> Self </option>
												<?php foreach($getAllCategory as $category) { ?>
													<option value="<?=$category->id?>"><?=$category->title?></option>
												<?php } ?>
											</select>
										</div>
									</div>						
									<div class="col-sm-6">
										<div class="form-group">
											<label>Title <span class="text-danger">*</span></label>
											<input type="text"   class="form-control" name="title">
										</div>
									</div>						
									<div class="col-sm-6">
										<div class="form-group">
											<label>Heading  <span class="text-danger">*</span></label>
											<input type="text" class="form-control" name="heading">
										</div>
									</div>	
									<div class="col-sm-3">
										<div class="form-group">
											<label>Category <span class="text-danger">*</span></label>
											<input type="text" name="slug" class="form-control" >
										</div>
									</div>	
                                    
                                    <div class="col-sm-3">
										<div class="form-group">
											<label>Category Type</label>
											<select class="form-control" name="cattype">
                                            <option  selected="selected" >Select</option>
												<option value="academics" >academics</option>
												<option value="beyond-academics">beyond-academics</option>
											</select>
										</div>
									</div>	
                                    
									<div class="col-sm-3">
										<div class="form-group">
											<label>Top</label>
											<select class="form-control" name="top">
												<option value="1" >Enable</option>
												<option value="0">Disable</option>
											</select>
										</div>
									</div>	
									<div class="col-sm-3">
										<div class="form-group">
											<label>Bottom</label>
											<select class="form-control" name="bottom">
												<option value="1" >Enable</option>
												<option value="0">Disable</option>
											</select>
										</div>
									</div>	
									<div class="col-sm-3">
										<div class="form-group">
											<label>Status</label>
											<select class="form-control" name="status">
												<option value="1" >Enable</option>
												<option value="0">Disable</option>
											</select>
										</div>
									</div>						
									<div class="col-sm-3">
										<div class="form-group">
											<label>Sort</label>
											<input type="number" class="form-control" name="sort" min="0">
										</div>
									</div>	
									<div class="col-sm-6">
										<div class="form-group">
											<label>Meta Title <span class="text-danger">*</span></label>
											<textarea class="form-control" name="meta_title"></textarea>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<label>Meta Keyword</label>
											<textarea class="form-control" name="meta_keyword"></textarea>
										</div>
									</div>
									<div class="col-sm-12">
										<div class="form-group">
											<label>Meta Description</label>
											<textarea class="form-control" name="meta_description"></textarea>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<label>Image</label>
											<div class="input-group">
												<span class="input-group-btn">
													<a data-input="image" data-preview="image_holder" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a>
												</span>
												<input id="image" class="form-control" type="text" name="image">
											</div>
											<div id="image_holder" style="margin-top:15px;max-height:100px;"></div>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<label>Banner</label>
											<div class="input-group">
												<span class="input-group-btn">
													<a data-input="banner" data-preview="banner_holder" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a>
												</span>
												<input id="banner" class="form-control" type="text" name="banner">
											</div>
											<div id="banner_holder" style="margin-top:15px;max-height:100px;"></div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="form-group">
											<label>Image (1)</label>
											<div class="input-group">
												<span class="input-group-btn">
													<a data-input="image1" data-preview="image1_holder" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a>
												</span>
												<input id="image1" class="form-control" type="text" name="image1">
											</div>
											<div id="image1_holder" style="margin-top:15px;max-height:100px;"></div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="form-group">
											<label>Image (2)</label>
											<div class="input-group">
												<span class="input-group-btn">
													<a data-input="image2" data-preview="image2_holder" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a>
												</span>
												<input id="image2" class="form-control" type="text" name="image2">
											</div>
											<div id="image2_holder" style="margin-top:15px;max-height:100px;"></div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="form-group">
											<label>Image (3)</label>
											<div class="input-group">
												<span class="input-group-btn">
													<a data-input="image3" data-preview="image3_holder" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a>
												</span>
												<input id="image3" class="form-control" type="text" name="image3">
											</div>
											<div id="image3_holder" style="margin-top:15px;max-height:100px;"></div>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<label>Image (4)</label>
											<div class="input-group">
												<span class="input-group-btn">
													<a data-input="image4" data-preview="image4_holder" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a>
												</span>
												<input id="image4" class="form-control" type="text" name="image4">
											</div>
											<div id="image4_holder" style="margin-top:15px;max-height:100px;"></div>
										</div>
									</div>	
									<div class="col-sm-6">
										<div class="form-group">
											<label>Image (5)</label>
											<div class="input-group">
												<span class="input-group-btn">
													<a data-input="image5" data-preview="image5_holder" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a>
												</span>
												<input id="image5" class="form-control" type="text" name="image5">
											</div>
											<div id="image5_holder" style="margin-top:15px;max-height:100px;"></div>
										</div>
									</div>
									<div class="col-sm-12">
										<div class="form-group">
											<label>Short Description</label>
											<textarea class="textarea" id="short_description" name="short_description"></textarea>
										</div>
									</div>
									<div class="col-sm-12">
										<div class="form-group">
											<label>Description</label>
											<textarea class="textarea" id="description" name="description"></textarea>
										</div>
									</div>
									<div class="col-sm-12">
										<div class="form-group">
											<label>Custom Data</label>
											<textarea class="textarea" id="custom_data" name="custom_data"></textarea>
										</div>
									</div>
									<div class="col-sm-12">
										<div class="form-group">
											<label>Related Service</label>
											<input type="text" name="category" value="" placeholder="Category" id="input-category" class="form-control"/>
											<div id="category_ids" class="well well-sm" style="height: 150px; overflow: auto;background: #ececec;padding: 10px;">
											
											</div>
										</div>
									</div>
								</div>
								
							</div>
							<div class="card-footer">
								<input type="submit" class="btn btn-primary" value="Submit" name="submit">
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
    </section>
</div>

@include('admin.category.script')
@endsection