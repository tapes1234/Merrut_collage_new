@extends('admin.layout.layout')
@section('content')
<div class="content-wrapper">
    <div class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?=$pageheading?></h1>
				</div>
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="<?=url(config('global.ADMIN_URL').'/dashboard')?>">Dashboard</a></li>
						<li class="breadcrumb-item active"><?=$pageheading?></li>
					</ol>
				</div>
			</div>
		</div>
    </div>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-secondary">
						<div class="card card-danger">
							@if ($error = Session::get('error'))
								<div class="card-header">
									<h3 class="card-title">{{$error}}</h3>
									<div class="card-tools">
										<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
										</button>
									</div>
								</div>
							@endif
						</div>
						<form method="post" id="quickForm" enctype="multipart/form-data">
							@csrf
							<div class="card-body">
								<div class="row">		
									<div class="col-sm-6">
										<div class="form-group">
											<label>Name <span class="text-danger">*</span></label>
											<input type="text"   class="form-control" name="name">
										</div>
									</div>						
													
										
									<div class="col-sm-6">
										<div class="form-group">
											<label>Year</label>
											<input type="text" name="link" class="form-control" >
										</div>
									</div>						
									<div class="col-sm-6">
										<div class="form-group">
											<label> Image</label>
											<div class="input-group">
												<span class="input-group-btn">
													<a data-input="image" data-preview="image_holder" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a>
												</span>
												<input id="image" class="form-control" type="text" name="image">
											</div>
											<div id="image_holder" style="margin-top:15px;max-height:100px;"></div>
										</div>
									</div>	
                                    
                                    
                                    
                                    
                                    <div class="col-sm-6">
										<div class="form-group">
											<label>Banner Image</label>
											<div class="input-group">
												<span class="input-group-btn">
													<a data-input="banner" data-preview="bannere_holder" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a>
												</span>
												<input id="banner" class="form-control" type="text" name="banner">
											</div>
											<div id="banner_holder" style="margin-top:15px;max-height:100px;"></div>
										</div>
									</div>
                                    
                                    
                                    <div class="col-sm-6">
										<div class="form-group">
											<label>Status</label>
											<select class="form-control" name="status">
												<option value="1" >Enable</option>
												<option value="0">Disable</option>
											</select>
										</div>
									</div>						
									<div class="col-sm-6">
										<div class="form-group">
											<label>Sort</label>
											<input type="number" class="form-control" name="sort" value="">
										</div>
									</div>
                                    
									
								</div>
							</div>
							<div class="card-footer">
								<input type="submit" class="btn btn-primary" value="Submit" name="submit">
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
    </section>
</div>
<script type="text/javascript">
$(document).ready(function () {
	$.validator.setDefaults({
	});
	$('#quickForm').validate({
		rules: {
			name:{ required:true, },  	  
		},
		errorElement: 'span',
		errorPlacement: function (error, element) {
			error.addClass('invalid-feedback');
			element.closest('.form-group').append(error);
		},
		highlight: function (element, errorClass, validClass) {
			$(element).addClass('is-invalid');
		},
		unhighlight: function (element, errorClass, validClass) {
			$(element).removeClass('is-invalid');
		}
	});
});
</script>

@endsection