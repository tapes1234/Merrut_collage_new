@extends('admin.layout.layout')
@section('content')
<div class="content-wrapper">
    <div class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?=$pageheading?></h1>
				</div>
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="<?=url(config('global.ADMIN_URL').'/dashboard')?>">Dashboard</a></li>
						<li class="breadcrumb-item active"><?=$pageheading?></li>
					</ol>
				</div>
			</div>
		</div>
    </div>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-secondary">
						<div class="card card-danger">
							@if ($error = Session::get('error'))
								<div class="card-header">
									<h3 class="card-title">{{$error}}</h3>
									<div class="card-tools">
										<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
										</button>
									</div>
								</div>
							@endif
						</div>
						<form method="post" id="quickForm" enctype="multipart/form-data">
							@csrf
							<div class="card-body">
								<div class="row">		
									<div class="col-sm-6">
										<div class="form-group">
											<label>Username <span class="text-danger">*</span></label>
											<input type="text"   class="form-control" name="username" value="<?=$pageInfo->username?>">
										</div>
									</div>		
									<div class="col-sm-6">
										<div class="form-group">
											<label>Password </label>
											<input type="text"   class="form-control" name="password">
										</div>
									</div>	
									<div class="col-sm-6">
										<div class="form-group">
											<label>Status</label>
											<select name="status" class="form-control">
												<option value="1" <?php if($pageInfo->username == '1'){ echo "selected";}?>>Enable</option>
												<option value="0" <?php if($pageInfo->username == '0'){ echo "selected";}?>>Disable</option>
											</select>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<h6 class="alert alert-secondary">Roles & Permission</h6>
									</div>
									<div class="col-lg-4">
										<div class="form-group">
											<label>Banner Manager</label><br>
											<input type="checkbox" name="roles[view_banner]" value="view_banner" <?php if(isset($roles->view_banner) && $roles->view_banner == 'view_banner'){ echo "checked"; }?>> View Banner <br>
											<input type="checkbox" name="roles[add_banner]" value="add_banner" <?php if(isset($roles->add_banner) && $roles->add_banner == 'add_banner'){ echo "checked"; }?>> Add Banner <br>
											<input type="checkbox" name="roles[edit_banner]" value="edit_banner" <?php if(isset($roles->edit_banner) && $roles->edit_banner == 'edit_banner'){ echo "checked"; }?>> Edit Banner <br>
											<input type="checkbox" name="roles[delete_banner]" value="delete_banner" <?php if(isset($roles->delete_banner) && $roles->delete_banner == 'delete_banner'){ echo "checked"; }?>> Delete Banner <br>
										</div>
									</div>		
									<div class="col-lg-4">
										<div class="form-group">
											<label>Page Manager</label><br>
											<input type="checkbox" name="roles[view_page]" value="view_page" <?php if(isset($roles->view_page) && $roles->view_page == 'view_page'){ echo "checked"; }?>> View Page <br>
											<input type="checkbox" name="roles[add_page]" value="add_page" <?php if(isset($roles->add_page) && $roles->add_page == 'add_page'){ echo "checked"; }?>> Add Page <br>
											<input type="checkbox" name="roles[edit_page]" value="edit_page" <?php if(isset($roles->edit_page) && $roles->edit_page == 'edit_page'){ echo "checked"; }?>> Edit Page <br>
											<input type="checkbox" name="roles[delete_page]" value="delete_page" <?php if(isset($roles->delete_page) && $roles->delete_page == 'delete_page'){ echo "checked"; }?>> Delete Page <br>
										</div>
									</div>	
									
									<div class="col-lg-4">
										<div class="form-group">
											<label>Testimonial Manager</label><br>
											<input type="checkbox" name="roles[view_testimonial]" value="view_testimonial" <?php if(isset($roles->view_testimonial) && $roles->view_testimonial == 'view_testimonial'){ echo "checked"; }?>> View Testimonial <br>
											<input type="checkbox" name="roles[add_testimonial]" value="add_testimonial" <?php if(isset($roles->add_testimonial) && $roles->add_testimonial == 'add_testimonial'){ echo "checked"; }?>> Add Testimonial <br>
											<input type="checkbox" name="roles[edit_testimonial]" value="edit_testimonial" <?php if(isset($roles->edit_testimonial) && $roles->edit_testimonial == 'edit_testimonial'){ echo "checked"; }?>> Edit Testimonial <br>
											<input type="checkbox" name="roles[delete_testimonial]" value="delete_testimonial" <?php if(isset($roles->delete_testimonial) && $roles->delete_testimonial == 'delete_testimonial'){ echo "checked"; }?>> Delete Testimonial <br>
										</div>
									</div>
									
									<!--div class="col-lg-4">
										<div class="form-group">
											<label>Team Manager</label><br>
											<input type="checkbox" name="roles[view_team]" value="view_team" <?php if(isset($roles->view_team) && $roles->view_team == 'view_team'){ echo "checked"; }?>> View Team <br>
											<input type="checkbox" name="roles[add_team]" value="add_team" <?php if(isset($roles->add_team) && $roles->add_team == 'add_team'){ echo "checked"; }?>> Add Team <br>
											<input type="checkbox" name="roles[edit_team]" value="edit_team" <?php if(isset($roles->edit_team) && $roles->edit_team == 'edit_team'){ echo "checked"; }?>> Edit Team <br>
											<input type="checkbox" name="roles[delete_team]" value="delete_team" <?php if(isset($roles->delete_team) && $roles->delete_team == 'delete_team'){ echo "checked"; }?>> Delete Team <br>
										</div>
									</div-->
									<div class="col-lg-4">
										<div class="form-group">
											<label>Client Manager</label><br>
											<input type="checkbox" name="roles[view_client]" value="view_client" <?php if(isset($roles->view_client) && $roles->view_client == 'view_client'){ echo "checked"; }?>> View Client <br>
											<input type="checkbox" name="roles[add_client]" value="add_client" <?php if(isset($roles->add_client) && $roles->add_client == 'add_client'){ echo "checked"; }?>> Add Client <br>
											<input type="checkbox" name="roles[edit_client]" value="edit_client" <?php if(isset($roles->edit_client) && $roles->edit_client == 'edit_client'){ echo "checked"; }?>> Edit Client <br>
											<input type="checkbox" name="roles[delete_client]" value="delete_client" <?php if(isset($roles->delete_client) && $roles->delete_client == 'delete_client'){ echo "checked"; }?>> Delete Client <br>
										</div>
									</div>	
									
									<div class="col-lg-4">
										<div class="form-group">
											<label>Location Manager</label><br>
											<input type="checkbox" name="roles[view_location]" value="view_location" <?php if(isset($roles->view_location) && $roles->view_location == 'view_location'){ echo "checked"; }?>> View Location <br>
											<input type="checkbox" name="roles[add_location]" value="add_location" <?php if(isset($roles->add_location) && $roles->add_location == 'add_location'){ echo "checked"; }?>> Add Location <br>
											<input type="checkbox" name="roles[edit_location]" value="edit_location" <?php if(isset($roles->edit_location) && $roles->edit_location == 'edit_location'){ echo "checked"; }?>> Edit Location <br>
											<input type="checkbox" name="roles[delete_location]" value="delete_location" <?php if(isset($roles->delete_location) && $roles->delete_location == 'delete_location'){ echo "checked"; }?>> Delete Location <br>
										</div>
									</div>
									
									<!--div class="col-lg-4">
										<div class="form-group">
											<label>Portfolio Manager</label><br>
											<input type="checkbox" name="roles[view_portfolio]" value="view_portfolio" <?php if(isset($roles->view_portfolio) && $roles->view_portfolio == 'view_portfolio'){ echo "checked"; }?>> View Portfolio <br>
											<input type="checkbox" name="roles[add_portfolio]" value="add_portfolio" <?php if(isset($roles->add_portfolio) && $roles->add_portfolio == 'add_portfolio'){ echo "checked"; }?>> Add Portfolio <br>
											<input type="checkbox" name="roles[edit_portfolio]" value="edit_portfolio" <?php if(isset($roles->edit_portfolio) && $roles->edit_portfolio == 'edit_portfolio'){ echo "checked"; }?>> Edit Portfolio <br>
											<input type="checkbox" name="roles[delete_portfolio]" value="delete_portfolio" <?php if(isset($roles->delete_portfolio) && $roles->delete_portfolio == 'delete_portfolio'){ echo "checked"; }?>> Delete Portfolio <br>
										</div>
									</div-->	
									<div class="col-lg-4">
										<div class="form-group">
											<label>Category Manager</label><br>
											<input type="checkbox" name="roles[view_category]" value="view_category" <?php if(isset($roles->view_category) && $roles->view_category == 'view_category'){ echo "checked"; }?>> View Category <br>
											<input type="checkbox" name="roles[add_category]" value="add_category" <?php if(isset($roles->add_category) && $roles->add_category == 'add_category'){ echo "checked"; }?>> Add Category <br>
											<input type="checkbox" name="roles[edit_category]" value="edit_category" <?php if(isset($roles->edit_category) && $roles->edit_category == 'edit_category'){ echo "checked"; }?>> Edit Category <br>
											<input type="checkbox" name="roles[delete_category]" value="delete_category" <?php if(isset($roles->delete_category) && $roles->delete_category == 'delete_category'){ echo "checked"; }?>> Delete Category <br>
										</div>
									</div>	
									<div class="col-lg-4">
										<div class="form-group">
											<label>Product Manager</label><br>
											<input type="checkbox" name="roles[view_product]" value="view_product" <?php if(isset($roles->view_product) && $roles->view_product == 'view_product'){ echo "checked"; }?>> View Product <br>
											<input type="checkbox" name="roles[add_product]" value="add_product" <?php if(isset($roles->add_product) && $roles->add_product == 'add_product'){ echo "checked"; }?>> Add Product <br>
											<input type="checkbox" name="roles[edit_product]" value="edit_product" <?php if(isset($roles->edit_product) && $roles->edit_product == 'edit_product'){ echo "checked"; }?>> Edit Product <br>
											<input type="checkbox" name="roles[delete_product]" value="delete_product" <?php if(isset($roles->delete_product) && $roles->delete_product == 'delete_product'){ echo "checked"; }?>> Delete Product <br>
										</div>
									</div>	
									
									<!--div class="col-lg-4">
										<div class="form-group">
											<label>Landing Page Manager</label><br>
											<input type="checkbox" name="roles[view_landing_page]" value="view_landing_page" <?php if(isset($roles->view_landing_page) && $roles->view_landing_page == 'view_landing_page'){ echo "checked"; }?>> View Landing Page <br>
											<input type="checkbox" name="roles[add_landing_page]" value="add_landing_page" <?php if(isset($roles->add_landing_page) && $roles->add_landing_page == 'add_landing_page'){ echo "checked"; }?> > Add Landing Page <br>
											<input type="checkbox" name="roles[edit_landing_page]" value="edit_landing_page" <?php if(isset($roles->edit_landing_page) && $roles->edit_landing_page == 'edit_landing_page'){ echo "checked"; }?>> Edit Landing Page <br>
											<input type="checkbox" name="roles[delete_landing_page]" value="delete_landing_page" <?php if(isset($roles->delete_landing_page) && $roles->delete_landing_page == 'delete_landing_page'){ echo "checked"; }?>> Delete Landing Page <br>
										</div>
									</div-->
									
									<div class="col-lg-4">
										<div class="form-group">
											<label>Blog Category Manager</label><br>
											<input type="checkbox" name="roles[view_blog_category]" value="view_blog_category" <?php if(isset($roles->view_blog_category) && $roles->view_blog_category == 'view_blog_category'){ echo "checked"; }?>> View Blog Category <br>
											<input type="checkbox" name="roles[add_blog_category]" value="add_blog_category" <?php if(isset($roles->add_blog_category) && $roles->add_blog_category == 'add_blog_category'){ echo "checked"; }?> > Add Blog Category <br>
											<input type="checkbox" name="roles[edit_blog_category]" value="edit_blog_category" <?php if(isset($roles->edit_blog_category) && $roles->edit_blog_category == 'edit_blog_category'){ echo "checked"; }?>> Edit Blog Category <br>
											<input type="checkbox" name="roles[delete_blog_category]" value="delete_blog_category" <?php if(isset($roles->delete_blog_category) && $roles->delete_blog_category == 'delete_blog_category'){ echo "checked"; }?>> Delete Blog Category <br>
										</div>
									</div>
									<div class="col-lg-4">
										<div class="form-group">
											<label>Blog Manager</label><br>
											<input type="checkbox" name="roles[view_blog]" value="view_blog" <?php if(isset($roles->view_blog) && $roles->view_blog == 'view_blog'){ echo "checked"; }?>> View Blog <br>
											<input type="checkbox" name="roles[add_blog]" value="add_blog" <?php if(isset($roles->add_blog) && $roles->add_blog == 'add_blog'){ echo "checked"; }?>> Add Blog <br>
											<input type="checkbox" name="roles[edit_blog]" value="edit_blog" <?php if(isset($roles->edit_blog) && $roles->edit_blog == 'edit_blog'){ echo "checked"; }?>> Edit Blog <br>
											<input type="checkbox" name="roles[delete_blog]" value="delete_blog" <?php if(isset($roles->delete_blog) && $roles->delete_blog == 'delete_blog'){ echo "checked"; }?>> Delete Blog<br>
										</div>
									</div>
									<!--div class="col-lg-4">
										<div class="form-group">
											<label>Blog Comment Manager</label><br>
											<input type="checkbox" name="roles[view_blog_comment]" value="view_blog_comment"<?php if(isset($roles->view_blog_comment) && $roles->view_blog_comment == 'view_blog_comment'){ echo "checked"; }?>> View Blog Comment <br>
											<input type="checkbox" name="roles[active_blog_comment]" value="active_blog_comment" <?php if(isset($roles->active_blog_comment) && $roles->active_blog_comment == 'active_blog_comment'){ echo "checked"; }?> > Active Blog Comment<br>
											<input type="checkbox" name="roles[deactive_blog_comment]" value="deactive_blog_comment" <?php if(isset($roles->deactive_blog_comment) && $roles->deactive_blog_comment == 'deactive_blog_comment'){ echo "checked"; }?>> Deactive Blog Comment <br>
											<input type="checkbox" name="roles[delete_blog_comment]" value="delete_blog_comment" <?php if(isset($roles->delete_blog_comment) && $roles->delete_blog_comment == 'delete_blog_comment'){ echo "checked"; }?>> Delete Blog Comment<br>
										</div>
									</div-->
									
									<div class="col-lg-4">
										<div class="form-group">
											<label>Users Manager</label><br>
											<input type="checkbox" name="roles[view_users]" value="view_users" <?php if(isset($roles->view_users) && $roles->view_users == 'view_users'){ echo "checked"; }?>> View Users <br>
											<input type="checkbox" name="roles[add_users]" value="add_users" <?php if(isset($roles->add_users) && $roles->add_users == 'add_users'){ echo "checked"; }?>> Add Users <br>
											<input type="checkbox" name="roles[edit_users]" value="edit_users" <?php if(isset($roles->edit_users) && $roles->edit_users == 'edit_users'){ echo "checked"; }?>> Edit Users <br>
											<input type="checkbox" name="roles[delete_users]" value="delete_users" <?php if(isset($roles->delete_users) && $roles->delete_users == 'delete_users'){ echo "checked"; }?>> Delete Users<br>
										</div>
									</div>
									<div class="col-lg-4">
										<div class="form-group">
											<label>Analytical Manager</label><br>
											<input type="checkbox" name="roles[view_analytical]" value="view_analytical" <?php if(isset($roles->view_analytical) && $roles->view_analytical == 'view_analytical'){ echo "checked"; }?>> View Analytical <br>
											<input type="checkbox" name="roles[add_analytical]" value="add_analytical" <?php if(isset($roles->add_analytical) && $roles->add_analytical == 'add_analytical'){ echo "checked"; }?>> Add Analytical <br>
											<input type="checkbox" name="roles[edit_analytical]" value="edit_analytical" <?php if(isset($roles->edit_analytical) && $roles->edit_analytical == 'edit_analytical'){ echo "checked"; }?>> Edit Analytical <br>
											<input type="checkbox" name="roles[delete_analytical]" value="delete_analytical" <?php if(isset($roles->delete_analytical) && $roles->delete_analytical == 'delete_analytical'){ echo "checked"; }?>> Delete Analytical<br>
										</div>
									</div>
									<div class="col-lg-4">
										<div class="form-group">
											<label>FAQ's Manager</label><br>
											<input type="checkbox" name="roles[view_faq]" value="view_faq" <?php if(isset($roles->view_faq) && $roles->view_faq == 'view_faq'){ echo "checked"; }?>> View Faq <br>
											<input type="checkbox" name="roles[add_faq]" value="add_faq" <?php if(isset($roles->add_faq) && $roles->add_faq == 'add_faq'){ echo "checked"; }?>>  Add Faq <br>
											<input type="checkbox" name="roles[edit_faq]" value="edit_faq" <?php if(isset($roles->edit_faq) && $roles->edit_faq == 'edit_faq'){ echo "checked"; }?>> Edit Faq <br>
											<input type="checkbox" name="roles[delete_faq]" value="delete_faq" <?php if(isset($roles->delete_faq) && $roles->delete_faq == 'delete_faq'){ echo "checked"; }?>> Delete Faq<br>
										</div>
									</div>
									<div class="col-lg-4">
										<div class="form-group">
											<label>Redirect Url Manager</label><br>
											<input type="checkbox" name="roles[view_redirect]" value="view_redirect" <?php if(isset($roles->view_redirect) && $roles->view_redirect == 'view_redirect'){ echo "checked"; }?>> View Redirect <br>
											<input type="checkbox" name="roles[add_redirect]" value="add_redirect" <?php if(isset($roles->add_redirect) && $roles->add_redirect == 'add_redirect'){ echo "checked"; }?>>  Add Redirect <br>
											<input type="checkbox" name="roles[edit_redirect]" value="edit_redirect" <?php if(isset($roles->edit_redirect) && $roles->edit_redirect == 'edit_redirect'){ echo "checked"; }?>> Edit Redirect <br>
											<input type="checkbox" name="roles[delete_redirect]" value="delete_redirect" <?php if(isset($roles->delete_redirect) && $roles->delete_redirect == 'delete_redirect'){ echo "checked"; }?>> Delete Redirect<br>
										</div>
									</div>
									<div class="col-lg-4">
										<div class="form-group">
											<label>Enquiry Manager</label><br>
											<input type="checkbox" name="roles[view_enquiry]" value="view_enquiry" <?php if(isset($roles->view_enquiry) && $roles->view_enquiry == 'view_enquiry'){ echo "checked"; }?>> View Enquiry <br>
											<!--input type="checkbox" name="roles[add_enquiry]" value="add_enquiry" <?php if(isset($roles->add_enquiry) && $roles->add_enquiry == 'add_enquiry'){ echo "checked"; }?>>  Add Enquiry <br>
											<input type="checkbox" name="roles[edit_enquiry]" value="edit_enquiry" <?php if(isset($roles->edit_enquiry) && $roles->edit_enquiry == 'edit_enquiry'){ echo "checked"; }?>> Edit Enquiry <br-->
											<input type="checkbox" name="roles[delete_enquiry]" value="delete_enquiry" <?php if(isset($roles->delete_enquiry) && $roles->delete_enquiry == 'delete_enquiry'){ echo "checked"; }?>> Delete Enquiry<br>
											<input type="checkbox" name="roles[download_enquiry_xlsx]" value="download_enquiry_xlsx" <?php if(isset($roles->download_enquiry_xlsx) && $roles->download_enquiry_xlsx == 'download_enquiry_xlsx'){ echo "checked"; }?>> Download Enquiry (xlsx)<br>
										</div>
									</div>
									<div class="col-lg-4">
										<div class="form-group">
										
											<input type="checkbox" name="roles[websetting]" value="websetting" <?php if(isset($roles->websetting) && $roles->websetting == 'websetting'){ echo "checked"; }?>> Web Setting <br>
											<input type="checkbox" name="roles[cache]" value="cache" <?php if(isset($roles->cache) && $roles->cache == 'cache'){ echo "checked"; }?>> Cache<br>
											
										</div>
									</div>
								</div>
							</div>
							<div class="card-footer">
								<input type="submit" class="btn btn-primary" value="Submit" name="submit">
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
    </section>
</div>
<script type="text/javascript">
$(document).ready(function () {
	$.validator.setDefaults({
	});
	$('#quickForm').validate({
		rules: {
			username:{ required:true, },  	    
		},
		errorElement: 'span',
		errorPlacement: function (error, element) {
			error.addClass('invalid-feedback');
			element.closest('.form-group').append(error);
		},
		highlight: function (element, errorClass, validClass) {
			$(element).addClass('is-invalid');
		},
		unhighlight: function (element, errorClass, validClass) {
			$(element).removeClass('is-invalid');
		}
	});
});
</script>

@endsection