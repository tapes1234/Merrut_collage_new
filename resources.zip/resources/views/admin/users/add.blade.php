@extends('admin.layout.layout')
@section('content')
<div class="content-wrapper">
    <div class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?=$pageheading?></h1>
				</div>
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="<?=url(config('global.ADMIN_URL').'/dashboard')?>">Dashboard</a></li>
						<li class="breadcrumb-item active"><?=$pageheading?></li>
					</ol>
				</div>
			</div>
		</div>
    </div>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-secondary">
						<div class="card card-danger">
							@if ($error = Session::get('error'))
								<div class="card-header">
									<h3 class="card-title">{{$error}}</h3>
									<div class="card-tools">
										<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
										</button>
									</div>
								</div>
							@endif
						</div>
						<form method="post" id="quickForm" enctype="multipart/form-data">
							@csrf
							<div class="card-body">
								<div class="row">		
									<div class="col-sm-6">
										<div class="form-group">
											<label>Username <span class="text-danger">*</span></label>
											<input type="text"   class="form-control" name="username">
										</div>
									</div>		
									<div class="col-sm-6">
										<div class="form-group">
											<label>Password <span class="text-danger">*</span></label>
											<input type="text"   class="form-control" name="password">
										</div>
									</div>	
									<div class="col-sm-6">
										<div class="form-group">
											<label>Status</label>
											<select name="status" class="form-control">
												<option value="1">Enable</option>
												<option value="0">Disable</option>
											</select>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<h6 class="alert alert-secondary">Roles & Permission</h6>
									</div>
									<div class="col-lg-4">
										<div class="form-group">
											<label>Banner Manager</label><br>
											<input type="checkbox" name="roles[view_banner]" value="view_banner"> View Banner <br>
											<input type="checkbox" name="roles[add_banner]" value="add_banner"  > Add Banner <br>
											<input type="checkbox" name="roles[edit_banner]" value="edit_banner" > Edit Banner <br>
											<input type="checkbox" name="roles[delete_banner]" value="delete_banner" > Delete Banner <br>
										</div>
									</div>		
									<div class="col-lg-4">
										<div class="form-group">
											<label>Page Manager</label><br>
											<input type="checkbox" name="roles[view_page]" value="view_page"> View Page <br>
											<input type="checkbox" name="roles[add_page]" value="add_page"  > Add Page <br>
											<input type="checkbox" name="roles[edit_page]" value="edit_page" > Edit Page <br>
											<input type="checkbox" name="roles[delete_page]" value="delete_page" > Delete Page <br>
										</div>
									</div>		
									<div class="col-lg-4">
										<div class="form-group">
											<label>Testimonial Manager</label><br>
											<input type="checkbox" name="roles[view_testimonial]" value="view_testimonial"> View Testimonial <br>
											<input type="checkbox" name="roles[add_testimonial]" value="add_testimonial"  > Add Testimonial <br>
											<input type="checkbox" name="roles[edit_testimonial]" value="edit_testimonial" > Edit Testimonial <br>
											<input type="checkbox" name="roles[delete_testimonial]" value="delete_testimonial" >Delete Testimonial <br>
										</div>
									</div>		
									<!--div class="col-lg-4">
										<div class="form-group">
											<label>Team Manager</label><br>
											<input type="checkbox" name="roles[view_team]" value="view_team"> View Team <br>
											<input type="checkbox" name="roles[add_team]" value="add_team"  > Add Team <br>
											<input type="checkbox" name="roles[edit_team]" value="edit_team" > Edit Team <br>
											<input type="checkbox" name="roles[delete_team]" value="delete_team" > Delete Team<br>
										</div>
									</div-->	
									<div class="col-lg-4">
										<div class="form-group">
											<label>Client Manager</label><br>
											<input type="checkbox" name="roles[view_client]" value="view_client"> View Client <br>
											<input type="checkbox" name="roles[add_client]" value="add_client"> Add Client <br>
											<input type="checkbox" name="roles[edit_client]" value="edit_client" > Edit Client <br>
											<input type="checkbox" name="roles[delete_client]" value="delete_client" > Delete Client<br>
										</div>
									</div>	
									
									<div class="col-lg-4">
										<div class="form-group">
											<label>Location Manager</label><br>
											<input type="checkbox" name="roles[view_location]" value="view_location"> View Location <br>
											<input type="checkbox" name="roles[add_location]" value="add_location"> Add Location <br>
											<input type="checkbox" name="roles[edit_location]" value="edit_location" > Edit Location <br>
											<input type="checkbox" name="roles[delete_location]" value="delete_location" > Delete Location<br>
										</div>
									</div>	
									<!--div class="col-lg-4">
										<div class="form-group">
											<label>Portfolio Manager</label><br>
											<input type="checkbox" name="roles[view_portfolio]" value="view_portfolio"> View Portfolio <br>
											<input type="checkbox" name="roles[add_portfolio]" value="add_portfolio"  > Add Portfolio <br>
											<input type="checkbox" name="roles[edit_portfolio]" value="edit_portfolio" > Edit Portfolio <br>
											<input type="checkbox" name="roles[delete_portfolio]" value="delete_portfolio" > Delete Portfolio <br>
										</div>
									</div-->
								
									<div class="col-lg-4">
										<div class="form-group">
											<label>Category Manager</label><br>
											<input type="checkbox" name="roles[view_category]" value="view_category"> View Category <br>
											<input type="checkbox" name="roles[add_category]" value="add_category"  > Add Category <br>
											<input type="checkbox" name="roles[edit_category]" value="edit_category" > Edit Category <br>
											<input type="checkbox" name="roles[delete_category]" value="delete_category" > Delete Category <br>
										</div>
									</div>		
									<div class="col-lg-4">
										<div class="form-group">
											<label>Product Manager</label><br>
											<input type="checkbox" name="roles[view_product]" value="view_product"> View Product <br>
											<input type="checkbox" name="roles[add_product]" value="add_product"  > Add Product <br>
											<input type="checkbox" name="roles[edit_product]" value="edit_product" > Edit Product <br>
											<input type="checkbox" name="roles[delete_product]" value="delete_product" > Delete Product <br>
										</div>
									</div>	
									
									<!--div class="col-lg-4">
										<div class="form-group">
											<label>Landing Page Manager</label><br>
											<input type="checkbox" name="roles[view_landing_page]" value="view_landing_page"> View Landing Page <br>
											<input type="checkbox" name="roles[add_landing_page]" value="add_landing_page"  > Add Landing Page <br>
											<input type="checkbox" name="roles[edit_landing_page]" value="edit_landing_page" > Edit Landing Page <br>
											<input type="checkbox" name="roles[delete_landing_page]" value="delete_landing_page" > Delete Landing Page <br>
										</div>
									</div-->	
									
									
									
									<div class="col-lg-4">
										<div class="form-group">
											<label>Blog Category Manager</label><br>
											<input type="checkbox" name="roles[view_blog_category]" value="view_blog_category"> View Blog Category <br>
											<input type="checkbox" name="roles[add_blog_category]" value="add_blog_category"  > Add Blog Category <br>
											<input type="checkbox" name="roles[edit_blog_category]" value="edit_blog_category" > Edit Blog Category <br>
											<input type="checkbox" name="roles[delete_blog_category]" value="delete_blog_category" > Delete Blog Category <br>
										</div>
									</div>
									<div class="col-lg-4">
										<div class="form-group">
											<label>Blog Manager</label><br>
											<input type="checkbox" name="roles[view_blog]" value="view_blog"> View Blog <br>
											<input type="checkbox" name="roles[add_blog]" value="add_blog"> Add Blog <br>
											<input type="checkbox" name="roles[edit_blog]" value="edit_blog" > Edit Blog <br>
											<input type="checkbox" name="roles[delete_blog]" value="delete_blog" > Delete Blog<br>
										</div>
									</div>
									<!--div class="col-lg-4">
										<div class="form-group">
											<label>Blog Comment Manager</label><br>
											<input type="checkbox" name="roles[view_blog_comment]" value="view_blog_comment"> View Blog Comment <br>
											<input type="checkbox" name="roles[active_blog_comment]" value="active_blog_comment"> Active Blog Comment<br>
											<input type="checkbox" name="roles[deactive_blog_comment]" value="deactive_blog_comment" > Deactive Blog Comment <br>
											<input type="checkbox" name="roles[delete_blog_comment]" value="delete_blog_comment" > Delete Blog Comment<br>
										</div>
									</div-->
									
									<div class="col-lg-4">
										<div class="form-group">
											<label>Users Manager</label><br>
											<input type="checkbox" name="roles[view_users]" value="view_users"> View Users <br>
											<input type="checkbox" name="roles[add_users]" value="add_users"> Add Users <br>
											<input type="checkbox" name="roles[edit_users]" value="edit_users" > Edit Users <br>
											<input type="checkbox" name="roles[delete_users]" value="delete_users" > Delete Users<br>
										</div>
									</div>
									<div class="col-lg-4">
										<div class="form-group">
											<label>Analytical Manager</label><br>
											<input type="checkbox" name="roles[view_analytical]" value="view_analytical"> View Analytical <br>
											<input type="checkbox" name="roles[add_analytical]" value="add_analytical"> Add Analytical <br>
											<input type="checkbox" name="roles[edit_analytical]" value="edit_analytical" > Edit Analytical <br>
											<input type="checkbox" name="roles[delete_analytical]" value="delete_analytical" > Delete Analytical<br>
										</div>
									</div>
									<div class="col-lg-4">
										<div class="form-group">
											<label>FAQ's Manager</label><br>
											<input type="checkbox" name="roles[view_faq]" value="view_faq"> View Faq <br>
											<input type="checkbox" name="roles[add_faq]" value="add_faq"> Add Faq <br>
											<input type="checkbox" name="roles[edit_faq]" value="edit_faq" > Edit Faq <br>
											<input type="checkbox" name="roles[delete_faq]" value="delete_faq" > Delete Faq<br>
										</div>
									</div>
									<div class="col-lg-4">
										<div class="form-group">
											<label>Redirect Url Manager</label><br>
											<input type="checkbox" name="roles[view_redirect]" value="view_faq"> View Redirect <br>
											<input type="checkbox" name="roles[add_redirect]" value="add_faq"> Add Redirect <br>
											<input type="checkbox" name="roles[edit_redirect]" value="edit_faq" > Edit Redirect <br>
											<input type="checkbox" name="roles[delete_redirect]" value="delete_faq" > Delete Redirect<br>
										</div>
									</div>
									<div class="col-lg-4">
										<div class="form-group">
											<label>Enquiry Manager</label><br>
											<input type="checkbox" name="roles[view_enquiry]" value="view_enquiry"> View Enquiry <br>
											<!--input type="checkbox" name="roles[add_enquiry]" value="add_enquiry"> Add Enquiry <br>
											<input type="checkbox" name="roles[edit_enquiry]" value="edit_enquiry" > Edit Enquiry <br-->
											<input type="checkbox" name="roles[delete_enquiry]" value="delete_enquiry" > Delete Enquiry<br>
											<input type="checkbox" name="roles[download_enquiry_xlsx]" value="download_enquiry_xlsx" > Download Enquiry (xlsx)<br>
										</div>
									</div>
									<div class="col-lg-4">
										<div class="form-group">
										
											<input type="checkbox" name="roles[websetting]" value="websetting"> Web Setting <br>
											<input type="checkbox" name="roles[cache]" value="cache"> Cache<br>
											
										</div>
									</div>
								</div>
							</div>
							<div class="card-footer">
								<input type="submit" class="btn btn-primary" value="Submit" name="submit">
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
    </section>
</div>
<script type="text/javascript">
$(document).ready(function () {
	$.validator.setDefaults({
	});
	$('#quickForm').validate({
		rules: {
			username:{ required:true, },  	  
			password:{ required:true, },  	  
		},
		errorElement: 'span',
		errorPlacement: function (error, element) {
			error.addClass('invalid-feedback');
			element.closest('.form-group').append(error);
		},
		highlight: function (element, errorClass, validClass) {
			$(element).addClass('is-invalid');
		},
		unhighlight: function (element, errorClass, validClass) {
			$(element).removeClass('is-invalid');
		}
	});
});
</script>

@endsection