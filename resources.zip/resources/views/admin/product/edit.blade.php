@extends('admin.layout.layout')
@section('content')
<div class="content-wrapper">
    <div class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?=$pageheading?></h1>
				</div>
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="<?=url(config('global.ADMIN_URL').'/dashboard')?>">Dashboard</a></li>
						<li class="breadcrumb-item active"><?=$pageheading?></li>
					</ol>
				</div>
			</div>
		</div>
    </div>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-secondary">
						<div class="card card-danger">
							@if ($error = Session::get('error'))
								<div class="card-header">
									<h3 class="card-title">{{$error}}</h3>
									<div class="card-tools">
										<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
										</button>
									</div>
								</div>
							@endif
						</div>
						<form method="post" id="quickForm" enctype="multipart/form-data">
						@csrf
						<div class="card-body" >
							
							<ul class="nav nav-tabs" id="myTab" role="tablist">
								<li class="nav-item">
									<a class="nav-link active" id="general-tab" data-toggle="tab" href="#general" role="tab" aria-controls="general" aria-selected="true">General</a>
								</li> 
						
								<li class="nav-item">
									<a class="nav-link" id="image-video-tab" data-toggle="tab" href="#image-video" role="tab" aria-controls="image-video" aria-selected="true">Image</a>
								</li>
							
							</ul>
							<div class="tab-content" id="myTabContent">
								<div class="tab-pane fade show active" id="general" role="tabpanel" aria-labelledby="general-tab">
									<div class="sectiondiv">
										<div class="row">
											<div class="col-sm-6">
												<div class="form-group">
													<label>Name <span class="text-danger"> *</span></label>
													<input type="text"   class="form-control" name="name" value="<?php if(old('name')){ echo old('name');}else{  echo $pageInfo->name; }?>">
													@error('name')
														<div class="text-danger">{{ $message }}</div>
													@enderror
												</div>
											</div>	
                                            
                                            
                                            <div class="col-sm-6">
										<div class="form-group">
											<label>Category </label>
											<input type="text" name="category" value="" placeholder="Categories" id="input-category" class="form-control"/>
											<div id="category_ids" class="well well-sm" style="height: 150px; overflow: auto;background: #ececec;padding: 10px;"> 
												<?php foreach($getSelectedBlogCategories as $selecteCategories) { ?>
												
													<div id="category_ids<?=$selecteCategories->category_id?>"><i class="fa fa-minus-circle"></i> <?=$selecteCategories->title?><input type="hidden" name="category_ids[]" value="<?=$selecteCategories->category_id?>"></div>
												<?php } ?>
											</div>
										</div>
									</div>
                                            
                                            
                                            
											
											<div class="col-sm-6">
												<div class="form-group">
													<label>Linkname <span class="text-danger">*</span> <small class="text-info">(use hypen "-" instead of space or any special character)</small></label>
													<input type="text" class="form-control" name="slug" value="<?php if(old('slug')){ echo old('slug');}else{  echo $pageInfo->slug; }?>">
													@error('slug')
														<div class="text-danger">{{ $message }}</div>
													@enderror
												</div>
											</div>
											<div class="col-sm-8">
												<div class="form-group">
													<label>Meta Title <span class="text-danger">*</span></label>
													<input type="text" name="meta_title" class="form-control" value="<?php if(old('meta_title')){ echo old('meta_title');}else{  echo $pageInfo->meta_title; }?>"/>
													@error('meta_title')
														<div class="text-danger">{{ $message }}</div>
													@enderror
												</div>
											</div>
											<div class="col-sm-2">
												<div class="form-group">
													<label>Sort</label>
													<input type="number" name="sort" class="form-control" min="0" value="<?php if(old('sort')){ echo old('sort');}else{  echo $pageInfo->sort; }?>" />
												</div>
											</div>
											<div class="col-sm-2">
												<div class="form-group">
													<label>Status</label>
													<select class="form-control" name="status">
														<option value="1" <?php if(old('status') == '1'){ echo "selected";}else{ if($pageInfo->status == '1'){ echo "selected";}}?>>Enable</option>
														<option value="0"  <?php if(old('status') == '0'){ echo "selected";}else{ if($pageInfo->status == '0'){ echo "selected";}}?>>Disable</option>
													</select>
												</div>
											</div>
										
											<div class="col-sm-6">
												<div class="form-group">
													<label>Meta Keyword</label>
													<textarea name="meta_keyword" class="form-control"><?php if(old('meta_keyword')){ echo old('meta_keyword');}else{ echo $pageInfo->meta_keyword;}?></textarea>
													@error('meta_keyword')
														<div class="text-danger">{{ $message }}</div>
													@enderror
												</div>
											</div>
											<div class="col-sm-6">
												<div class="form-group">
													<label>Meta Description</label>
													<textarea name="meta_description" class="form-control"><?php if(old('meta_description')){ echo old('meta_description');}else{ echo $pageInfo->meta_description;}?></textarea>
													@error('meta_description')
														<div class="text-danger">{{ $message }}</div>
													@enderror
												</div>
											</div>
											<div class="col-sm-12">
												<div class="form-group">
													<label>Short Description</label>
													<textarea class="textarea" name="short_description" id="short_description"><?php if(old('short_description')){ echo old('short_description');}else{ echo $pageInfo->short_description;}?></textarea>
													@error('short_description')
														<div class="text-danger">{{ $message }}</div>
													@enderror
												</div>
											</div>					
											<div class="col-sm-12">
												<div class="form-group">
													<label>Description</label>
													<textarea class="textarea" name="description" id="description"><?php if(old('description')){ echo old('description');}else{ echo $pageInfo->description;}?></textarea>
													@error('description')
														<div class="text-danger">{{ $message }}</div>
													@enderror
												</div>
											</div>	
											<div class="col-sm-12">
												<div class="form-group">
													<label>Custom Data</label>
													<textarea class="textarea" name="custom_data" id="custom_data"><?php if(old('custom_data')){ echo old('custom_data');}else{ echo $pageInfo->custom_data;}?></textarea>
													@error('custom_data')
														<div class="text-danger">{{ $custom_data }}</div>
													@enderror
												</div>
											</div>
										</div>
									</div>
								</div>	
				
							
								<div class="tab-pane fade" id="image-video" role="tabpanel" aria-labelledby="image-video-tab">
									<div class="sectiondiv">
										<div class="row">
											<div class="col-sm-6">
												<div class="form-group">
													<label>Image (Primary)</label>
													<div class="input-group">
														<span class="input-group-btn">
															<a data-input="image" data-preview="image_holder" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a>
														</span>
														<input id="image" class="form-control" type="text" name="image" value="<?php if(old('image')){ echo old('image');}else{  echo $pageInfo->image; }?>">
													</div>
													<div id="image_holder" style="margin-top:15px;max-height:100px;">
														<?php if(old('image')) { ?>
															<img src="<?=resizeimg(old('image'),80,80,false)?>">
														<?php } else { ?>
															<img src="<?=resizeimg($pageInfo->image,80,80,false)?>">
														<?php } ?>
													</div>
												</div>
											</div>		
											<div class="col-sm-6">
												<div class="form-group">
													<label>Banner</label>
													<div class="input-group">
														<span class="input-group-btn">
															<a data-input="banner" data-preview="banner_holder" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a>
														</span>
														<input id="banner" class="form-control" type="text" name="banner"  value="<?php if(old('banner')){ echo old('banner');}else{  echo $pageInfo->banner; }?>">
													</div>
													<div id="banner_holder" style="margin-top:15px;max-height:100px;">
													<?php if(old('banner')) { ?>
															<img src="<?=resizeimg(old('banner'),80,80,false)?>">
														<?php } else { ?>
															<img src="<?=resizeimg($pageInfo->banner,80,80,false)?>">
														<?php } ?>

													</div>
												</div>
											</div>	
										
											<div class="col-sm-12">
												<h5 class="alert alert-secondary">Other Image <span class="btn btn-success btn-sm float-sm-right" id="otherimage">+ Other Images</span></h5>
											</div>
											<div id="otherimage_div" style="width:100%">
												<?php if(old('otherimage')){ $sn=1 ?>
													<?php foreach(old('otherimage') as $otherimage) { ?>
													<div class="row form-group" id="newotherimage_div<?=$sn?>" style="background: #ececec;padding: 12px;">
														<div class="col-sm-9">
															<div class="form-group">
																<label>Other Image</label>
																<div class="input-group"><span class="input-group-btn"><a data-input="otherimage<?=$sn?>" data-preview="otherimage_holder<?=$sn?>" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a></span><input id="otherimage<?=$sn?>" class="form-control" type="text" name="otherimage[<?=$sn?>][image]" value="<?=$otherimage['image']?>" required></div>
																<div id="otherimage_holder2" style="margin-top:15px;max-height:100px;">
																	<img src="<?=resizeimg($otherimage['image'],80,80,false)?>">
																</div>
														  </div>
														</div>
														<div class="col-lg-2">
															<div class="form-group">
																<label>Sort</label>
																<div class="input-group">  <input type="number" class="form-control" name="otherimage[<?=$sn?>][sort]" value="<?=$otherimage['sort']?>" required=""> </div>
															</div>
														</div>
														<div class="col-lg-1">
														  <div class="form-group">
															 <label>Remove</label>
															 <div class="form-group"><span class="btn btn-danger btn_remove" id="<?=$sn?>">X</span></div>
														  </div>
													   </div>
													</div>
													<?php $sn++;} ?>
												<?php }else{ $sn=1; ?>
												<?php foreach($otherImages as $otherimage){  ?>
													<div class="row form-group" id="newotherimage_div<?=$sn?>" style="background: #ececec;padding: 12px;">
														<div class="col-sm-9">
															<div class="form-group">
																<label>Other Image</label>
																<div class="input-group"><span class="input-group-btn"><a data-input="otherimage<?=$sn?>" data-preview="otherimage_holder<?=$sn?>" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a></span><input id="otherimage<?=$sn?>" class="form-control" type="text" name="otherimage[<?=$sn?>][image]" value="<?=$otherimage['image']?>" required></div>
																<div id="otherimage_holder2" style="margin-top:15px;max-height:100px;">
																	<img src="<?=resizeimg($otherimage['image'],80,80,false)?>">
																</div>
														  </div>
														</div>
														<div class="col-lg-2">
															<div class="form-group">
																<label>Sort</label>
																<div class="input-group">  <input type="number" class="form-control" name="otherimage[<?=$sn?>][sort]" value="<?=$otherimage['sort']?>" required=""> </div>
															</div>
														</div>
														<div class="col-lg-1">
														  <div class="form-group">
															 <label>Remove</label>
															 <div class="form-group"><span class="btn btn-danger btn_remove" id="<?=$sn?>">X</span></div>
														  </div>
													   </div>
													</div>
												<?php $sn++; } ?>
												<?php } ?>
											</div>
										</div>
									</div>
								</div>	
						
                        </div>
                     </div>
					<div class="card-footer">
						<input type="submit" class="btn btn-primary" value="Submit">
					</div>
                  </form>

					
					</div>
				</div>
			</div>
		</div>
    </section>
</div>


@include('admin.product.script')
@endsection