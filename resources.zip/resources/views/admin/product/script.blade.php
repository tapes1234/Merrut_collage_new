<script>



// Sliding
$('input[name=\'category\']').autocomplete({
	'source': function(request, response) {
		$.ajax({
			url: '<?php echo url(config('global.ADMIN_URL').'/category/autocomplete?filter_name=')?>'+encodeURIComponent(request),
			dataType: 'json',
			success: function(json) {
				response($.map(json, function(item) {
					return {
						label: item['name'],
						value: item['category_id']
					}
				}));
			}
		});
	},
	'select': function(item) {
		$('input[name=\'category\']').val('');
		$('#category_ids' + item['value']).remove();
		$('#category_ids').append('<div id="category_ids' + item['value'] + '"><i class="fa fa-minus-circle"></i> ' + item['label'] + '<input type="hidden" name="category_ids[]" value="' + item['value'] + '" /></div>');
	}
});

$('#category_ids').delegate('.fa-minus-circle', 'click', function() {
	$(this).parent().remove();
});



// Sliding
$('input[name=\'category\']').autocomplete({
	'source': function(request, response) {
		$.ajax({
			url: '<?php echo url(config('global.ADMIN_URL').'/category/autocomplete?filter_name=')?>'+encodeURIComponent(request),
			dataType: 'json',
			success: function(json) {
				response($.map(json, function(item) {
					return {
						label: item['name'],
						value: item['category_id']
					}
				}));
			}
		});
	},
	'select': function(item) {
		$('input[name=\'category\']').val('');
		$('#category_ids' + item['value']).remove();
		$('#category_ids').append('<div id="category_ids' + item['value'] + '"><i class="fa fa-minus-circle"></i> ' + item['label'] + '<input type="hidden" name="category_ids[]" value="' + item['value'] + '" /></div>');
	}
});

$('#category_ids').delegate('.fa-minus-circle', 'click', function() {
	$(this).parent().remove();
});













//other image2
	
var i = <?php echo $sn?>;
$('#otherimage').click(function(){
	i++;
	$('#otherimage_div').append('<div class="row form-group" id="newotherimage_div'+i+'" style="background: #ececec;padding: 12px;"><div class="col-sm-9"><div class="form-group"><label>Other Image</label><div class="input-group"><span class="input-group-btn"><a data-input="otherimage'+i+'" data-preview="otherimage_holder'+i+'" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a></span><input id="otherimage'+i+'" class="form-control" type="text" name="otherimage['+i+'][image]" required></div><div id="otherimage_holder'+i+'" style="margin-top:15px;max-height:100px;"></div></div></div><div class="col-lg-2"><div class="form-group"><label>Sort</label><div class="input-group">  <input type="number" class="form-control" name="otherimage['+i+'][sort]" required> </div></div></div><div class="col-lg-1"><div class="form-group"> <label>Remove</label><div class="form-group"><span class="btn btn-danger btn_remove" id="'+i+'">X</span></div> </div></div></div>');
	$('#otherimage_div').find('.uploadfile').filemanager('image', {prefix: '/laravel-filemanager'});	
});
$(document).on('click', '.btn_remove', function(){  
	var button_id = $(this).attr("id");   
   $('#newotherimage_div'+button_id+'').remove();  
});


</script>