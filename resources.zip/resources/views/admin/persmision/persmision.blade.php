



<!DOCTYPE html>
<html>

<head>

  <meta charset="utf-8">

  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <title>Permission Denied</title>

  <meta name="viewport" content="width=device-width, initial-scale=1">

  

  <link rel="stylesheet" href="{{url('assets/admin_assets/plugins/fontawesome-free/css/all.min.css')}}">



<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">



  <link rel="stylesheet" href="{{url('assets/admin_assets/plugins/icheck-bootstrap/icheck-bootstrap.min.css')}}">

  <link rel="stylesheet" href="{{url('assets/admin_assets/dist/css/adminlte.min.css')}}">







 

</head>

<body class="hold-transition login-page">

<div class="login-box">

  <div class="card">

    <div class="card-body login-card-body">

	
		<h2>You Do Not have Permission</h2>
		<a class="btn btn-primary" href="<?=url(config('global.ADMIN_URL').'/dashboard')?>">Back</a>


   

    </div>



  </div>

</div>







<script src="{{url('assets/admin_assets/plugins/jquery/jquery.min.js')}}"></script>

<script src="{{url('assets/admin_assets/plugins/bootstrap/js/bootstrap.bundle.min.js')}}"></script>

<script src="{{url('assets/admin_assets/dist/js/adminlte.min.js')}}"></script>



</body>

</html>

