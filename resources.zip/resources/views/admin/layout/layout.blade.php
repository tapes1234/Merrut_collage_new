@include('admin.layout.headcss')
@include('admin.layout.navbar')
@include('admin.layout.sidebar')


@yield('content')

@include('admin.layout.footer')