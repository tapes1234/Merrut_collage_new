<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">

    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
      </li>
   
    </ul>

    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a class="nav-link" href="<?=url('/');?>" target="_blank">
        <i class="fas fa-eye"> View Site</i>
		
        </a>
      </li>       
	  <li class="nav-item">
        <a class="nav-link" href="<?=config('global.ADMIN_URL').'/dashboard/logout'?>">
        <i class="fas fa-sign-out-alt"> Log-Out</i>
        </a>
      </li> 
    </ul>
  </nav>
  <!-- /.navbar -->