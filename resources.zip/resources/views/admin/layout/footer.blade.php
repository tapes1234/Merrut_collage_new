
  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->

<!-- jQuery UI 1.11.4 -->
<script src="{{url('assets/admin_assets/plugins/jquery-ui/jquery-ui.min.js')}}"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="{{url('assets/admin_assets/plugins/bootstrap/js/bootstrap.bundle.min.js')}}"></script>

<script src="{{url('assets/admin_assets/plugins/jquery-validation/jquery.validate.min.js')}}"></script>
<script src="{{url('assets/admin_assets/plugins/jquery-validation/additional-methods.min.js')}}"></script>
<!-- Ekko Lightbox -->
<script src="{{url('assets/admin_assets/plugins/ekko-lightbox/ekko-lightbox.min.js')}}"></script>
<!-- DataTables -->
<script src="{{url('assets/admin_assets/plugins/datatables/jquery.dataTables.js')}}"></script>

<script src="{{url('assets/admin_assets/plugins/datatables-bs4/js/dataTables.bootstrap4.js')}}"></script>
<script src="{{url('assets/admin_assets/plugins/select2/js/select2.full.min.js')}}"></script>
<!-- ChartJS -->
<script src="{{url('assets/admin_assets/plugins/chart.js/Chart.min.js')}}"></script>
<!-- Sparkline -->
<script src="{{url('assets/admin_assets/plugins/sparklines/sparkline.js')}}"></script>
<!-- JQVMap -->
<script src="{{url('assets/admin_assets/plugins/jqvmap/jquery.vmap.min.js')}}"></script>
<script src="{{url('assets/admin_assets/plugins/jqvmap/maps/jquery.vmap.usa.js')}}"></script>
<!-- jQuery Knob Chart -->
<script src="{{url('assets/admin_assets/plugins/jquery-knob/jquery.knob.min.js')}}"></script>
<!-- daterangepicker -->
<script src="{{url('assets/admin_assets/plugins/moment/moment.min.js')}}"></script>
<script src="{{url('assets/admin_assets/plugins/daterangepicker/daterangepicker.js')}}"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="{{url('assets/admin_assets/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js')}}"></script>
<!-- Summernote -->
<script src="{{url('assets/admin_assets/plugins/summernote/summernote-bs4.min.js')}}"></script>

<!-- CkEditor -->
<script src="{{url('assets/admin_assets/plugins/ckeditor/ckeditor.js')}}"></script>
<!-- overlayScrollbars -->
<script src="{{url('assets/admin_assets/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')}}"></script>
<!-- AdminLTE App -->
<script src="{{url('assets/admin_assets/dist/js/adminlte.js')}}"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="{{url('assets/admin_assets/dist/js/pages/dashboard.js')}}"></script>
<!-- AdminLTE for demo purposes -->
<script src="{{url('assets/admin_assets/dist/js/demo.js')}}"></script>
<!-- Filterizr-->
<script src="{{url('assets/admin_assets/plugins/filterizr/jquery.filterizr.min.js')}}"></script>
 <script src="{{url('assets/admin_assets/dropify/js/dropify.min.js')}}"></script>
 <script src="{{url('assets/admin_assets/dist/js/fancybox.js')}}"></script>
 <script src="/vendor/laravel-filemanager/js/stand-alone-button.js"></script>
  <script>
	var route_prefix = "/laravel-filemanager";
	$('.uploadfile').filemanager('image', {prefix: route_prefix});
  </script>

<script>
	jQuery(document).ready(function() {   
		$( ".textarea" ).each(function( index ) {
			CKEDITOR.replace($( this ).attr("id"),{ 
				filebrowserImageBrowseUrl: '/laravel-filemanager?type=Images',
				filebrowserImageUploadUrl: '/laravel-filemanager/upload?type=Images&_token=',
				filebrowserBrowseUrl: '/laravel-filemanager?type=Files',
				filebrowserUploadUrl: '/laravel-filemanager/upload?type=Files&_token='
			});    
		});
	});
</script>

	
<script>
  $(function () {
    $("#table").DataTable(); $('.select2').select2();
  });
</script>	


<script>
$(document).ready(function(){
	$('.dropify').dropify();
});
    //Timepicker
    $('#timepicker').datetimepicker({
      format: 'LT'
    }); 

	//Timepicker
    $('#timepicker2').datetimepicker({
      format: 'LT'
    });
</script>


</body>
</html>
