<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <div class="sidebar">
		<div class="user-panel mt-3 pb-3 mb-3 d-flex">
			<div class="image">
				<img src="{{url('assets/admin_assets/dist/img/user2-160x160.jpg')}}" class="img-circle elevation-2" alt="User Image">
			</div>
			<div class="info">
				<a href="javascript:void();" class="d-block">{{Auth::guard('admin')->user()->username}}</a>
			</div>
		</div>
		
		<!--div class="form-inline">
			<div class="input-group" data-widget="sidebar-search">
				<input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
				<div class="input-group-append">
					<button class="btn btn-sidebar">
						<i class="fas fa-search fa-fw"></i>
					</button>
				</div>
			</div>
		</div-->
		<nav class="mt-2">
		
			<ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
				<li class="nav-item">
					<a href="<?=url(config('global.ADMIN_URL').'/dashboard')?>" class="nav-link">
						<i class="nav-icon fas fa-home"></i>
						<p>Dashboard</p>
					</a>
				</li>	
				
				
				
				<?php if(isset(checkRoles()->view_banner) || isset(checkRoles()->view_page) || isset(checkRoles()->view_portfolio) || isset(checkRoles()->view_faq) || isset(checkRoles()->view_testimonial) || isset(checkRoles()->view_team) || isset(checkRoles()->view_client)) { ?>
				<li class="nav-item has-treeview ">
					<a href="#" class="nav-link">
						<i class="nav-icon fas fa-th"></i>
						<p>CMS Manager<i class="right fas fa-angle-left"></i> </p>
					</a>
					<ul class="nav nav-treeview">	
						<?php if(isset(checkRoles()->view_banner)) { ?>
							<li class="nav-item">
								<a href="<?=url(config('global.ADMIN_URL').'/banner')?>" class="nav-link">
									<i class="far fa-circle nav-icon"></i>
									<p>Banner Manager</p>
								</a>
							</li>	
						<?php } ?>
						<?php if(isset(checkRoles()->view_page)) { ?>
							<li class="nav-item">
								<a href="<?=url(config('global.ADMIN_URL').'/page')?>" class="nav-link">
									<i class="far fa-circle nav-icon"></i>
									<p>Page Manager</p>
								</a>
							</li>	
						<?php } ?>
						<?php if(isset(checkRoles()->view_portfolio)) { ?>
							<li class="nav-item">
								<a href="<?=url(config('global.ADMIN_URL').'/portfolio')?>" class="nav-link">
									<i class="far fa-circle nav-icon"></i>
									<p>Portfolio Manager</p>
								</a>
							</li>	
						<?php } ?>
						<?php if(isset(checkRoles()->view_team)) { ?>
							<li class="nav-item">
								<a href="<?=url(config('global.ADMIN_URL').'/team')?>" class="nav-link">
									<i class="far fa-circle nav-icon"></i>
									<p>Team Manager</p>
								</a>
							</li>	
						<?php } ?>		
						
						<?php if(isset(checkRoles()->view_location)) { ?>
							<li class="nav-item">
								<a href="<?=url(config('global.ADMIN_URL').'/location')?>" class="nav-link">
									<i class="far fa-circle nav-icon"></i>
									<p>Location Manager</p>
								</a>
							</li>	
						<?php } ?>	
						
						
						<?php if(isset(checkRoles()->view_client)) { ?>
							<li class="nav-item">
								<a href="<?=url(config('global.ADMIN_URL').'/client')?>" class="nav-link">
									<i class="far fa-circle nav-icon"></i>
									<p>Legacy Manager</p>
								</a>
							</li>	
						<?php } ?>	
						
						<?php if(isset(checkRoles()->view_testimonial)) { ?>
							<li class="nav-item d-none">
								<a href="<?=url(config('global.ADMIN_URL').'/testimonial')?>" class="nav-link">
									<i class="far fa-circle nav-icon"></i>
									<p>Testimonial Manager</p>
								</a>
							</li>	
						<?php } ?>
				
						
						<?php if(isset(checkRoles()->view_faq)) { ?>
						<li class="nav-item">
							<a href="<?=url(config('global.ADMIN_URL').'/faq')?>" class="nav-link ">
								<i class="far fa-circle nav-icon"></i>
								<p>FAQ's Manager</p>
							</a>
						</li>
						<?php } ?>
					</ul>
				</li>	
				<?php } ?>
				
				<?php if(isset(checkRoles()->view_category) || isset(checkRoles()->view_product)) { ?>
				<li class="nav-item has-treeview ">
					<a href="#" class="nav-link">
						<i class="nav-icon fas fa-table"></i>
						<p>Catalog Manager<i class="right fas fa-angle-left"></i> </p>
					</a>
					<ul class="nav nav-treeview">	
					
						<?php if(isset(checkRoles()->view_category)) { ?>
							<li class="nav-item">
								<a href="<?=url(config('global.ADMIN_URL').'/category')?>" class="nav-link">
									<i class="far fa-circle nav-icon"></i>
									<p>Category Manager</p>
								</a>
							</li>	
						<?php } ?>	
						<?php if(isset(checkRoles()->view_product)) { ?>
							<li class="nav-item">
								<a href="<?=url(config('global.ADMIN_URL').'/product')?>" class="nav-link">
									<i class="far fa-circle nav-icon"></i>
									<p>Academics Manager</p>
								</a>
							</li>	
						<?php } ?>
						
					</ul>
				</li>	
				<?php } ?>

				
				<?php if(isset(checkRoles()->view_blog_category) || isset(checkRoles()->view_blog) || isset(checkRoles()->view_blog_comment)) { ?>
				<li class="nav-item has-treeview ">
					<a href="#" class="nav-link">
						<i class="nav-icon fas fa-blog"></i>
						<p>Blog Manager<i class="right fas fa-angle-left"></i> </p>
					</a>
					<ul class="nav nav-treeview">	
						<?php if(isset(checkRoles()->view_blog_category)) { ?>
						<li class="nav-item">
							<a href="<?=url(config('global.ADMIN_URL').'/blog-category')?>" class="nav-link ">
								<i class="far fa-circle nav-icon"></i>
								<p>Category</p>
							</a>
						</li>
						<?php } ?>
						<?php if(isset(checkRoles()->view_blog)) { ?>
						<li class="nav-item">
							<a href="<?=url(config('global.ADMIN_URL').'/blog')?>" class="nav-link ">
								<i class="far fa-circle nav-icon"></i>
								<p>Blog</p>
							</a>
						</li>
						<?php } ?>
						<?php if(isset(checkRoles()->view_blog_comment)) { ?>
						<li class="nav-item">
							<a href="<?=url(config('global.ADMIN_URL').'/comment')?>" class="nav-link ">
								<i class="far fa-circle nav-icon"></i>
								<p>Comments</p>
							</a>
						</li>
						<?php } ?>
					</ul>
				</li>	
				<?php } ?>
				
				<?php if(isset(checkRoles()->view_landing_page) || isset(checkRoles()->view_enquiry)) { ?>
				<li class="nav-item has-treeview ">
					<a href="#" class="nav-link">
						<i class="nav-icon fas fa-question"></i>
						<p>Enquiry Manager<i class="right fas fa-angle-left"></i> </p>
					</a>
					<ul class="nav nav-treeview">	
					
						<?php if(isset(checkRoles()->view_landing_page)) { ?>
							<li class="nav-item">
								<a href="<?=url(config('global.ADMIN_URL').'/lp')?>" class="nav-link">
									<i class="far fa-circle nav-icon"></i>
									<p>Landing Page Manager</p>
								</a>
							</li>	
						<?php } ?>
						
						<?php if(isset(checkRoles()->view_enquiry)) { ?>
							<li class="nav-item">
								<a href="<?=url(config('global.ADMIN_URL').'/enquiry')?>" class="nav-link">
									<i class="far fa-circle nav-icon"></i>
									<p>Enquiry Manager</p>
								</a>
							</li>	
						<?php } ?>
				
					</ul>
				</li>	
				<?php } ?>

				<?php if(isset(checkRoles()->websetting) || isset(checkRoles()->view_users) || isset(checkRoles()->view_analytical) || isset(checkRoles()->view_faq) || isset(checkRoles()->cache)) { ?>
				<li class="nav-item has-treeview ">
					<a href="#" class="nav-link">
						<i class="nav-icon fas fa-cogs"></i>
						<p>System<i class="right fas fa-angle-left"></i> </p>
					</a>
					<ul class="nav nav-treeview">	
						<?php if(isset(checkRoles()->websetting)) { ?>
						<li class="nav-item">
							<a href="<?=url(config('global.ADMIN_URL').'/setting')?>" class="nav-link ">
								<i class="far fa-circle nav-icon"></i>
								<p>Web Setting</p>
							</a>
						</li>	
						<?php } ?>
						<?php if(isset(checkRoles()->view_users)) { ?>
						<li class="nav-item">
							<a href="<?=url(config('global.ADMIN_URL').'/users')?>" class="nav-link ">
								<i class="far fa-circle nav-icon"></i>
								<p>User Manager</p>
							</a>
						</li>
						<?php } ?>
						<?php if(isset(checkRoles()->view_analytical)) { ?>
						<li class="nav-item">
							<a href="<?=url(config('global.ADMIN_URL').'/analytics')?>" class="nav-link ">
								<i class="far fa-circle nav-icon"></i>
								<p>Analytics Manager</p>
							</a>
						</li>
						<?php } ?>
					
						<?php if(isset(checkRoles()->cache)) { ?>
						<li class="nav-item">
							<a href="<?=url(config('global.ADMIN_URL').'/cache')?>" class="nav-link ">
								<i class="far fa-circle nav-icon"></i>
								<p>Remove Cache</p>
							</a>
						</li>
						<?php } ?>
						<?php if(isset(checkRoles()->view_redirect)) { ?>
						<li class="nav-item">
							<a href="<?=url(config('global.ADMIN_URL').'/redirect')?>" class="nav-link ">
								<i class="far fa-circle nav-icon"></i>
								<p>Redirect Url</p>
							</a>
						</li>
						<?php } ?>
					</ul>
				</li>	
				<?php } ?>
								
				
			</ul>
		</nav>
    </div>
</aside>