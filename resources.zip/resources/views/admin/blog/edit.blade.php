@extends('admin.layout.layout')
@section('content')
<style>
.select2-container .select2-selection--single{
	height:39px;
}
</style>
<div class="content-wrapper">
    <div class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?=$pageheading?></h1>
				</div>
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="<?=url(config('global.ADMIN_URL').'/dashboard')?>">Dashboard</a></li>
						<li class="breadcrumb-item active"><?=$pageheading?></li>
					</ol>
				</div>
			</div>
		</div>
    </div>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-secondary">
						<div class="card card-danger">
							@if ($error = Session::get('error'))
								<div class="card-header">
									<h3 class="card-title">{{$error}}</h3>
									<div class="card-tools">
										<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
										</button>
									</div>
								</div>
							@endif
						</div>
						<form method="post" id="quickForm" enctype="multipart/form-data">
							@csrf
							<div class="card-body">
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<label>Category </label>
											<input type="text" name="category" value="" placeholder="Categories" id="input-category" class="form-control"/>
											<div id="category_ids" class="well well-sm" style="height: 150px; overflow: auto;background: #ececec;padding: 10px;"> 
												<?php foreach($getSelectedBlogCategories as $selecteCategories) { ?>
												
													<div id="category_ids<?=$selecteCategories->category_id?>"><i class="fa fa-minus-circle"></i> <?=$selecteCategories->title?><input type="hidden" name="category_ids[]" value="<?=$selecteCategories->category_id?>"></div>
												<?php } ?>
											</div>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<label>Parent Category <span class="text-danger">*</span></label>
											<select class="form-control select2" name="parent_category_id" id="parent_category_id" required>
												<option value="" hidden> --Select-- </option>
												<?php foreach($getAllBlogCategory as $blogCategory) { ?>
													<option value="<?=$blogCategory->id?>" <?php if($pageInfo->parent_category_id == $blogCategory->id){ echo "selected";}?>><?=$blogCategory->title?></option>
												<?php } ?>
											</select>
											
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<label>Title <span class="text-danger">*</span></label>
											<input type="text"   class="form-control" name="title" value="<?=$pageInfo->title?>">
										</div>
									</div>						
									<div class="col-sm-6">
										<div class="form-group">
											<label>Heading <span class="text-danger">*</span></label>
											<input type="text" class="form-control" name="heading" value="<?=$pageInfo->heading?>">
										</div>
									</div>	
									<div class="col-sm-9">
										<div class="form-group">
											<label>Punchline </label>
											<input type="text" class="form-control" name="punchline" value="<?=$pageInfo->punchline?>">
										</div>
									</div>	
									<div class="col-sm-3">
										<div class="form-group">
											<label>Badge </label>
											<input type="text" class="form-control" name="badge" value="<?=$pageInfo->badge?>">
										</div>
									</div>	
									<div class="col-sm-6">
										<div class="form-group">
											<label>Meta Title <span class="text-danger">*</span></label>
											<textarea name="meta_title" class="form-control"><?=$pageInfo->meta_title?></textarea>
										</div>
									</div>	
									<div class="col-sm-6">
										<div class="form-group">
											<label>Meta Keyword</label>
											<textarea name="meta_keyword" class="form-control"><?=$pageInfo->meta_keyword?></textarea>
										</div>
									</div>	
									<div class="col-sm-12">
										<div class="form-group">
											<label>Meta Description</label>
											<textarea name="meta_description" class="form-control"><?=$pageInfo->meta_description?></textarea>
										</div>
									</div>	
									
									<div class="col-sm-3">
										<div class="form-group">
											<label>Status</label>
											<select class="form-control" name="status">
												<option value="1" <?php if($pageInfo->status == '1'){ echo "selected";}?>>Enable</option>
												<option value="0" <?php if($pageInfo->status == '0'){ echo "selected";}?>>Disable</option>
											</select>
										</div>
									</div>	
									<div class="col-sm-3">
										<div class="form-group">
											<label>Publish Date</label>
											<input type="date" class="form-control" name="publish_date" value="<?=$pageInfo->publish_date?>">
										</div>
									</div>	
									<div class="col-sm-3">
										<div class="form-group">
											<label>Author Name</label>
											<input type="text" class="form-control" name="author_name"value="<?=$pageInfo->author_name?>">
										</div>
									</div>	
									<div class="col-sm-12">
										<div class="form-group">
											<label>Slug <span class="text-danger">*</span></label>
											<input type="text" name="slug" class="form-control" value="<?=$pageInfo->slug?>">
										</div>
									</div>						
									<div class="col-sm-6">
										<div class="form-group">
											<label>Icon</label>
											<div class="input-group">
												<span class="input-group-btn">
													<a data-input="icon" data-preview="icon_holder" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a>
												</span>
												<input id="icon" class="form-control" type="text" name="icon" value="<?=$pageInfo->icon?>">
											</div>
											<div id="icon_holder" style="margin-top:15px;max-height:100px;">
												<img src="<?=resizeimg($pageInfo->icon,80,80,false)?>">
											</div>
										</div>
									</div>									<div class="col-sm-6">										<div class="form-group">											<label>Icon Caption</label>											<input type="text" name="icon_caption" class="form-control" value="<?=$pageInfo->icon_caption?>" >										</div>									</div>	
									<div class="col-sm-6">
										<div class="form-group">
											<label>Thumb</label>
											<div class="input-group">
												<span class="input-group-btn">
													<a data-input="thumb" data-preview="thumb_holder" class="btn btn-warning uploadfile"><i class="fa fa-picture-o"></i> Choose </a>
												</span>
												<input id="thumb" class="form-control" type="text" name="thumb" value="<?=$pageInfo->thumb?>">
											</div>
											<div id="thumb_holder" style="margin-top:15px;max-height:100px;">
												<img src="<?=resizeimg($pageInfo->thumb,80,80,false)?>">
											</div>
										</div>
									</div>									<div class="col-sm-6">										<div class="form-group">											<label>Thumb Caption</label>											<input type="text" name="thumb_caption" class="form-control" value="<?=$pageInfo->thumb_caption?>" >										</div>									</div>	
									<div class="col-sm-12">
										<div class="form-group">
											<label>Short Description</label>
											<textarea class="textarea" id="short_description" name="short_description"><?=$pageInfo->short_description?></textarea>
										</div>
									</div>
									<div class="col-sm-12">
										<div class="form-group">
											<label>Description</label>
											<textarea class="textarea" id="description" name="description"><?=$pageInfo->description?></textarea>
										</div>
									</div>
								</div>
							</div>
							<div class="card-footer">
								<input type="submit" class="btn btn-primary" value="Submit" name="submit">
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
    </section>
</div>



@include('admin.blog.script')
@endsection

