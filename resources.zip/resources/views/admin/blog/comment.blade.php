@extends('admin.layout.layout')
@section('content')
<div class="content-wrapper">
    <div class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-left">
						<li class="breadcrumb-item"><a href="<?=url(config('global.ADMIN_URL').'/dashboard')?>">Dashboard</a></li>
						<li class="breadcrumb-item active"><?=$pageheading?></li>
					</ol>
				</div>
				<div class="col-sm-6">
					<div class="float-sm-right">
						
						<a href='javascript:void()' onclick=" $('#bannerform').attr('action', '<?php echo $activate ; ?>'); $('#bannerform').submit();  " class="btn btn-success btn-sm"> Active</a>
						
						<a href='javascript:void()' onclick=" $('#bannerform').attr('action', '<?php echo $deactivate ; ?>'); $('#bannerform').submit();  " class="btn btn-warning btn-sm"> Deactivate</a>
						
						<a href='javascript:void()' onclick=" $('#bannerform').attr('action', '<?php echo $deleteaction ; ?>'); $('#bannerform').submit();  " class="btn btn-danger btn-sm"> Delete</a>
					</div>
				</div>
			</div>
		</div>
    </div>
	<section class="content">
		<div class="row">
			<div class="col-12">
				@if ($success = Session::get('success'))
				<div class="card card-success">
					<div class="card-header">
						<h3 class="card-title">{{$success}}</h3>
					</div>
				</div>
				@endif	
				 
				@if ($error = Session::get('error'))
				<div class="card card-danger">
					<div class="card-header">
						<h3 class="card-title">{{$error}}</h3>
					</div>
				</div>
				@endif

				<div class="card-body">
					<?php if($allresults) { ?>
					<form id="bannerform" name="bannerform" method="post">
					@csrf
				
						<table id="tables" class="table table-bordered table-striped">
							<thead>
								<tr>
								  <th>#</th>
								  <th>Name</th>
								  <th>Email</th>
								  <th>Comment</th>
								  <th>status</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach($allresults as $result){ ?>
									<tr>
										<td>
											<input type="checkbox" name="delete_ids[]" value="<?=$result->id?>">
										</td>
										
										<td><?=$result->name?></td>
										<td><?=$result->email?></td>
										<td>
											<i  class="text-dark"><span class="text-info">Blog:</span> <?=$result->blog_title?><i><br>
											<i  class="text-dark"><span class="text-info">Comment:</span> <?=$result->comment?><i>
										</td>
										<td>
											<?php echo $result->status ? '<span class="badge badge-success">Enable<span>': '<span class="badge badge-danger">Disable<span>'?>
										</td>
									</tr>
									
								<?php  }?>
							</tbody>
  
						</table>
					</form>

					<?=$allresults->withQueryString()->links('pagination::bootstrap-5')?>
					<?php } else { ?>
						<h3 class="text-center">Data Not Found</h3>
					<?php } ?>
				</div>
			</div>
        </div>
    </section>
</div>


@endsection