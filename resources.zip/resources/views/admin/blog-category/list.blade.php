@extends('admin.layout.layout')
@section('content')
<div class="content-wrapper">
    <div class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-left">
						<li class="breadcrumb-item"><a href="<?=url(config('global.ADMIN_URL').'/dashboard')?>">Dashboard</a></li>
						<li class="breadcrumb-item active"><?=$pageheading?></li>
					</ol>
				</div>
				<div class="col-sm-6">
					<div class="float-sm-right">
						<a href="<?=$action?>" class="btn btn-success btn-sm">Add Blog Category</a>
						<a href='javascript:void()' onclick=" $('#bannerform').attr('action', '<?php echo $deleteaction ; ?>'); $('#bannerform').submit();  " class="btn btn-danger btn-sm"> Delete</a>
					</div>
				</div>
			</div>
		</div>
    </div>
	<section class="content">
		<div class="row">
			<div class="col-12">
				@if ($success = Session::get('success'))
				<div class="card card-success">
					<div class="card-header">
						<h3 class="card-title">{{$success}}</h3>
					</div>
				</div>
				@endif	
				 
				@if ($error = Session::get('error'))
				<div class="card card-danger">
					<div class="card-header">
						<h3 class="card-title">{{$error}}</h3>
					</div>
				</div>
				@endif

				<div class="card-body">
					<form id="bannerform" name="bannerform" method="post">
					@csrf
						<table id="table" class="table table-bordered table-striped">
							<thead>
								<tr>
								  <th>#</th>
								  <th>Title</th>
								  <th>Parent</th>
								  <th>Status</th>
								  <th>Top</th>
								  <th>Bottom</th>
								  <th>Sort</th>
								  <th>Action</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach($allresults as $result){ ?>
									<tr>
										<td>
											<input type="checkbox" name="delete_ids[]" value="<?=$result->id?>">
										</td>
										<td><?=$result->self_name?>											<br><span>Url: </span><a target="_blank" href="<?=createBlogCategoryUrl($result->slug)?>"><?=createBlogCategoryUrl($result->slug)?></a>										</td>
										<td><?=$result->parent_name ?? 'Self' ?></td>
										<td><?php echo $result->status ? '<span class="badge badge-success">Enable</span>' : '<span class="badge badge-danger">Disable</span>'?></td>
										<td><?php echo $result->top ? '<span class="badge badge-success">Enable</span>' : '<span class="badge badge-danger">Disable</span>'?></td>
										<td><?php echo $result->bottom ? '<span class="badge badge-success">Enable</span>' : '<span class="badge badge-danger">Disable</span>'?></td>
										<td><?=$result->sort?></td>
										<td><a href="<?=url(config('global.ADMIN_URL').'/blog-category/edit/'.$result->id)?>" class="btn btn-info btn-sm"><i class="fas fa-pencil-alt"></i></a></td>
										
									</tr>
								<?php  }?>
							</tbody>
  
						</table>
						
					</form>
					
				</div>

				
			</div>
        </div>
    </section>
</div>

@endsection