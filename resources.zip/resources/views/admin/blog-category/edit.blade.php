@extends('admin.layout.layout')
@section('content')
<div class="content-wrapper">
    <div class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark"><?=$pageheading?></h1>
				</div>
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="<?=url(config('global.ADMIN_URL').'/dashboard')?>">Dashboard</a></li>
						<li class="breadcrumb-item active"><?=$pageheading?></li>
					</ol>
				</div>
			</div>
		</div>
    </div>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-secondary">
						<div class="card card-danger">
							@if ($error = Session::get('error'))
								<div class="card-header">
									<h3 class="card-title">{{$error}}</h3>
									<div class="card-tools">
										<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
										</button>
									</div>
								</div>
							@endif
						</div>
						<form method="post" id="quickForm" enctype="multipart/form-data">
							@csrf
							<div class="card-body">
								<div class="row">	
									<div class="col-sm-6">
										<div class="form-group">
											<label>Select parent <span class="text-danger">*</span></label>
											<select name="pid" class="form-control">
												<option value="0" <?php if($pageInfo->pid == '0'){ echo "selected";}?>> Self </option>
												<?php foreach($getAllCategory as $category) { ?>
													<?php if($category->id != $pageInfo->id) { ?>
														<option value="<?=$category->id?>" <?php if($pageInfo->pid == $category->id){ echo "selected";}?>><?=$category->title?></option>
													<?php } ?>
												<?php } ?>
											</select>
										</div>
									</div>	
									<div class="col-sm-6">
										<div class="form-group">
											<label>Title <span class="text-danger">*</span></label>
											<input type="text"   class="form-control" name="title" value="<?=$pageInfo['title']?>">
										</div>
									</div>						
									<div class="col-sm-6">
										<div class="form-group">
											<label>Heading  <span class="text-danger">*</span></label>
											<input type="text" class="form-control" name="heading" value="<?=$pageInfo['heading']?>">
										</div>
									</div>	
									<div class="col-sm-6">
										<div class="form-group">
											<label>Slug <span class="text-danger">*</span></label>
											<input type="text" name="slug" class="form-control"  value="<?=$pageInfo['slug']?>">
										</div>
									</div>	
									<div class="col-sm-3">
										<div class="form-group">
											<label>Top</label>
											<select class="form-control" name="top">
												<option value="1" <?php if($pageInfo['top'] == '1'){ echo "selected";}?>>Enable</option>
												<option value="0" <?php if($pageInfo['top'] == '0'){ echo "selected";}?>>Disable</option>
											</select>
										</div>
									</div>	
									<div class="col-sm-3">
										<div class="form-group">
											<label>Bottom</label>
											<select class="form-control" name="bottom">
												<option value="1" <?php if($pageInfo['bottom'] == '1'){ echo "selected";}?>>Enable</option>
												<option value="0" <?php if($pageInfo['bottom'] == '0'){ echo "selected";}?>>Disable</option>
											</select>
										</div>
									</div>	
									<div class="col-sm-3">
										<div class="form-group">
											<label>Status</label>
											<select class="form-control" name="status">
												<option value="1" <?php if($pageInfo['status'] == '1'){ echo "selected";}?>>Enable</option>
												<option value="0" <?php if($pageInfo['status'] == '0'){ echo "selected";}?>>Disable</option>
											</select>
										</div>
									</div>						
									<div class="col-sm-3">
										<div class="form-group">
											<label>Sort</label>
											<input type="number" class="form-control" name="sort" min="0" value="<?=$pageInfo['sort']?>">
										</div>
									</div>	
									<div class="col-sm-6">
										<div class="form-group">
											<label>Meta Title <span class="text-danger">*</span></label>
											<textarea class="form-control" name="meta_title"><?=$pageInfo['meta_title']?></textarea>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<label>Meta Keyword</label>
											<textarea class="form-control" name="meta_keyword"><?=$pageInfo['meta_keyword']?></textarea>
										</div>
									</div>
									<div class="col-sm-12">
										<div class="form-group">
											<label>Meta Description</label>
											<textarea class="form-control" name="meta_description"><?=$pageInfo['meta_description']?></textarea>
										</div>
									</div>
									
														
									
								</div>
							</div>
							<div class="card-footer">
								<input type="submit" class="btn btn-primary" value="Submit" name="submit">
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
    </section>
</div>
<script type="text/javascript">
$(document).ready(function () {
	$.validator.setDefaults({
	});
	$('#quickForm').validate({
		rules: {
			title:{ required:true, },  	  
			heading:{ required:true, },  	  
			meta_title:{ required:true, },  	  
			slug:{ required:true, },  	  
		},
		errorElement: 'span',
		errorPlacement: function (error, element) {
			error.addClass('invalid-feedback');
			element.closest('.form-group').append(error);
		},
		highlight: function (element, errorClass, validClass) {
			$(element).addClass('is-invalid');
		},
		unhighlight: function (element, errorClass, validClass) {
			$(element).removeClass('is-invalid');
		}
	});
});
</script>

@endsection