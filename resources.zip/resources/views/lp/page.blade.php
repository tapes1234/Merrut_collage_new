@extends('lp.layout.layout')
@section('content')

<section class="njjf-iiiirj" style="background-image: url(public/uploads/common/home6.jpg)">
	<div class="home-section-overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<?=$banner_text?>
				<a href="<?=$banner_button_link?>" class="nmmcd-jjjdhyr"><?=$banner_button_text?></a>
			</div>
			<div class="homenewpopup dffsrewrffsdewr-nnnns no-show-mobile" id="register">
				<div class="formmainhead"> <b>Drop a message </b></div>
				<div class="homenewpopinner form1">
					<form method="post">
						<div class="homefield">
							<input type="text" name="name" placeholder="Name" value="" class="form-control ">
						</div>
						<div class="homefield">
							<input type="email" name="email" placeholder="E-mail" value="" class="form-control ">
						</div>
						<div class="homefield">
							<input type="text" name="mobile" placeholder="Contact Number:" value="" pattern="\d{10}" class="form-control ">
						</div>
						<div class="homefield">
							<select class="form-control" name="service">
								<option hidden="">Select Service</option>
							</select>
						</div>
						<div class="homefield">
							<textarea class="hhhhhs" name="message" value="" class="form-control "></textarea>
						</div>
						<div class="homefield" >
							<input type="submit" value="Submit" style="background-color:#FF1493 ">
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="mobile-show">
	<div class="container">
		<div class="row">
			<div class="homenewpopup" id="register">
				<div class="formmainhead"> <b>Drop a message </b></div>
				<div class="homenewpopinner form1">
					<form method="post">
						<div class="homefield">
							<input type="text" name="name" placeholder="Name" value="" class="form-control ">
						</div>
						<div class="homefield">
							<input type="email" name="email" placeholder="E-mail" value="" class="form-control ">
						</div>
						<div class="homefield">
							<input type="text" name="mobile" placeholder="Contact Number:" value="" pattern="\d{10}" class="form-control ">
						</div>
						<div class="homefield">
							<select class="form-control" name="service">
								<option hidden="">Select Service</option>
							</select>
						</div>
						<div class="homefield">
							<textarea class="hhhhhs" name="message" value="" class="form-control "></textarea>
						</div>
						<div class="homefield" >
							<input type="submit" value="Submit" style="background-color:#FF1493 ">
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="about-section nnnndjr-jjjd d-no-mob" id="about">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-lg-7">
				<div class="about-area-content">
					<div class="about-content">
						<?=$about_description?>
					</div>
					<div class="btn-box">
						<a href="<?=$about_button_link?>" class="default-btn-one" style="background-color:#FF1493 "> <i class="fa fa-phone"></i><?=$about_button_text?></a>
					</div>
				</div>
			</div>
			<div class="col-lg-5">
				<div class="about-video">
					<div class="about-image nnnchfuut">
						<img src="<?=resizeimg($about_image,1050,1105,false)?>" alt="<?=webdata('webname')?>" title="<?=webdata('webname')?>">
					</div>
				</div>
			</div>
		</div>
	</div>
</section>


<section class="about-section nnnndjr-jjjd mob-show-jjj" id="about">
	<div class="container">
		<div class="row">

			 <div class="col-lg-5">
				<div class="about-video">
					<div class="about-image nnnchfuut">
						<img src="<?=resizeimg($about_image,1050,1105,false)?>" alt="<?=webdata('webname')?>" title="<?=webdata('webname')?>">
					</div>
				</div>
			</div>
			<div class="col-lg-7">
				<div class="about-area-content">
					<div class="about-content">
						<?=$about_description?>
					</div>

					<div class="btn-box">
						<a href="<?=$about_button_link?>" class="default-btn-one" style="background-color:#FF1493 "> <i class="fa fa-phone"></i><?=$about_button_text?></a>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>


         
<section class="new-mmmfjkg" id="services">
	<div class="container">
		<div class="row nnnvjjfuur-mmmske">
			<div class="section-title">
				<h2><?=$service_heading?></h2>   
			</div>
			<div class="row"> 
				<?php foreach($service_data as $servicedata) { ?>
				<div class="col-md-4 nnnf-kk">
					<div class="main-jjjjsfheur">
						<div class="njjjdie-image"><img src="<?=resizeimg($servicedata->image,1280,589,false)?>" title="<?=$servicedata->title?>" alt="<?=$servicedata->title?>"></div>
						<div class="njjjdie-content">
							<h3><?=$servicedata->title?></h3>
						</div>
					</div>
				</div>      
				<?php } ?>
			</div>     
		</div>
	</div>
</section>

<div class="video-section" style="background-image: url(<?=resizeimg($custom_section_image,1920,1281,false)?>); background-color: #FF1493" >
	<div class="container">
		<div class="video-area">
			<div class="video-title">
				<?=$custom_description?>
				<br>
				<a href="<?=$custom_section_button_link?>" class="mkkkdujrnnchf jjjjd-hhhr"><?=$custom_button_text?></a>
			</div>
		</div>            
	</div>    
</div> 


<section class="choose-section" id="why">
	<div class="container">
		<div class="choose-area">
			<div class="row">
				<div class="col-lg-12 text-center">
					<div class="choose-title">
						<h3><?=$why_choose_heading?></h3>
					</div>
				</div>
			</div>
		</div>    

		<div class="row">
			<?php foreach($why_choose_data as $whychoosedata) { ?>
			<div class="col-lg-4 col-md-6 mb-4">
				<div class="abg-jjjryhdfg">
					<img src="<?=resizeimg($whychoosedata->image,407,407,false)?>" alt="<?=$whychoosedata->heading?>" title="<?=$whychoosedata->heading?>">
					<h3><?=$whychoosedata->heading?></h3>
					<p><?=$whychoosedata->description?></p>
					
				</div>
			</div>
			<?php } ?>
		</div>
	</div>
</section>


<?php if($getTesimonial = getTesimonial($limit=3)) { ?>
<section class="testimonial-section" id="reveiw">
	<div class="container">
		<div class="section-title">
			<h2> Customer Testimonial <h2>
		</div>
		<div class="testimonial-slider owl-carousel owl-theme">
			<?php foreach($getTesimonial as $tesimonial) { ?>
			<div class="testimonial-item">
				<div class="testimonial-content">
					<i class="flaticon-quotation-marks"></i>
					<p><?=$tesimonial->description?></p>
					<div class="mkkkdjhryyfh"><?=$tesimonial->name?></div>
					<div class="rectangle-image">
						<img src="<?=resizeimg($tesimonial->description,200,200,false)?>" alt="<?=$tesimonial->name?>" title="<?=$tesimonial->name?>">
					</div>
				</div>
			</div>
			<?php } ?>
		</div>
	</div>
</section>
<?php } ?>


<div class="counter-section" style="background-color:#FF1493 ">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="single-counter">
					<h3><span class="counter"><?=$counter_1_value?></span></h3>
					<span class="sub-title"><?=$counter_1_text?></span>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="single-counter">
					<h3><span class="counter"><?=$counter_2_value?></span></h3>
					<span class="sub-title"><?=$counter_2_text?></span>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="single-counter">
					<h3><span class="counter"><?=$counter_3_value?></span></h3>
					<span class="sub-title"><?=$counter_3_text?></span>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="single-counter">
					<h3><span class="counter"><?=$counter_4_value?></span></h3>
					<span class="sub-title"><?=$counter_4_text?> </span>
				</div>
			</div>
		</div>
	</div>
	<div class="shape-img1">
		<img src="{{url('assets/landing_assets/img/circle.png')}}" alt="image">
	</div>
	<div class="shape-img2">
		<img src="{{url('assets/landing_assets/img/circle-2.png')}}" alt="image">
	</div>
</div>


<section class="new-pribsh">
	<div class="container">
		<div class="row pde-jjjsu">    
			<div class="col-md-12">
				<div class="ndvnsdfasik">
					 <?=$custom_description_1?>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="faq-section nnnff-kkkr" id="contact">
	<div class="container">
		<div class="section-title">
			<h2>Contact With Us</h2>    
		</div>
		<div class="row">
            <div class="inv-center"> 
				<div class="row">
					<div class="col-md-6">
						<div class="nsfyuwurwk">
							<input type="text" class="mkkks-jueutwey" placeholder="Name">
						</div>
					</div>
					<div class="col-md-6">
						<div class="nsfyuwurwk">
							<input type="text" class="mkkks-jueutwey" placeholder="Email">
						</div>
					</div>

					<div class="col-md-6">
						<div class="nsfyuwurwk">
							<input type="text" class="mkkks-jueutwey" placeholder="Phone">
						</div>
					</div>

					<div class="col-md-6">
						<div class="nsfyuwurwk">
							<select class="mkkks-jueutwey">
								<option hidden="">Select Service</option>                
							</select>
                        </div>
					</div>

					<div class="col-md-12">
                        <div class="nsfyuwurwk">
                            <input type="text" class="mkkks-jueutwey-2" placeholder="Message">
                        </div>
                    </div>

					<div class="col-md-12">
                        <div class="nsfyuwurwk">
							<button class="asdc-uuuey" style="background-color:#FF1493 ">SUBMIT NOW</button>
                        </div>
                    </div>
                </div>
			</div>
		</div>        
	</div>   
</section>


<section class="loacjerur">
	<div class="container">
		<?=$custom_description_2?>
	</div>
</section>
    

@endsection