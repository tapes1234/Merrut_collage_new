<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html;charset=UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<title><?php echo $meta_title;?></title>
	<meta name="robots" content="noindex,nofollow">
	<meta name="keywords" content="<?=$meta_keyword?>">
	<meta name="description" content="<?php echo $meta_description?>">
	<?php if(webdata('favicon_file'))  {?>
	<link rel="icon" href="<?php echo resizeimg(webdata('favicon_file'),64, 64,$aspectRatio=false)?>" type="image/x-icon">
	<?php } ?>
	<?php $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";?>
	<link href="<?=$actual_link?>" rel="canonical" />
	<base href="<?php echo url('/')?>">
	<!-- Facebook OpenGraph -->
    <meta property="og:locale" content="en">
    <meta property="og:url" content="<?=$actual_link?>">
    <meta property="og:site_name" content="<?=webdata('webname')?>">
    <meta property="og:title" content="<?php echo $meta_title;?>">
    <meta property="og:description" content="<?php echo $meta_description?>">
	<meta property="og:type" content="Article">
	<meta property="og:image" content="<?php echo resizeimg($og_image,1200,630,$aspectRatio=false)?>">
	<meta property="og:image" content="<?php echo resizeimg($og_image,1200,630,$aspectRatio=false)?>">
	<meta property="og:image" content="<?php echo resizeimg($og_image,1200,630,$aspectRatio=false)?>">
	<meta property="og:image" content="<?php echo resizeimg($og_image,1200,630,$aspectRatio=false)?>">
	<meta property="og:image" content="<?php echo resizeimg($og_image,1200,630,$aspectRatio=false)?>">
	<meta property="og:image:width" content="1200" />
	<meta property="og:image:height" content="630" />
	<!-- Twitter Card -->
	<meta name="twitter:title" content="<?php echo $meta_title;?>">
	<meta name="twitter:description" content="<?php echo $meta_description;?>">
	<meta name="twitter:image" content="<?php echo resizeimg($og_image,1200, 630,$aspectRatio=false)?>">
	<meta name="twitter:image:alt" content="<?php echo $meta_title;?>">
	<link href="{{url('assets/front_assets/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="{{url('assets/landing_assets/css/bootstrap.min.css')}}">
	<link rel="stylesheet" href="{{url('assets/landing_assets/css/style.css')}}">
	<link rel="stylesheet" href="{{url('assets/landing_assets/css/owl.carousell.min.css')}}">
	<link href="../../maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	<script src="{{url('assets/landing_assets/js/jquery.min.js')}}"></script>
	<?php 
		echo getanalytics($position="Head",$select_path="All Page",$url=''); 
		$urlforscript = str_replace(url('/'),"",url()->current());
		echo getanalytics($position="Head",$select_path="Custom",$url=$urlforscript); 
	?>
	
</head>
	<?php 
		echo getanalytics($position="Body",$select_path="All Page",$url=''); 
		$urlforscript = str_replace(url('/'),"",url()->current());
		echo getanalytics($position="Body",$select_path="Custom",$url=$urlforscript); 
	?>
	
	
<body class="hold-transition register-page">
	<header class="header-area" id="myHeader" style="background-color:#FF1493 " >
		<div class="container">
			<div class="row">
				<div class="col-lg-8 col-md-8">
					<ul class="header-info">
						<li>
							<i class="flaticon-call-answer"></i>Call Us:+91 88-782-00-782
						</li>
						<li>
							<i class="flaticon-envelope"></i>
							<a href="#"><span class="__cf_email__">info@flowers4you.in</span></a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</header>
	<div class="new-top-bar-mobile">
		<div class="first-njjjsu">
			<a href="#mobile-form-kj"><a style="color: #fff;" href="mailto:info@flowers4you.in">info@flowers4you.in</a></a>
		</div>
		<div class="righhhdyr-mobile-bh">
			<ul>
				<li><a href="tel:+91 88-782-00-782">+91 88-782-00-782</a></li>
				<li><a href="tel:+91 88-782-00-782"><i class="fa fa-phone"></i></a></li>
			</ul>
		</div>
	</div>
   
	<div class="navbar-area ">
		<div class="jian-mobile-nav">
			<div class="logo">
				<a class="ns-sh" href="<?=$current_url?>"><img src="<?=resizeimg(webdata('logo_file'),300,92,false)?>" alt="<?=webdata('webname')?>" title="<?=webdata('webname')?>"></a>
				<a class="mmmmcbf" href="<?=$current_url?>"><img src="<?=resizeimg(webdata('logo_file'),300,92,false)?>" aalt="<?=webdata('webname')?>" title="<?=webdata('webname')?>" width="100%"></a>
			</div>
		</div>
		<div class="jian-nav">
			<div class="container">
				<nav class="navbar navbar-expand-md navbar-light">
					<a class="navbar-brand ns-sh" href="<?=$current_url?>"><img src="<?=resizeimg(webdata('logo_file'),300,92,false)?>" alt="<?=webdata('webname')?>" title="<?=webdata('webname')?>"></a>
					<a class="navbar-brand mmmmcbf" href="<?=$current_url?>"><img src="<?=resizeimg(webdata('logo_file'),300,92,false)?>" alt="<?=webdata('webname')?>" title="<?=webdata('webname')?>"></a>
					<div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
						<ul class="navbar-nav">
							<li class="nav-item"><a href="<?=$current_url?>" class="nav-link active">Home</a></li>
							<li class="nav-item">
								<a href="#about" class="nav-link">About Us</a>
							</li>
							<li class="nav-item">
								<a href="#services" class="nav-link">Our Services</a>
							</li>
							<li class="nav-item"><a href="#why" class="nav-link">Why Choose Us</a></li>
							<li class="nav-item"><a href="#reveiw" class="nav-link">Reviews</a></li>
							<li class="nav-item"><a href="#contact" class="nav-link">Contact</a></li>
						</ul>
					</div>
				</nav>
			</div>
		</div>
	</div>
	@yield('content')	
	<div class="footer-bottom">
		<div class="container">
			<div class="bottom-content">
				<p>All Right Reserved <a href="#" class="__cf_email__" > <?=webdata('webname')?></a> </p>
			</div>
		</div>
	</div>
	<button onclick="topFunction()" id="myBtn" class="mkkkdnjhry" style="background-color:#FF1493 ">Call Us: <?=webdata('support')?></button>
	<div class="main-fixee-bot">
		<div class="left-bot-kkks">
			<a href="tel:<?=webdata('support')?>"><i class="fa fa-phone"></i><?=webdata('support')?></a> 
		</div>
		<div class="right-bot-kkks"><a target="_blank" href="https://api.whatsapp.com/send?phone=%20+91%209870651401%20&amp;text=Hey%20Team"><img src="assets/img/whatsapp.html" width="25"> Whatsapp Us</a></div>
	</div>
   <script src="{{url('assets/landing_assets/js/main.js')}}"></script>
   <script src="{{url('assets/landing_assets/js/owl.carousell.js')}}"></script>
   
<?php 
	echo getanalytics($position="Footer",$select_path="All Page",$url=''); 
	$urlforscript = str_replace(url('/'),"",url()->current());
	echo getanalytics($position="Footer",$select_path="Custom",$url=$urlforscript); 
?>
</body>
</html>